# Assignment: Symbolic and Algebraic Reasoning in Petri Nets

This project provides a Python implementation for analyzing **1-safe
Petri Nets** using symbolic (BDD) and algebraic reasoning.

## Project Structure

Ensure the following files are in the same directory: - `main.py` - PNML
test files: `mini_model.pnml`, `small_model.pnml`, `medium_model.pnml`,
`large_model.pnml`

## Requirements

-   Python 3.12+
-   Libraries: numpy, pyeda, dd, pulp, seaborn, matplotlib

## Installation

``` bash
python -m pip install numpy pyeda dd pulp seaborn matplotlib
```

## Running the Program

``` bash
python main.py net.pnml
```

Ensure the PNML file is in the same folder as `main.py`.

## Example

``` bash
python main.py mini_model.pnml
python main.py small_model.pnml
python main.py medium_model.pnml
python main.py large_model.pnml
```

## Output

Results will be printed in the terminal.
