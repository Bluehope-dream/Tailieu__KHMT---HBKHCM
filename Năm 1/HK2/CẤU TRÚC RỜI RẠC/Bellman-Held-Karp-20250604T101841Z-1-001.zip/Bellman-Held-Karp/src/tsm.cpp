#include "tsm.h"

// You can add your helper functions here

void Traveling(int edge[][3], int numberOfEdges, char startVertex){
    // Your code here
}
