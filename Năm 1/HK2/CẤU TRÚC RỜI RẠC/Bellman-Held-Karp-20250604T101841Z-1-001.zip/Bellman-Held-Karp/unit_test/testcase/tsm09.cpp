#include "unit_test.hpp"

bool UNIT_TEST::tsm09()
{
    string name = "tsm09";
    stringstream output;

    //! ---- DATA --------
    int numCities = 11;
    int matrix[numCities][numCities] = {
        {0, 80, 88, 70, 63, 13, 55, 9, 0, 17, 42},
        {59, 0, 80, 65, 21, 78, 8, 10, 69, 48, 18},
        {37, 43, 0, 84, 41, 23, 45, 18, 94, 97, 25},
        {75, 29, 13, 0, 45, 45, 27, 0, 54, 27, 70},
        {48, 86, 2, 13, 0, 7, 80, 74, 69, 49, 22},
        {88, 38, 17, 24, 79, 0, 40, 69, 50, 86, 19},
        {75, 61, 0, 89, 59, 45, 0, 68, 11, 0, 95},
        {81, 48, 0, 83, 14, 41, 63, 0, 88, 10, 64},
        {62, 50, 55, 79, 74, 34, 71, 96, 0, 36, 57},
        {67, 12, 70, 67, 1, 29, 65, 21, 41, 0, 17},
        {68, 74, 17, 1, 58, 31, 42, 73, 19, 5, 0}
    };
    char vertex[numCities] = {'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'};

    char startVertex = 'D';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len = "The best path length is: ";
        output_len += (179 * 0.95 < path_len && path_len < 179 * 1.05 ? "179" :to_string(path_len));

    //! ---- EXPECT --------
    string expect = "The best path length is: 179";
    return printResult(output_len, expect, name);
}