#include "unit_test.hpp"

bool UNIT_TEST::tsm13()
{
    string name = "tsm13";
    stringstream output;

    //! ---- DATA --------
    int numCities = 3;
    int matrix[numCities][numCities] = {
        {0, 2, 1},
        {1, 0, 3},
        {2, 3, 0}
    };
    char vertex[numCities] = {'B','D','S'};

    char startVertex = 'B';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());
    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (5 * 0.95 < path_len && path_len < 5 * 1.05 ? "5" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 5";
    return printResult(output_len, expect, name);
}