#include "unit_test.hpp"

bool UNIT_TEST::tsm10()
{
    string name = "tsm10";
    stringstream output;

    //! ---- DATA --------
    int numCities = 2;
    int matrix[numCities][numCities] = {
        {0, 590},
        {0, 0}
    };
    char vertex[numCities] = {'B','C'};

    char startVertex = 'B';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < 8; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
        output_len += to_string(path_len);
    }

    //! ---- EXPECT --------
    string expect = "No path found";
    return printResult(output_len, expect, name);
}