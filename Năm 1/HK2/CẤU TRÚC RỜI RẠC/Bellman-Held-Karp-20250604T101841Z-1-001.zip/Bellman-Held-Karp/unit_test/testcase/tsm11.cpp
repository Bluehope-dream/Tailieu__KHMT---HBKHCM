#include "unit_test.hpp"

bool UNIT_TEST::tsm11()
{
    string name = "tsm11";
    stringstream output;

    //! ---- DATA --------
    int numCities = 12;
    int matrix[numCities][numCities] = {
         {0, 68, 78, 95, 13, 89, 30, 1, 37, 70, 25, 46},
        {33, 0, 63, 1, 99, 79, 94, 60, 56, 38, 85, 47},
        {1, 71, 0, 63, 41, 79, 72, 88, 38, 87, 8, 68},
        {34, 21, 58, 0, 64, 22, 95, 34, 47, 94, 19, 63},
        {95, 18, 42, 41, 0, 78, 98, 79, 15, 98, 80, 38},
        {61, 74, 18, 85, 62, 0, 56, 24, 70, 24, 58, 43},
        {34, 74, 66, 82, 9, 65, 0, 76, 80, 28, 71, 99},
        {23, 12, 29, 73, 92, 97, 71, 0, 24, 35, 84, 98},
        {5, 70, 12, 13, 94, 34, 90, 5, 0, 78, 24, 79},
        {96, 6, 40, 61, 82, 21, 42, 5, 20, 0, 65, 70},
        {1, 38, 14, 50, 62, 38, 86, 46, 89, 43, 0, 16},
        {53, 57, 63, 40, 99, 68, 70, 23, 47, 66, 82, 0}
    };
    char vertex[numCities] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L'};

    char startVertex = 'E';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
        output_len += (205 * 0.95 < path_len && path_len < 205 * 1.05 ? "205" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 205";
    return printResult(output_len, expect, name);
}