#include "unit_test.hpp"

bool UNIT_TEST::tsm03()
{
    string name = "tsm03";
    stringstream output;

    //! ---- DATA --------
    int numCities = 8;
    int matrix[numCities][numCities] = {
        {0, 399, 683, 780, 479, 480, 839, 101},
        {547, 0, 276, 795, 843, 168, 491, 802},
        {180, 876, 0, 421, 348, 490, 323, 446},
        {583, 796, 398, 0, 615, 840, 784, 295},
        {7, 143, 391, 406, 0, 826, 171, 237},
        {306, 10, 338, 205, 638, 0, 134, 400},
        {158, 625, 203, 691, 501, 624, 0, 39},
        {344, 948, 485, 927, 96, 235, 895, 0}
    };
    char vertex[numCities] = {'A', 'B', 'C', 'D', 'E', 'F', 'I', 'H'};

    char startVertex = 'E';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len = "The best path length is: ";
        output_len += (1952 * 0.95 < path_len && path_len < 1952 * 1.05 ? "1952" :to_string(path_len));

    //! ---- EXPECT --------
    string expect = "The best path length is: 1592";
    return printResult(output_len, expect, name);
}