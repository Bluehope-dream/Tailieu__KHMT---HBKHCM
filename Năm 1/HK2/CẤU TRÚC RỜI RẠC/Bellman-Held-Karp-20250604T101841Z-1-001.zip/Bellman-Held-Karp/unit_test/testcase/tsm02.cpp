#include "unit_test.hpp"

bool UNIT_TEST::tsm02()
{
    string name = "tsm02";
    stringstream output;

    //! ---- DATA --------
    int numCities = 7;
    int matrix[numCities][numCities] = {
        {0, 346, 76, 227, 125, 605, 123},
        {165, 0, 486, 81, 821, 833, 783},
        {86, 812, 0, 776, 564, 491, 940},
        {602, 12, 590, 0, 939, 927, 513},
        {937, 601, 430, 533, 0, 440, 153},
        {155, 786, 581, 383, 263, 0, 187},
        {858, 429, 673, 291, 250, 858, 0}
    };
    char vertex[numCities] = {'A', 'B', 'C', 'F', 'I', 'H', 'L'};

    char startVertex = 'A';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len = "The best path length is: ";
        output_len += (1451 * 0.95 < path_len && path_len < 1451 * 1.05 ? "1451" :to_string(path_len));

    //! ---- EXPECT --------
    string expect = "The best path length is: 1451";
    return printResult(output_len, expect, name);
}