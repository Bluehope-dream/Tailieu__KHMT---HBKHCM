#include "unit_test.hpp"

bool UNIT_TEST::tsm20()
{
    string name = "tsm20";
    stringstream output;

    //! ---- DATA --------
    int numCities = 13;
    int matrix[numCities][numCities] = {
        {0, 310, 972, 838, 603, 426, 335, 88, 804, 650, 485, 388, 763},
        {219, 0, 794, 496, 274, 978, 806, 72, 675, 553, 24, 555, 514},
        {526, 19, 0, 74, 76, 502, 318, 864, 164, 642, 54, 768, 68},
        {390, 208, 225, 0, 392, 693, 613, 507, 0, 408, 3, 538, 738},
        {0, 962, 413, 715, 0, 338, 320, 230, 216, 340, 656, 293, 0},
        {326, 509, 359, 968, 564, 0, 479, 389, 306, 687, 614, 50, 732},
        {579, 558, 996, 339, 561, 887, 0, 78, 371, 849, 491, 439, 0},
        {0, 21, 404, 504, 29, 49, 698, 0, 355, 559, 409, 675, 475},
        {888, 64, 133, 927, 678, 183, 659, 610, 0, 741, 656, 949, 303},
        {543, 27, 26, 744, 871, 817, 284, 683, 838, 0, 41, 539, 867},
        {90, 237, 574, 649, 647, 250, 476, 887, 314, 609, 0, 815, 345},
        {793, 474, 955, 886, 482, 904, 189, 377, 284, 568, 122, 0, 155},
        {385, 406, 0, 0, 447, 729, 443, 890, 318, 370, 891, 0, 0}
    };
    char vertex[numCities] = {'A', 'B', 'C', 'D', 'E', 'F', 'G', 'L', 'U', 'W', 'X', 'Y', 'Z'};

    char startVertex = 'Z';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (1838 * 0.95 < path_len && path_len < 1838 * 1.05 ? "1838" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 1838";
    return printResult(output_len, expect, name);
}