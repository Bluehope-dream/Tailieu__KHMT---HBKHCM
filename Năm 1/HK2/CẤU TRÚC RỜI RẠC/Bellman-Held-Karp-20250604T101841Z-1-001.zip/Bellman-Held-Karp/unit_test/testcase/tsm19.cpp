#include "unit_test.hpp"

bool UNIT_TEST::tsm19()
{
    string name = "tsm19";
    stringstream output;

    //! ---- DATA --------
    int numCities = 15;
    int matrix[numCities][numCities] = {
        {0, 338, 153, 328, 264, 151, 834, 488, 909, 570, 722, 242, 503, 278, 901},
        {107, 0, 842, 189, 31, 588, 229, 296, 657, 394, 783, 335, 917, 703, 822},
        {670, 556, 0, 776, 360, 710, 456, 624, 213, 290, 112, 123, 860, 186, 717},
        {363, 465, 618, 0, 822, 307, 807, 205, 247, 389, 501, 905, 783, 284, 592},
        {701, 340, 414, 371, 0, 896, 190, 83, 958, 646, 707, 172, 936, 819, 647},
        {796, 357, 364, 511, 822, 0, 334, 685, 481, 494, 891, 729, 883, 744, 986},
        {666, 29, 578, 719, 369, 993, 0, 90, 617, 535, 525, 576, 182, 232, 100},
        {470, 403, 747, 619, 761, 111, 130, 0, 935, 797, 168, 769, 291, 59, 498},
        {174, 803, 484, 193, 184, 414, 912, 905, 0, 407, 355, 523, 943, 880, 451},
        {477, 465, 551, 299, 868, 298, 918, 981, 761, 0, 401, 269, 558, 569, 38},
        {850, 980, 536, 376, 135, 372, 569, 320, 138, 482, 0, 577, 546, 189, 100},
        {841, 69, 551, 670, 534, 102, 969, 755, 752, 888, 736, 0, 513, 641, 5},
        {424, 562, 43, 626, 542, 931, 2, 677, 655, 572, 349, 794, 0, 406, 927},
        {692, 595, 379, 885, 664, 931, 555, 551, 385, 876, 306, 490, 116, 0, 394},
        {355, 757, 752, 779, 319, 795, 405, 213, 79, 760, 891, 86, 332, 592, 0}
    };
    char vertex[numCities] = {'B','C','D','E','F','G','H','I','J','K','L','M','N','O','P'};

    char startVertex = 'B';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (1996 * 0.95 < path_len && path_len < 1996 * 1.05 ? "1996" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 1996";
    return printResult(output_len, expect, name);
}