#include "unit_test.hpp"

bool UNIT_TEST::tsm18()
{
    string name = "tsm18";
    stringstream output;

    //! ---- DATA --------
    int numCities = 16;
    int matrix[numCities][numCities] = {
        {0, 6, 20, 2, 93, 63, 9, 15, 84, 21, 0, 70, 83, 41, 4, 52},
        {86, 0, 25, 47, 57, 28, 94, 99, 23, 38, 27, 99, 3, 84, 93, 90},
        {80, 99, 0, 62, 83, 44, 25, 92, 59, 61, 14, 59, 84, 49, 1, 88},
        {1, 39, 65, 0, 48, 96, 46, 42, 48, 21, 32, 75, 72, 35, 12, 65},
        {77, 92, 16, 40, 0, 27, 61, 17, 72, 20, 31, 38, 80, 15, 39, 33},
        {55, 92, 72, 21, 92, 0, 68, 19, 34, 16, 40, 18, 44, 12, 5, 56},
        {30, 35, 0, 46, 27, 80, 0, 7, 44, 4, 28, 75, 42, 60, 90, 81},
        {93, 98, 73, 17, 19, 65, 37, 0, 90, 51, 6, 30, 21, 50, 94, 78},
        {58, 76, 13, 10, 23, 40, 42, 82, 0, 37, 46, 62, 12, 40, 22, 55},
        {73, 67, 53, 98, 36, 24, 15, 74, 14, 0, 18, 80, 96, 39, 82, 42},
        {18, 92, 19, 83, 2, 94, 24, 97, 76, 61, 0, 43, 39, 25, 36, 13},
        {32, 9, 33, 85, 8, 69, 61, 75, 43, 75, 94, 0, 75, 23, 33, 57},
        {66, 3, 49, 85, 87, 4, 79, 63, 1, 7, 76, 96, 0, 46, 53, 32},
        {12, 86, 94, 97, 23, 54, 66, 85, 29, 62, 12, 23, 37, 0, 36, 9},
        {95, 2, 12, 44, 39, 51, 48, 18, 66, 1, 25, 42, 98, 24, 0, 48},
        {30, 88, 34, 76, 85, 57, 30, 51, 42, 60, 65, 7, 83, 3, 43, 0}
    };
    char vertex[numCities] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q'};

    char startVertex = 'A';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (118 * 0.95 < path_len && path_len < 118 * 1.05 ? "118" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 118";
    return printResult(output_len, expect, name);
}