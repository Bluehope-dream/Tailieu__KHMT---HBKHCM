#include "unit_test.hpp"

bool UNIT_TEST::tsm12()
{
    string name = "tsm12";
    stringstream output;

    //! ---- DATA --------
    int numCities = 9;
    int matrix[numCities][numCities] = {
        {0, 427, 314, 320, 829, 437, 725, 738, 154},
        {845, 0, 182, 754, 637, 359, 304, 314, 413},
        {295, 936, 0, 315, 313, 678, 840, 905, 200},
        {43, 621, 804, 0, 110, 164, 987, 598, 591},
        {301, 270, 772, 91, 0, 995, 511, 597, 192},
        {45, 351, 829, 404, 655, 0, 143, 817, 950},
        {431, 485, 616, 461, 325, 873, 0, 661, 720},
        {494, 818, 830, 10, 805, 780, 601, 0, 459},
        {51, 726, 550, 398, 237, 147, 591, 282, 0}
    };
    char vertex[numCities] = {'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S'};

    char startVertex = 'K';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (1766 * 0.95 < path_len && path_len < 1766 * 1.05 ? "1766" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 1766";
    return printResult(output_len, expect, name);
}