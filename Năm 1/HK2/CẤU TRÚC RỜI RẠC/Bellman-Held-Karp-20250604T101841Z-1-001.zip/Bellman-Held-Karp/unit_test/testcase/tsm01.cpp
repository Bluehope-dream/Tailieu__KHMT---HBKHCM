#include "unit_test.hpp"

bool UNIT_TEST::tsm01()
{
    string name = "tsm01";
    stringstream output;

    //! ---- DATA --------
    int numCities = 5;
    int matrix[numCities][numCities] = {
        {0, 9, 92, 61, 11},
        {41, 0, 99, 44, 78},
        {75, 42, 0, 79, 12},
        {86, 78, 24, 0, 15},
        {86, 62, 1, 9, 0}
    };
    char vertex[numCities] = {'A', 'C', 'F', 'I', 'H'};

    char startVertex = 'A';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len = "The best path length is: ";
        output_len += (127 * 0.95 < path_len && path_len < 127 * 1.05 ? "127" :to_string(path_len));

    //! ---- EXPECT --------
    string expect = "The best path length is: 127";
    return printResult(output_len, expect, name);
}