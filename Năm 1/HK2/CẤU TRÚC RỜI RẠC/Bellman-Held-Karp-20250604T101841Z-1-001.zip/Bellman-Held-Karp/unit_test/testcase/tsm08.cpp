#include "unit_test.hpp"

bool UNIT_TEST::tsm08()
{
    string name = "tsm08";
    stringstream output;

    //! ---- DATA --------
    int numCities = 3;
    int matrix[numCities][numCities] = {
         {0, 8, 94},
        {20, 0, 0},
        {51, 54, 0}
    };
    char vertex[numCities] = {'B', 'C', 'E'};

    char startVertex = 'C';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len = "The best path length is: ";
        output_len += (168 * 0.95 < path_len && path_len < 168 * 1.05 ? "168" :to_string(path_len));

    //! ---- EXPECT --------
    string expect = "The best path length is: 168";
    return printResult(output_len, expect, name);
}