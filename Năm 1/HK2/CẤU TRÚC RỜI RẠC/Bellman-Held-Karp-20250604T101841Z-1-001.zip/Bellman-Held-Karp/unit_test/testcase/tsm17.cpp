#include "unit_test.hpp"

bool UNIT_TEST::tsm17()
{
    string name = "tsm17";
    stringstream output;

    //! ---- DATA --------
    int numCities = 14;
    int matrix[numCities][numCities] = {
        {0,   902, 398, 535, 907, 576, 56,  960, 448, 468, 889, 642, 216, 707},
        {768, 0,   650, 124, 545, 782, 992, 817, 442, 665, 46,  983, 459, 455},
        {811, 987, 0,   974, 390, 893, 228, 789, 428, 488, 717, 484, 448, 165},
        {305, 337, 159, 0,   873, 396, 927, 875, 521, 824, 657, 865, 993, 99},
        {882, 39,  435, 693, 0,   847, 598, 681, 173, 340, 574, 401, 481, 354},
        {241, 198, 190, 689, 716, 0,   847, 27,  875, 721, 423, 803, 596, 296},
        {979, 254, 161, 973, 705, 44,  0,   12,  492, 737, 211, 442, 770, 384},
        {783, 696, 138, 616, 50,  379, 815, 0,   593, 69,  531, 440, 448, 758},
        {513, 871, 561, 462, 168, 893, 68,  681, 0,   866, 125, 725, 230, 618},
        {815, 442, 412, 585, 178, 547, 282, 668, 164, 0,   684, 48,  979, 629},
        {469, 862, 422, 269, 620, 935, 492, 534, 749, 660, 0,   427, 817, 694},
        {645, 943, 419, 875, 913, 586, 669, 325, 172, 848, 873, 0,   806, 516},
        {37,  842, 916, 368, 472, 737, 230, 894, 6,   202, 181, 499, 0,   736},
        {283, 511, 515, 100, 1548, 160, 395, 977, 36,  308, 915, 57,  986, 0}
    };
    char vertex[numCities] = {'A','B','C','D','E','F','G','S','T','U','V','W','X','Y'};

    char startVertex = 'X';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (1548 * 0.95 < path_len && path_len < 1548 * 1.05 ? "1548" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 1548";
    return printResult(output_len, expect, name);
}