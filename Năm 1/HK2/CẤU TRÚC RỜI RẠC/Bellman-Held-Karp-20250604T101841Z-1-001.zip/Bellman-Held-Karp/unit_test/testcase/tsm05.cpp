#include "unit_test.hpp"

bool UNIT_TEST::tsm05()
{
    string name = "tsm05";
    stringstream output;

    //! ---- DATA --------
    int numCities = 5;
    int matrix[numCities][numCities] = {
        {0, 855, 870, 949, 90},
        {173, 0, 998, 713, 279},
        {737, 882, 0, 244, 526},
        {70, 200, 793, 0, 311},
        {702, 126, 359, 998, 0}
    };
    char vertex[numCities] = {'A', 'B', 'X', 'Y', 'Z'};

    char startVertex = 'X';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len = "The best path length is: ";
        output_len += (1066 * 0.95 < path_len && path_len < 1066 * 1.05 ? "1066" :to_string(path_len));

    //! ---- EXPECT --------
    string expect = "The best path length is: 1066";
    return printResult(output_len, expect, name);
}