#include "unit_test.hpp"

bool UNIT_TEST::tsm15()
{
    string name = "tsm15";
    stringstream output;

    //! ---- DATA --------
    int numCities = 7;
    int matrix[numCities][numCities] = {
        {0,   694, 830, 77,  353, 306, 603},
        {313, 0,   780, 13,  412, 185, 713},
        {7,   617, 0,   174, 812, 163, 477},
        {862, 889, 9,   0,   551, 892, 686},
        {419, 301, 572, 235, 0,   905, 301},
        {941, 599, 132, 370, 952, 0,   438},
        {973, 617, 218, 986, 29,  755,   0}
    };
    char vertex[numCities] = {'A','C','E','F','H','J','K'};

    char startVertex = 'A';

    // Convert to edge list
    int edge[numCities*numCities][3];
    int numberOfEdges = 0;
    for (int i = 0; i < numCities; i++)
    {
        for (int j = 0; j < numCities; j++)
        {
            if (matrix[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = matrix[i][j];
                numberOfEdges++;
            }
        }
    }

    //! ---- PROCESS --------
    std::streambuf* oldCoutBuffer = std::cout.rdbuf();
    std::cout.rdbuf(output.rdbuf());
    Traveling(edge, numberOfEdges, startVertex);
    std::cout.rdbuf(oldCoutBuffer);

    int* matrixToCal[numCities];
    for (int i = 0; i < numCities; ++i) matrixToCal[i] = matrix[i];

    int path_len = computePathCost(matrixToCal, numCities, vertex, output.str());

    string output_len;
    if (path_len == -1)
    {
        output_len = "No path found";
    }
    else if (path_len == -2)
    {
        output_len = "Your output: " + output.str();
    }
    
    else
    {
        output_len = "The best path length is: ";
            output_len += (1103 * 0.95 < path_len && path_len < 1103 * 1.05 ? "1103" :to_string(path_len));
    }

    //! ---- EXPECT --------
    string expect = "The best path length is: 1103";
    return printResult(output_len, expect, name);
}