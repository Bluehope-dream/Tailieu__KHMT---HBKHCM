#include "tsm.h"
#include "bellman.h"
void arg_c1(){
     const int num_vertices = 10;
    char vertex[num_vertices] = {
        'A','B','C','D','E','F','G','H','I','O'
    };

    // Ma trận trọng số đồ thị có đủ kết nối cho TSP
    int G2[num_vertices][num_vertices] = {
        // A   B   C   D   E   F   G   H   I   O
        { 0,  5, 90, 90, 90, 90, 90, 90, 90,100 }, // A
        { 5,  0,  5, 90, 90, 90, 90, 90, 90, 90 }, // B
        {90,  5,  0,  5, 90, 90, 90, 90, 90, 90 }, // C
        {90, 90,  5,  0,  5, 90, 90, 90, 90, 90 }, // D
        {90, 90, 90,  5,  0,  5, 90, 90, 90, 90 }, // E
        {90, 90, 90, 90,  5,  0,  5, 90, 90, 90 }, // F
        {90, 90, 90, 90, 90,  5,  0,  5, 90, 90 }, // G
        {90, 90, 90, 90, 90, 90,  5,  0,  5, 90 }, // H
        {90, 90, 90, 90, 90, 90, 90,  5,  0,  5 }, // I
        {100,90, 90, 90, 90, 90, 90, 90,  5,  0 }, // O
    };
    int edge[num_vertices * num_vertices][3];
    int numberOfEdges = 0;

    for (int i = 0; i < num_vertices; i++) {
        for (int j = 0; j < num_vertices; j++) {
            if (G2[i][j] > 0) {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = G2[i][j];
                numberOfEdges++;
            }
        }
    }
    int BellmanFordValue[num_vertices];
    int BellmanFordPrevious[num_vertices];

    for (int i = 0; i < num_vertices; i++) {
        BellmanFordValue[i] = -1;
        BellmanFordPrevious[i] = -1;
    }

    string start = "A";
    string end = "O";

    for(int i = 0; i < num_vertices; i++){
        BF(edge, numberOfEdges, start[0], BellmanFordValue, BellmanFordPrevious);
        cout << "Iteration " << i + 1 << ": " << endl;
        for(int j = 0; j < num_vertices; j++){
            cout << BellmanFordValue[j] << " ";
        }
        cout << endl;
        for(int j = 0; j < num_vertices; j++){
            cout << BellmanFordPrevious[j] << " ";
        }
        cout << endl;
    }
// Gọi cho thuật toán shortest path
     cout << "Shortest path from " << start << " to " << end << ": ";
    string path = BF_Path(edge, numberOfEdges, start[0], end[0]);
    cout << path << endl;
// Gọi thuật toán TSP
    cout << "TSP result from " << start << ": ";
    string tsm = Traveling(edge, numberOfEdges, start[0]);
    cout << tsm << endl;
}
void arg_c2(){
    const int num_vertices = 30;
    char vertex[num_vertices] = {
    'A','B','C','D','E','F','G','H','I','J',
    'K','L','M','N','O','P','Q','R','S','T',
    'U','V','W','X','Y','Z','1','2','3','4'
    };
int G1[num_vertices][num_vertices] = {
// A   B   C   D   E   F   G   H   I   J   K   L   M   N   O   P   Q   R   S   T   U   V   W   X   Y   Z   1   2   3   4
{  0, 12, 23, 34, 45, 31, 22, 27, 25, 44, 41, 36, 31, 30, 33, 35, 37, 32, 28, 26, 29, 30, 33, 36, 39, 40, 41, 44, 47, 50 }, // A
{ 12,  0, 11, 21, 33, 30, 28, 26, 32, 38, 35, 31, 28, 29, 30, 33, 36, 39, 40, 41, 42, 43, 46, 48, 50, 52, 54, 55, 57, 59 }, // B
{ 23, 11,  0, 10, 22, 25, 21, 20, 24, 30, 31, 33, 36, 39, 42, 45, 48, 50, 53, 55, 57, 59, 60, 61, 63, 65, 66, 68, 70, 72 }, // C
{ 34, 21, 10,  0, 11, 19, 18, 16, 20, 23, 25, 29, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50, 52, 53, 55, 56, 58, 60, 62, 64 }, // D
{ 45, 33, 22, 11,  0, 10, 15, 17, 22, 25, 28, 30, 33, 35, 37, 40, 42, 45, 47, 49, 51, 52, 54, 56, 58, 60, 61, 63, 65, 67 }, // E
{ 31, 30, 25, 19, 10,  0, 12, 14, 16, 18, 21, 23, 25, 28, 30, 33, 35, 37, 40, 42, 44, 45, 47, 49, 51, 52, 54, 56, 58, 60 }, // F
{ 22, 28, 21, 18, 15, 12,  0,  8, 10, 14, 18, 20, 22, 24, 27, 30, 32, 34, 36, 39, 41, 43, 45, 46, 48, 50, 51, 53, 55, 57 }, // G
{ 27, 26, 20, 16, 17, 14,  8,  0,  6,  9, 12, 15, 17, 19, 22, 24, 26, 28, 30, 33, 35, 37, 39, 41, 43, 45, 46, 48, 50, 52 }, // H
{ 25, 32, 24, 20, 22, 16, 10,  6,  0,  5,  9, 12, 14, 16, 19, 21, 23, 25, 27, 30, 32, 34, 36, 38, 40, 42, 44, 46, 48, 50 }, // I
{ 44, 38, 30, 23, 25, 18, 14,  9,  5,  0,  6, 10, 12, 14, 16, 18, 20, 22, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43, 45, 47 }, // J
{ 41, 35, 31, 25, 28, 21, 18, 12,  9,  6,  0,  5,  8, 10, 12, 14, 16, 18, 21, 23, 25, 27, 29, 31, 33, 35, 37, 39, 41, 43 }, // K
{ 36, 31, 33, 29, 30, 23, 20, 15, 12, 10,  5,  0,  4,  7,  9, 11, 13, 15, 18, 20, 22, 24, 26, 28, 30, 32, 34, 36, 38, 40 }, // L
{ 31, 28, 36, 32, 33, 25, 22, 17, 14, 12,  8,  4,  0,  3,  5,  8, 10, 12, 14, 17, 19, 21, 23, 25, 27, 29, 31, 33, 35, 37 }, // M
{ 30, 29, 39, 34, 35, 28, 24, 19, 16, 14, 10,  7,  3,  0,  2,  4,  6,  8, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31, 33 }, // N
{ 33, 30, 42, 36, 37, 30, 27, 22, 19, 16, 12,  9,  5,  2,  0,  2,  4,  6,  9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29, 31 }, // O
{ 35, 33, 45, 38, 40, 33, 30, 24, 21, 18, 14, 11,  8,  4,  2,  0,  2,  4,  6,  9, 11, 13, 15, 17, 19, 21, 23, 25, 27, 29 }, // P
{ 37, 36, 48, 40, 42, 35, 32, 26, 23, 20, 16, 13, 10,  6,  4,  2,  0,  2,  4,  7,  9, 11, 13, 15, 17, 19, 21, 23, 25, 27 }, // Q
{ 32, 39, 50, 42, 45, 37, 34, 28, 25, 22, 18, 15, 12,  8,  6,  4,  2,  0,  2,  5,  7,  9, 11, 13, 15, 17, 19, 21, 23, 25 }, // R
{ 28, 40, 53, 44, 47, 40, 36, 30, 27, 25, 21, 18, 14, 11,  9,  6,  4,  2,  0,  3,  5,  7,  9, 11, 13, 15, 17, 19, 21, 23 }, // S
{ 26, 41, 55, 46, 49, 42, 39, 33, 30, 27, 23, 20, 17, 13, 11,  9,  7,  5,  3,  0,  2,  4,  6,  8, 10, 12, 14, 16, 18, 20 }, // T
{ 29, 42, 57, 48, 51, 44, 41, 35, 32, 29, 25, 22, 19, 15, 13, 11,  9,  7,  5,  2,  0,  2,  4,  6,  8, 10, 12, 14, 16, 18 }, // U
{ 30, 43, 59, 50, 52, 45, 43, 37, 34, 31, 27, 24, 21, 17, 15, 13, 11,  9,  7,  4,  2,  0,  2,  4,  6,  8, 10, 12, 14, 16 }, // V
{ 33, 46, 60, 52, 54, 47, 45, 39, 36, 33, 29, 26, 23, 19, 17, 15, 13, 11,  9,  6,  4,  2,  0,  2,  4,  6,  8, 10, 12, 14 }, // W
{ 36, 48, 61, 53, 56, 49, 46, 41, 38, 35, 31, 28, 25, 21, 19, 17, 15, 13, 11,  8,  6,  4,  2,  0,  2,  4,  6,  8, 10, 12 }, // X
{ 39, 50, 63, 55, 58, 51, 48, 43, 40, 37, 33, 30, 27, 23, 21, 19, 17, 15, 13, 10,  8,  6,  4,  2,  0,  2,  4,  6,  8, 10 }, // Y
{ 40, 52, 65, 56, 60, 52, 50, 45, 42, 39, 35, 32, 29, 25, 23, 21, 19, 17, 15, 12, 10,  8,  6,  4,  2,  0,  2,  4,  6,  8 }, // Z
{ 41, 54, 66, 58, 61, 54, 51, 46, 44, 41, 37, 34, 31, 27, 25, 23, 21, 19, 17, 14, 12, 10,  8,  6,  4,  2,  0,  2,  4,  6 }, // 1
{ 44, 55, 68, 60, 63, 56, 53, 48, 46, 43, 39, 36, 33, 29, 27, 25, 23, 21, 19, 16, 14, 12, 10,  8,  6,  4,  2,  0,  2,  4 }, // 2
{ 47, 57, 70, 62, 65, 58, 55, 50, 48, 45, 41, 38, 35, 31, 29, 27, 25, 23, 21, 18, 16, 14, 12, 10,  8,  6,  4,  2,  0,  2 }, // 3
{ 50, 59, 72, 64, 67, 60, 57, 52, 50, 47, 43, 40, 37, 33, 31, 29, 27, 25, 23, 20, 18, 16, 14, 12, 10,  8,  6,  4,  2,  0 }  // 4
};

    // Convert to edge list
    int edge[num_vertices*num_vertices][3];
    int numberOfEdges = 0;
    for (int i = 0; i < num_vertices; i++)
    {
        for (int j = 0; j < num_vertices; j++)
        {
            if (G1[i][j] > 0)
            {
                edge[numberOfEdges][0] = vertex[i];
                edge[numberOfEdges][1] = vertex[j];
                edge[numberOfEdges][2] = G1[i][j];
                numberOfEdges++;
            }
        }
    }

    string start = "B";
    string end = "1";

    int BellmanFordValue[num_vertices];
    int BellmanFordPrevious[num_vertices];

    for(int i = 0; i < num_vertices; i++){
        BellmanFordValue[i] = -1;
        BellmanFordPrevious[i] = -1;
    }

    for(int i = 0; i < num_vertices; i++){
        BF(edge, numberOfEdges, start[0], BellmanFordValue, BellmanFordPrevious);
        cout << "Iteration " << i + 1 << ": " << endl;
        for(int j = 0; j < num_vertices; j++){
            cout << BellmanFordValue[j] << " ";
        }
        cout << endl;
        for(int j = 0; j < num_vertices; j++){
            cout << BellmanFordPrevious[j] << " ";
        }
        cout << endl;
    }

    cout << "Shortest path from " << start << " to " << end << ": ";
    string path = BF_Path(edge, numberOfEdges, start[0], end[0]);
    cout << path << endl;
    cout << "Traveling Salesman Problem solution: ";
    string tsm_path = Traveling(edge, numberOfEdges, start[0]);
    cout << tsm_path << endl;
}

int main() {
       cout << "\033[32mTEST01\033[0m" << endl;
    arg_c1();   // Test này dành kiểm thử việc in cả đoạn đường ngắn nhất và kết quả TSM cho bài toán 10 đỉnh 
       cout << "\033[32mTEST02\033[0m" << endl;
    arg_c2();  // Chủ dành cho việc test TSM với số đỉnh là 25 đỉnh 
    return 0;
}
