#include "tsm.h"
const int INF = 1e9;
// Thực hiện lấy các chỉ số có sẵn trong thuật toán ACO này 
const double ALPHA = 1.0;      // Trọng số pheromone
const double BETA = 2.0;       // Trọng số heuristic
const double RHO = 0.1;        // Tốc độ bay hơi pheromone
const double Q = 100.0;        // Hằng số pheromone
const int NUM_ANTS = 20;       // Số kiến chuyên dụng cho thuật toán 
const int MAX_ITERATIONS = 100; // Số vòng lặp

int getID(char vertex, const vector<char>& list) {
    for (int i = 0; i < list.size(); ++i) {
        if (list[i] == vertex) return i;
    }
    return -1;
}

void setVertexList(int edgeList[][3], int numEdges, vector<char>& res) {
    for (int i = 0; i < numEdges; ++i) {
        char u = edgeList[i][0];
        char v = edgeList[i][1];
        if (find(res.begin(), res.end(), u) == res.end())
            res.push_back(u);
        if (find(res.begin(), res.end(), v) == res.end())
            res.push_back(v);
    }
}

void initDistanceMatrix(int edgeList[][3], int numEdges, const vector<char>& vertices, vector<vector<int>>& dist) {
    int size = vertices.size();
    dist.assign(size, vector<int>(size, INF));
    for (int i = 0; i < size; ++i)
        dist[i][i] = 0;
    for (int i = 0; i < numEdges; ++i) {
        int from = getID(edgeList[i][0], vertices);
        int to = getID(edgeList[i][1], vertices);
        dist[from][to] = edgeList[i][2];
    }
}

void reconstructPath(const vector<vector<int>>& parent, int endMask, int last, vector<int>& trace) {
    while (last != -1) {
        trace.push_back(last);
        int prev = parent[endMask][last];
        endMask ^= (1 << last);
        last = prev;
    }
    reverse(trace.begin(), trace.end());
}

string Traveling(int edgeList[][3], int numberOfEdges, char startVertex){
    vector<char> vertex;
    setVertexList(edgeList, numberOfEdges, vertex);
    int startIdx = getID(startVertex, vertex);
    if (startIdx == -1) {
        return "No path found";
    }

    vector<vector<int>> dist;
    initDistanceMatrix(edgeList, numberOfEdges, vertex, dist);
    int num = vertex.size();
    
    if (num > 20) {
    vector<vector<double>> pheromone(num, vector<double>(num, 0.1));
    vector<vector<double>> heuristic(num, vector<double>(num, 0.0));
    
    for (int i = 0; i < num; i++) {
        for (int j = 0; j < num; j++) {
            if (i != j && dist[i][j] != INF) {
                heuristic[i][j] = 1.0 / dist[i][j];
            }
        }
    }
    
    vector<int> bestTour;
    int bestLens = INF;
    
    for (int k = 0; k < MAX_ITERATIONS; k++) {
        vector<vector<int>> antTours(NUM_ANTS);
        vector<int> tourLens(NUM_ANTS, INF);
        
        for (int a = 0; a < NUM_ANTS; a++) {
            vector<bool> visited(num, false);
            antTours[a].push_back(startIdx);
            visited[startIdx] = true;
            int currCity = startIdx;
            bool check = false;
            
            for (int step = 1; step < num; step++) {
                vector<double> probChoice(num, 0.0);
                double res = 0.0;
                
                for (int nextCity = 0; nextCity < num; nextCity++) {
                    if (!visited[nextCity] && dist[currCity][nextCity] != INF) {
                        probChoice[nextCity] = pow(pheromone[currCity][nextCity], ALPHA) * pow(heuristic[currCity][nextCity], BETA);
                        res += probChoice[nextCity];
                    }
                }

                if (res == 0.0) {
                    check = true;
                    break;
                }

                double r = ((double)rand() / RAND_MAX) * res;
                double power = 0.0;
                int nextCity = -1;
                for (int i = 0; i < num; i++) {
                    if (probChoice[i] > 0) {
                        power += probChoice[i];
                        if (r <= power) {
                            nextCity = i;
                            break;
                        }
                    }
                }

                if (nextCity == -1) {
                    check = true;
                    break;
                }

                antTours[a].push_back(nextCity);
                visited[nextCity] = true;
                tourLens[a] = (tourLens[a] == INF ? 0 : tourLens[a]) + dist[currCity][nextCity];
                currCity = nextCity;
            }

            if (check || antTours[a].size() < num || dist[currCity][startIdx] == INF) {
                tourLens[a] = INF;
                continue;
            }

            tourLens[a] += dist[currCity][startIdx];

            if (tourLens[a] < bestLens) {
                bestLens = tourLens[a];
                bestTour = antTours[a];
            }
        }

        // Bay hơi pheromone
        for (int i = 0; i < num; i++)
            for (int j = 0; j < num; j++)
                pheromone[i][j] *= (1.0 - RHO);

        for (int a = 0; a < NUM_ANTS; a++) {
            if (tourLens[a] == INF) continue;
            double delta = Q / tourLens[a];
            for (int i = 0; i < antTours[a].size() - 1; i++) {
                int u = antTours[a][i];
                int v = antTours[a][i + 1];
                pheromone[u][v] += delta;
                pheromone[v][u] += delta;
            }
            int u = antTours[a].back();
            int v = startIdx;
            pheromone[u][v] += delta;
            pheromone[v][u] += delta;
        }
    }

    if (bestTour.empty()) return "No path found";

    string output = "";
    for (int i = 0; i < bestTour.size(); i++) {
        output += vertex[bestTour[i]];
        if (i + 1 < bestTour.size()) output += " ";
    }
    output += " ";
    output += startVertex;
    return output;
}

    // Thuật toán DP cho số đỉnh <= 20
    int totalStates = 1 << num;
    vector<vector<int>> dp(totalStates, vector<int>(num, INF));
    vector<vector<int>> prev(totalStates, vector<int>(num, -1));
    dp[1 << startIdx][startIdx] = 0;

    for (int state = 0; state < totalStates; state++) {
        for (int u = 0; u < num; u++){
            if ((state >> u & 1) == 0 || dp[state][u] == INF) continue;
            for (int v = 0; v < num; v++){
                if (state >> v & 1) continue;
                if (dist[u][v] == INF) continue;

                int next = state | (1 << v);
                int cost = dp[state][u] + dist[u][v];
                if (cost >= 0 && (dp[next][v] == INF || cost < dp[next][v])) {
                    dp[next][v] = cost;
                    prev[next][v] = u;
                }
            }
        }
    }

    int bestCost = INF, endCity = -1;
    int full = totalStates - 1;
    for (int i = 0; i < num; i++){
        if (i == startIdx || dist[i][startIdx] == INF || dp[full][i] == INF) continue;
        int totalCost = dp[full][i] + dist[i][startIdx];
        if (totalCost >= 0 && (bestCost == INF || totalCost < bestCost)) {
            bestCost = totalCost;
            endCity = i;
        }
    }

    if (bestCost == INF) {
        return "No path found";
    
    }

    vector<int> tour;
    reconstructPath(prev, full, endCity, tour);
    string output="";
    for (int i = 0; i < tour.size(); i++){
        output+= vertex[tour[i]];
        if (i + 1 < tour.size()) output+=" ";
    }
    output= output+ " "+ startVertex;
    return output;
}