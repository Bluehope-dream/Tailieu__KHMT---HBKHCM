#include "bellman.h"
#define INF 1e9
void initial(int edge[][3], int &numberOfEdges, vector<char>& vertexList, int& numVertices, char &startVertex, int& startIndex) {
  // Bước 1: Đánh dấu các đỉnh xuất hiện
    bool trans[256] = {false};
    for (int i = 0; i < numberOfEdges; i++) {
        trans[(unsigned char)edge[i][0]] = true;
        trans[(unsigned char)edge[i][1]] = true;
    }
   // Bước 2: Tạo danh sách đỉnh duy nhất và ánh xạ đỉnh thành chỉ số
    for (int c = 0; c < 256; c++) {
        if (trans[c]) vertexList.push_back((char)c);
    }
    numVertices = vertexList.size();
    for (int i = 0; i < numVertices - 1; i++) {
        for (int j = i + 1; j < numVertices; j++) {
            if (vertexList[i] > vertexList[j]) {
                char tempo = vertexList[i];
                vertexList[i] = vertexList[j];
                vertexList[j] = tempo;
            }
        }
    }
    // Tìm chỉ số của startVertex(đỉnh bắt đầu)
    startIndex = -1;
    for (int i = 0; i < numVertices; i++) {
        if (vertexList[i] == startVertex) {
            startIndex = i;
            break;
        }
    }
}
void BF(int edge[][3], int numberOfEdges, char startVertex, int BellmanFordValue[], int BellmanFordPrevious[]) {
    vector<char> vertexList;
    int numVertices;
    int pos;
    initial(edge,numberOfEdges,vertexList,numVertices, startVertex, pos);
    vector<int> indexVertex(256, -1);  //ánh xạ char thành int 
    for (int i = 0; i < numVertices; i++) {
        indexVertex[(unsigned char)vertexList[i]] = i;
    }
    if (pos == -1) {
        BellmanFordValue[pos] = 0;
        return;
    }
    if (BellmanFordValue[pos] == -1)
        BellmanFordValue[pos] = 0;
    vector<int> BFValCopy(numVertices);
    for (int i = 0; i < numVertices; i++) {
        BFValCopy[i] = BellmanFordValue[i];
    }

    // Vòng lặp chính Bellman-Ford
    for (int iter = 0; iter < numVertices - 1; iter++) {
        bool updated = false;
        for (int i = 0; i < numVertices; i++) {
            if (BFValCopy[i] == -1) continue;

            for (int e = 0; e < numberOfEdges; e++) {
                char uChar = edge[e][0];
                char vChar = edge[e][1];
                int w = edge[e][2];

                int u = indexVertex[(unsigned char)uChar];
                int v = indexVertex[(unsigned char)vChar];

                if (u == i) {
                    if (BellmanFordValue[v] == -1 || BellmanFordValue[v] > BFValCopy[i] + w) {
                        BellmanFordValue[v] = BFValCopy[i] + w;
                        BellmanFordPrevious[v] = i;
                        updated = true;
                    }
                }
            }
        }
        if(!updated) break;
    }
}
string BF_Path(int edge[][3], int numberOfEdges, char startVertex, char goalVertex) {
    vector<char> vertexList;
    int numVertices;
    int startIndex = -1;
    initial(edge, numberOfEdges, vertexList, numVertices, startVertex, startIndex);
    int goalIndex = -1;
    for (int i = 0; i < numVertices; i++) {
        if (vertexList[i] == goalVertex) {
            goalIndex = i;
            break;
        }
    }
    if (startIndex == -1 || goalIndex == -1) {          // Một trong hai đỉnh không tồn tại
        return "NO PATH";
    }
    int BellmanFordValue[100];
    int BellmanFordPrevious[100];
    for (int i = 0; i < numVertices; i++) {
        BellmanFordValue[i] = INF; 
        BellmanFordPrevious[i] = -1;
    }
    BellmanFordValue[startIndex] = 0;
    for (int iter = 0; iter < numVertices - 1; iter++) {
        BF(edge, numberOfEdges, startVertex, BellmanFordValue, BellmanFordPrevious);
    }
    if (BellmanFordValue[goalIndex] == -1) {
        return "NO PATH";
    }
    char pathList[100];
    int pathLength = 0;
    int cur = goalIndex;
    while (cur != -1) {
        pathList[pathLength++] = vertexList[cur];
        if (cur == startIndex) break;
        cur = BellmanFordPrevious[cur];
    }
    string path = "";
    for (int i = pathLength - 1; i >= 0; i--) {
        path += pathList[i];
        if (i > 0) path += ' ';
    }
    return path;
}
