x = [0, 0.2, 0.4, 0.6, 0.8, 1.0];
y = [0, 0.034, 0.120, 0.267, 0.500, 1.000];
x_nonzero = x(x > 0);
y_nonzero = y(x > 0);
f = fit(x_nonzero', y_nonzero', 'power1');
disp(f)
format long;
fprintf('a = %.10f\n', f.a); % Tham số a
fprintf('b = %.10f\n', f.b); % Tham số b
plot(x, y, 'o');
xlim([0,1]);
ylim([0,1]);
grid on;
hold on;
plot(f, x, y);
hold off;
xlabel('x');
ylabel('L(x)'); 
