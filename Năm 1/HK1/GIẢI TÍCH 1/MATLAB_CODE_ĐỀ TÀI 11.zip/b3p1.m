n = input('Nhập số cặp giá trị mà bạn muốn để tìm ra hàm Lorenz có dạng bậc hai : ');
x = zeros(1,n);
y = zeros(1,n);

for i = 1:n
    x(i) = input('Nhập tỷ lệ phần trăm dân số đang xét: ');
    y(i) = input('Nhập tỷ lệ phần trăm thu nhập tích lũy tương ứng của số dân đang xét : ');
end

% Tìm đa thức bậc 2 gần đúng cho dữ liệu (x,y)
p = polyfit(x,y,2);
% Tính giá trị của đa thức tại các điểm x
yfit = polyval(p,x);
% Hiển thị kết quả a,b,c tìm ra hàm bậc 2 biểu diễn hàm Lorenz trong năm
% đang xét
disp(['a = ', num2str(p(1))]);
disp(['b = ', num2str(p(2))]);
disp(['c = ', num2str(p(3))]);
