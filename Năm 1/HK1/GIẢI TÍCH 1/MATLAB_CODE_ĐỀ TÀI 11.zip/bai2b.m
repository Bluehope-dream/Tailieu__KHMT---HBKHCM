function limit = tinh_gioi_han(p, N)
   function an = calculate_an(n, p)
% This function calculates the value of a_n for the given sequence
%
% Input:
%   n: The index of the term in the sequence (positive integer)
%   p: The power in the sequence (positive real number)
%
% Output:
%   an: The value of the nth term in the sequence

% Calculate the sum of the series
sum_of_powers = sum(1:n).^p;

% Calculate the value of a_n
an = sum_of_powers / n^(p+1);

end