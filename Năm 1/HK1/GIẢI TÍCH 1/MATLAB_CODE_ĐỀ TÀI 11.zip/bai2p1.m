% Biểu diễn số liệu của bảng ở bài 2
x=[0 0.2 0.4 0.6 0.8 1.0 ];
y= [0 0.034 0.12 0.267 0.5 1];
plot(x,y,'--*r');
xlabel('x');
ylabel('L(x)');
xlim([-0.25 1.5])
ylim([-0.5 1.5])
grid on
hold on
% Vẽ đồ thị của hàm vừa mới tìm được để kt tính chất của nó
p = polyfit(x,y,2);
yfit = polyval(p,x);
hold on;
plot(x,yfit,'r')
% Tìm công thức của hàm
disp(['a = ', num2str(p(1))]);
disp(['b = ', num2str(p(2))]);
disp(['c = ', num2str(p(3))]);
