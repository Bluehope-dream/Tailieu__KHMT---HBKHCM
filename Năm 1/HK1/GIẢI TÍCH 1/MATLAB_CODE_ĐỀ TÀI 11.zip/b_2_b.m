function tinh_gioi_han_day_so(p)
    % Kiểm tra giá trị p
  while true
     if p > 0
        break;
     else
  p = input('Nhap lai gia tri cua p (p > 0): ');
        end
  end
    % Tính giới hạn dãy số bằng phương pháp giới hạn bằng phần mềm máy tính
    syms n k;
    f = k^p/(n^(p+1));
    a_n = symsum(f, k, 1, n);
    a_n_limit = limit(a_n, n, inf);
    % Tính giới hạn dãy số bằng phương pháp tích phân
    limit_a_n_tichphan = tinh_gioi_han_bang_ph_tich_phan(p);

a_n_limit_check = double(a_n_limit);

% Hiển thị kết quả
disp(['Giới hạn của dãy số khi n -> inf (tính bằng tổng): ', num2str(a_n_limit_check)]);
disp(['Giới hạn của dãy số khi n -> inf (tính bằng tích phân): ', num2str(limit_a_n_tichphan)]);
    if abs(a_n_limit - limit_a_n_tichphan) < 1e-10
        disp('Hai kết quả gần bằng nhau, phương pháp tính bằng tích phân là chính xác.');
    else
        disp('Có sự sai khác giữa hai kết quả.');
    end
end

% Hàm tính giới hạn bằng tích phân
function limit_a_n = tinh_gioi_han_bang_ph_tich_phan(p)
    limit_a_n = 1 / (p + 1);
end

% Cần nhập giá trị p để khảo sát tính đúng đắn của kết quả 
p = input('Nhap gia tri cua p (p > 0): ');
tinh_gioi_han_day_so(p);
