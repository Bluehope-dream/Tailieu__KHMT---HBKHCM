% Định nghĩa từng thành phần biến và chỉ số
syms n k;
% Định nghĩa dãy số cần tính giới hạn
f = 1/(n+k);
Gioi_han_day_so = limit(symsum(f, k, 1, n), n, inf);
%Trình bày kết quả phép toán 
disp('Giới hạn của dãy số khi n tiến tới vô cùng là ')
disp(Gioi_han_day_so);