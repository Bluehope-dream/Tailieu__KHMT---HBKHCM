import numpy as np
import sympy as sp
import matplotlib.pyplot as plt
import matplotlib.animation as animation
import matplotlib.cm as cm

# Hàm nhập giá trị từ người dùng
def get_positive_float_input(prompt, default_value):
    while True:
        try:
            user_input = input(f"{prompt} (Mặc định là {default_value}): ")
            if user_input == "":
                return default_value
            value = float(user_input)
            if value > 0:
                return value
            else:
                print("Giá trị phải dương. Vui lòng nhập lại.")
        except ValueError:
            print("Giá trị không hợp lệ. Vui lòng nhập lại.")

# Nhập các tham số từ người dùng
m = get_positive_float_input("Nhập khối lượng vật thể (kg)", 1.0)  # Khối lượng vật thể
h = get_positive_float_input("Nhập hệ số cản môi trường", 0.5)  # Hệ số cản môi trường
v0 = get_positive_float_input("Nhập vận tốc ban đầu (m/s)", 40)  # Vận tốc ban đầu
g = get_positive_float_input("Nhập gia tốc trọng trường (m/s^2)", 9.81)  # Gia tốc trọng trường

# Nhập các góc phóng (độ)
theta_values_input = input("Nhập các góc phóng (độ) cách nhau bằng dấu cách (mặc định: 15 30 45 60 75): ")
if not theta_values_input.strip():
    theta_values = [15, 30, 45, 60, 75]
else:
    theta_values = [float(angle) for angle in theta_values_input.split()]

# Nhập thời gian bay
manual_flight_time = get_positive_float_input("Nhập thời gian bay (giây) ", 6.0)

# Màu sắc cho các vệt chuyển động (sử dụng bảng màu gradient)
colors = cm.rainbow(np.linspace(0, 1, len(theta_values)))

# Các biến x(t) và y(t) tượng trưng cho vị trí theo thời gian
t = sp.symbols('t')  # Thời gian
x = sp.Function('x')(t)
y = sp.Function('y')(t)

# Mảng để lưu trữ các phương trình vị trí và nghiệm
x_equations = []
y_equations = []

# Danh sách để lưu trữ các quỹ đạo và thời gian bay
trajectories = []

# Danh sách để lưu trữ điểm cao nhất và điểm cuối của quỹ đạo
max_height_points = []
landing_points = []

# Giải phương trình cho từng góc
for angle in theta_values:
    # Chuyển góc sang radian
    theta_rad = np.radians(angle)
    
    # Vận tốc ban đầu theo các phương
    vx0 = v0 * np.cos(theta_rad)  # Vận tốc theo phương ngang
    vy0 = v0 * np.sin(theta_rad)  # Vận tốc theo phương dọc
    
    # Phương trình vi phân cho chuyển động theo x và y
    eq1 = sp.Eq(sp.diff(x, t), vx0 * sp.exp(-h/m * t))  # Phương trình chuyển động theo x
    eq2 = sp.Eq(sp.diff(y, t), vy0 * sp.exp(-h/m * t) - (m*g/h) * (1 - sp.exp(-h/m * t)))  # Phương trình chuyển động theo y
    
    # Giải phương trình vi phân
    sol_x = sp.dsolve(eq1, ics={x.subs(t, 0): 0})
    sol_y = sp.dsolve(eq2, ics={y.subs(t, 0): 0})

    # Lưu trữ kết quả
    x_equations.append(sol_x)
    y_equations.append(sol_y)

    # Chuyển đổi phương trình thành hàm số để tính giá trị
    f_x = sp.lambdify(t, sol_x.rhs, 'numpy')
    f_y = sp.lambdify(t, sol_y.rhs, 'numpy')
    
    # Tạo mảng thời gian để vẽ đồ thị (tăng độ phân giải)
    t_vals = np.linspace(0, manual_flight_time, 300)  # Tạo mảng thời gian với độ phân giải cao hơn
    x_vals = f_x(t_vals)  # Tính giá trị x tại các thời điểm
    y_vals = f_y(t_vals)  # Tính giá trị y tại các thời điểm
    
    # Lưu trữ quỹ đạo
    trajectories.append((x_vals, y_vals))
    
    # Tìm điểm cao nhất và điểm cuối của quỹ đạo
    max_height_idx = np.argmax(y_vals)
    max_height_points.append((x_vals[max_height_idx], y_vals[max_height_idx]))
    landing_points.append((x_vals[-1], y_vals[-1]))

# Tạo figure với bố cục 1 cột và 1 hàng
fig, ax = plt.subplots(figsize=(10, 8))

# Thiết lập giới hạn trục cho quỹ đạo
x_max = max([np.max(x) for x, y in trajectories])
y_max = max([np.max(y) for x, y in trajectories])

ax.set_xlim(0, x_max + 5)
ax.set_ylim(min([np.min(y) for x, y in trajectories]) - 5, y_max + 5)

# Tạo các đường đồ thị rỗng cho quỹ đạo
trajectory_lines = [ax.plot([], [], color=colors[i], lw=2, label=f'Góc {theta_values[i]}°')[0] for i in range(len(theta_values))]

# Tạo các đối tượng Line2D cho vệt chuyển động mờ (alpha thấp)
trail_lines = [ax.plot([], [], color=colors[i], alpha=0.3)[0] for i in range(len(theta_values))]

# Tạo đối tượng văn bản để hiển thị đồng hồ thời gian (chỉ một hàng, màu đen)
time_text = ax.text(0.99, 0.75, "", color='black', transform=ax.transAxes, ha='right', fontsize=13)

# Các biến để lưu trữ các điểm đánh dấu và văn bản
scatters = []
texts = []

# Hàm animation: cập nhật đồ thị cho quỹ đạo và đồng hồ
def animate(i):
    artists = []
    # Cập nhật các quỹ đạo
    for j in range(len(theta_values)):
        x_vals, y_vals = trajectories[j]
        t_current = t_vals[min(i, len(t_vals)-1)]
        
        trajectory_lines[j].set_data(x_vals[:min(i+1, len(t_vals))], y_vals[:min(i+1, len(t_vals))])
        trail_lines[j].set_data(x_vals[:min(i+1, len(t_vals))], y_vals[:min(i+1, len(t_vals))])
        artists.extend([trajectory_lines[j], trail_lines[j]])

    # Cập nhật đồng hồ thời gian 
    time_text.set_text(f"t = {t_current:.2f} s")
    artists.append(time_text)

    # Hiển thị các điểm cao nhất và điểm cuối khi hoạt ảnh kết thúc
    if i == len(t_vals):
        for j in range(len(theta_values)):
            scatter = ax.scatter(*max_height_points[j], color=colors[j], edgecolors='black', zorder=5, s=15, linewidths=0.2)
            text = ax.text(max_height_points[j][0], max_height_points[j][1], f"({max_height_points[j][0]:.1f}, {max_height_points[j][1]:.1f})", fontsize=8, color='black', ha='left',va='bottom')
            scatters.append(scatter)
            texts.append(text)
            scatter = ax.scatter(*landing_points[j], color=colors[j], edgecolors='black', zorder=5, s=15, linewidths=0.2)
            text = ax.text(landing_points[j][0], landing_points[j][1], f"({landing_points[j][0]:.1f}, {landing_points[j][1]:.1f})", fontsize=8, color='black', ha='left',va= 'bottom')
            scatters.append(scatter)
            texts.append(text)
        time_text.set_text(f"t = {manual_flight_time:.2f} s")

    return artists + scatters + texts

# Hàm khởi tạo: tạo ra đồ thị trống khi bắt đầu animation
def init():
    for line in trajectory_lines + trail_lines:
        line.set_data([], [])
    time_text.set_text('')
    return trajectory_lines + trail_lines + [time_text]

# Tạo animation
ani = animation.FuncAnimation(fig, animate, frames=800, init_func=init, interval=5,blit=True,repeat=False)

# Thiết lập nhãn và tiêu đề cho quỹ đạo
ax.grid(True, which='both', axis='both', color='gray', linestyle='--', linewidth=0.5, alpha=0.7)
ax.set_xlabel('x(t) (m)', fontsize=12)
ax.set_ylabel('y(t) (m)', fontsize=12)
ax.set_title('Quỹ Đạo Chuyển Động Ném Xiên Trong Trọng Trường Có Lực Cản Môi Trường', fontsize=14, weight='bold')

# Thêm thông số người dùng nhập ban đầu
props = dict(boxstyle='round', facecolor='white', alpha=0.8)
ax.text(0.01, 0.09, 
        f"Khối lượng: {m} kg\nHệ số cản: {h}\n"
        f"Vận tốc ban đầu: {v0} m/s\nGia tốc trọng trường: {g} m/s²", 
        transform=ax.transAxes, fontsize=11, color='black', bbox=props)

# Thêm chú thích
ax.legend(loc='upper right')

# Hiển thị đồ thị
plt.tight_layout()
plt.show()
