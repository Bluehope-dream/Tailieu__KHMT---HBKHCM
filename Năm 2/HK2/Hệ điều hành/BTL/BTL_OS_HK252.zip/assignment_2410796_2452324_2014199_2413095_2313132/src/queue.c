#include <stdio.h>
#include <stdlib.h>
#include "queue.h"

int empty(struct queue_t *q)
{
    if (q == NULL) // kiểm tra nếu con trỏ hàng đợi bị rỗng (chưa được cấp phát)
        return 1; 
    return (q->size == 0); // trả về 1 nếu số lượng phần tử bằng 0, ngược lại trả về
}

void enqueue(struct queue_t *q, struct pcb_t *proc)
{
    /* TODO: put a new process to queue [q] */
    if (q == NULL || q->size >= MAX_QUEUE_SIZE) {
        return;
    }

    int idx = q->size; // lấy ví trí trống ở ngay cuối mảng làm mốc
    while (idx > 0) { // vòng lặp dồn hàng : chạy lùi từ cuối mảng về đầu mảng
        q->proc[idx] = q->proc[idx - 1]; // kéo phần tử đứng trước lùi về phía sau 1 ô 
        idx--; // goảm vị trí xuống để kéo tiếp người phía trước
    }

    q->proc[0] = proc; // thêm process vào vị trí đầu tiên (0) vừa được làm trông
    q->size++; // tăng số lượng 
}

struct pcb_t *dequeue(struct queue_t *q)
{
    /* TODO: return a pcb whose prioprity is the highest
     * in the queue [q] and remember to remove it from q
     * */
    if (empty(q)) { // nếu hàng đang trống thì trả về NULL
        return NULL;
    }

    q->size--; // giảm số lượng đi 1 (lúc này q->size chính là vị trí của người cũ nhất ở cuối hàng)
    struct pcb_t *oldest_proc = q->proc[q->size]; // lấy process ở vị trí cuối cùng ra

    q->proc[q->size] = NULL; // xóa sạch dấu vết của process vừa lấy ra để an toàn bộ nhớ

    return oldest_proc; // trả về process lấy được cho CPU xử lý
}

struct pcb_t *purgequeue(struct queue_t *q, struct pcb_t *proc)
{
    /* TODO: remove a specific item from queue
     * */
    if (empty(q) || proc == NULL) { // nếu hàm rỗng hoặc process truyền vào bị lỗi
        return NULL;
    }

    int target_idx = -1; // biến lưu vị trí cần tìm

    for (int i = 0; i < q->size; i++) {
        if (q->proc[i] == proc) {
            target_idx = i; // tìm thấy thì đánh dấu vị trí lại
            break;
        }
    }

    if (target_idx == -1) { // nếu không tìm thấy trong hàng
        return NULL;
    }

    for (int i = target_idx; i < q->size - 1; i++) { // dồn những vị trí đứng sau vị trí cần tìm lên 1 bước
        q->proc[i] = q->proc[i + 1];
    }

    q->size--; // giảm tổng số phần tử của hàng đợi đi 1
    q->proc[q->size] = NULL; // xóa rác ở phần tử cuối cùng sau khi mảng đã dồn lên

    return proc; // trả về process đã bị xóa
}