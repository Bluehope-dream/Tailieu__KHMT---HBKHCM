/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

#include "os-mm.h"
#include "syscall.h"
#include "libmem.h"
#include "queue.h"
#include <stdlib.h>

#ifdef MM64
#include "mm64.h"
#else
#include "mm.h"
#endif

extern int pg_getval(struct mm_struct *mm, addr_t addr, BYTE *data, struct pcb_t *caller);
extern int pg_setval(struct mm_struct *mm, addr_t addr, BYTE value, struct pcb_t *caller);
//typedef char BYTE;

int __sys_memmap(struct krnl_t *krnl, uint32_t pid, struct sc_regs* regs)
{
   int memop = regs->a1;
   BYTE value;
   struct pcb_t *caller = NULL;

   /* Traverse running_list to find the corresponding process by PID */
   struct queue_t *running_list = krnl->running_list;
   if (running_list != NULL) {
       for (int i = 0; i < running_list->size; i++) {
           if (running_list->proc[i] != NULL && running_list->proc[i]->pid == pid) {
               caller = running_list->proc[i];
               break;
           }
       }
   }

   /* If process not found in running list, abort */
   if (caller == NULL) {
       return -1;
   }

   /* Route the memory operation to the appropriate kernel space function */
   switch (memop) {
   case SYSMEM_MAP_OP:
            vmap_pgd_memset(caller, regs->a2, regs->a3);
            break;
   case SYSMEM_INC_OP:
            inc_vma_limit(caller, regs->a2, regs->a3);
            break;
   case SYSMEM_SWP_OP:
            __mm_swap_page(caller, regs->a2, regs->a3);
            break;
   case SYSMEM_IO_READ:
        if (pg_getval(caller->mm, regs->a2, &value, caller) == 0) {
            regs->a3 = value; 
        } else {
            return -1; 
        }
        break;
   case SYSMEM_IO_WRITE:
        if (pg_setval(caller->mm, regs->a2, (BYTE)regs->a3, caller) != 0) {
            return -1;
        }
        break;
   default:
            return -1;
   }
   return 0;
}


