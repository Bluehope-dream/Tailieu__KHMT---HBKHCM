/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

// #ifdef MM_PAGING
/*
 * PAGING based Memory Management
 * Memory physical module mm/mm-memphy.c
 */

#include "mm.h"
#ifdef MM64
#include "mm64.h"
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*
 *  MEMPHY_mv_csr - move MEMPHY cursor
 *  @mp: memphy struct
 *  @offset: offset
 */
int MEMPHY_mv_csr(struct memphy_struct *mp, addr_t offset)
{
   int numstep = 0;

   mp->cursor = 0;
   while (numstep < offset && numstep < mp->maxsz)
   {
      /* Traverse sequentially */
      mp->cursor = (mp->cursor + 1) % mp->maxsz;
      numstep++;
   }

   return 0;
}

/*
 *  MEMPHY_seq_read - read MEMPHY device
 *  @mp: memphy struct
 *  @addr: address
 *  @value: obtained value
 */
int MEMPHY_seq_read(struct memphy_struct *mp, addr_t addr, BYTE *value)
{
   if (mp == NULL || mp->storage == NULL)
      return -1;

   if (!mp->rdmflg)
      return -1; 

   *value = mp->storage[addr];
   return 0;
}

/*
 *  MEMPHY_read read MEMPHY device
 *  @mp: memphy struct
 *  @addr: address
 *  @value: obtained value
 */
int MEMPHY_read(struct memphy_struct * mp, addr_t addr, BYTE *value)
{
   if (mp == NULL || mp->storage == NULL || addr >= mp->maxsz)
      return -1;

   if (mp->rdmflg) {
      *value = mp->storage[addr];
   } else {
      addr_t offset = (addr >= mp->cursor) ? (addr - mp->cursor) : (mp->maxsz - mp->cursor + addr);
      MEMPHY_mv_csr(mp, offset);
      *value = mp->storage[addr];
   }

   return 0;
}

/*
 *  MEMPHY_seq_write - write MEMPHY device
 *  @mp: memphy struct
 *  @addr: address
 *  @data: written data
 */
// int MEMPHY_seq_write(struct memphy_struct *mp, addr_t addr, BYTE value)
// {

//    if (mp == NULL)
//       return -1;

//    if (!mp->rdmflg)
//       return -1; /* Not compatible mode for sequential read */

//    MEMPHY_mv_csr(mp, addr);
//    mp->storage[addr] = value;

//    return 0;
// }

/*
 *  MEMPHY_write-write MEMPHY device
 *  @mp: memphy struct
 *  @addr: address
 *  @data: written data
 */
int MEMPHY_write(struct memphy_struct * mp, addr_t addr, BYTE data)
{
   if (mp == NULL || mp->storage == NULL || addr >= mp->maxsz)
      return -1;

   if (mp->rdmflg) {
      mp->storage[addr] = data;
   } else {
      addr_t offset = (addr >= mp->cursor) ? (addr - mp->cursor) : (mp->maxsz - mp->cursor + addr);
      MEMPHY_mv_csr(mp, offset);
      mp->storage[addr] = data;
   }

   return 0;
}

/*
 *  MEMPHY_format-format MEMPHY device
 *  @mp: memphy struct
 */
int MEMPHY_format(struct memphy_struct *mp, int pagesz)//chia khối bộ nhớ thành các frame bằng nhau, rồi ấy lại thành linkedlist các frame trống
{
   /* This setting come with fixed constant PAGESZ */
   int numfp = mp->maxsz / pagesz;
   struct framephy_struct *newfst, *fst;
   int iter = 0;

   if (numfp <= 0)
      return -1;

   /* Init head of free framephy list */
   fst = malloc(sizeof(struct framephy_struct));
   fst->fpn = iter;
   mp->free_fp_list = fst;

   /* We have list with first element, fill in the rest num-1 element member*/
   for (iter = 1; iter < numfp; iter++)
   {
      newfst = malloc(sizeof(struct framephy_struct));
      newfst->fpn = iter;
      newfst->fp_next = NULL;
      fst->fp_next = newfst;
      fst = newfst;
   }

   return 0;
}

int MEMPHY_get_freefp(struct memphy_struct *mp, addr_t *retfpn)
{
   struct framephy_struct *fp = mp->free_fp_list;

   /* Nếu danh sách khung trang trống đã cạn (Out of memory) */
   if (fp == NULL)
      return -1; 

   /* Rút khung trang ở đầu danh sách trống */
   *retfpn = fp->fpn;
   mp->free_fp_list = fp->fp_next;

   /* Đưa khung trang này sang danh sách Đang sử dụng (used_fp_list) 
    * để hệ thống không bị rò rỉ bộ nhớ (memory leak) */
   fp->fp_next = mp->used_fp_list;
   mp->used_fp_list = fp;

   return 0;
}

int MEMPHY_dump(struct memphy_struct *mp)
{
  /*TODO dump memphy contnt mp->storage
   *     for tracing the memory content
   */
   if (mp == NULL || mp->storage == NULL)
      return -1;

   printf("--- DUMP PHYSICAL MEMORY ---\n");
   int i;
   int count = 0;
   for (i = 0; i < mp->maxsz; i++)
   {
      if (mp->storage[i] != 0)
      {
         printf("MEM[%08x] = %02x\n", i, (unsigned char)mp->storage[i]);
         count++;
      }
   }
   if (count == 0) {
       printf("Memory is empty.\n");
   }
   printf("----------------------------\n");
   return 0;
}

int MEMPHY_put_freefp(struct memphy_struct *mp, addr_t fpn)
{
   struct framephy_struct *fp = mp->used_fp_list;
   struct framephy_struct *prev = NULL;

   /* Tìm node chứa fpn đang được sử dụng */
   while (fp != NULL && fp->fpn != fpn) {
       prev = fp;
       fp = fp->fp_next;
   }

   /* Nếu tìm thấy, gỡ nó khỏi used_fp_list và đẩy vào free_fp_list */
   if (fp != NULL) {
       if (prev == NULL) {
           mp->used_fp_list = fp->fp_next;
       } else {
           prev->fp_next = fp->fp_next;
       }

       fp->fp_next = mp->free_fp_list;
       mp->free_fp_list = fp;
       return 0;
   }

   /* Nếu không tìm thấy, tạo node mới nạp vào free_fp_list */
   struct framephy_struct *newnode = malloc(sizeof(struct framephy_struct));
   newnode->fpn = fpn;
   newnode->fp_next = mp->free_fp_list;
   mp->free_fp_list = newnode;

   return 0;
}

/*
 *  Init MEMPHY struct
 */
int init_memphy(struct memphy_struct *mp, addr_t max_size, int randomflg)
{
   mp->storage = (BYTE *)malloc(max_size * sizeof(BYTE));
   memset(mp->storage, 0, max_size * sizeof(BYTE));
   mp->maxsz = max_size;

#ifdef MM64
   MEMPHY_format(mp, PAGING64_PAGESZ);
#else
   MEMPHY_format(mp, PAGING_PAGESZ);
#endif

   mp->rdmflg = randomflg;
   if (!randomflg)
      mp->cursor = 0;

   return 0;
}

// #endif
