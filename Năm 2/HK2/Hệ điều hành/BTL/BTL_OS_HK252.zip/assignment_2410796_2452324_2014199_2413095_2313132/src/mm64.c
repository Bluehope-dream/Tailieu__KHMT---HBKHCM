/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* LamiaAtrium release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

/*
 * PAGING based Memory Management
 * Memory management unit mm/mm.c
 */

#include "mm64.h"
#include <stdlib.h>
#include <stdint.h>
#include <stdio.h>
#include <time.h>
#include <stdlib.h>

#if defined(MM64)

/*
 * init_pte - Initialize PTE entry
 */
int init_pte(addr_t *pte,
             int pre,    // present
             addr_t fpn,    // FPN
             int drt,    // dirty
             int swp,    // swap
             int swptyp, // swap type
             addr_t swpoff) // swap offset
{
  if (pre != 0) {
    if (swp == 0) { 
      SETBIT(*pte, PAGING_PTE_PRESENT_MASK); 
      CLRBIT(*pte, PAGING_PTE_SWAPPED_MASK);
      CLRBIT(*pte, PAGING_PTE_DIRTY_MASK); 
      SETVAL(*pte, fpn, PAGING_PTE_FPN_MASK, PAGING_PTE_FPN_LOBIT); 
    }
    else
    { // page swapped
      SETBIT(*pte, PAGING_PTE_PRESENT_MASK); 
      SETBIT(*pte, PAGING_PTE_SWAPPED_MASK); 
      CLRBIT(*pte, PAGING_PTE_DIRTY_MASK);
 
      SETVAL(*pte, swptyp, PAGING_PTE_SWPTYP_MASK, PAGING_PTE_SWPTYP_LOBIT);
      SETVAL(*pte, swpoff, PAGING_PTE_SWPOFF_MASK, PAGING_PTE_SWPOFF_LOBIT);
    }
  }
 
  return 0;
}


/*
 * get_pd_from_pagenum - Parse address to 5 page directory level
 * @pgn   : pagenumer
 * @pgd   : page global directory
 * @p4d   : page level directory
 * @pud   : page upper directory
 * @pmd   : page middle directory
 * @pt    : page table 
 */
int get_pd_from_address(addr_t addr, addr_t* pgd, addr_t* p4d, addr_t* pud, addr_t* pmd, addr_t* pt)
{
	/* Extract page direactories */
	*pgd = PAGING64_ADDR_PGD(addr);
  *p4d = PAGING64_ADDR_P4D(addr);
  *pud = PAGING64_ADDR_PUD(addr);
  *pmd = PAGING64_ADDR_PMD(addr);
  *pt  = PAGING64_ADDR_PT(addr);

	/* TODO: implement the page direactories mapping */

	return 0;
}

/*
 * get_pd_from_pagenum - Parse page number to 5 page directory level
 * @pgn   : pagenumer
 * @pgd   : page global directory
 * @p4d   : page level directory
 * @pud   : page upper directory
 * @pmd   : page middle directory
 * @pt    : page table 
 */
int get_pd_from_pagenum(addr_t pgn, addr_t* pgd, addr_t* p4d, addr_t* pud, addr_t* pmd, addr_t* pt)
{
	/* Shift the address to get page num and perform the mapping*/
	return get_pd_from_address(pgn << PAGING64_ADDR_PT_SHIFT,
                         pgd,p4d,pud,pmd,pt);
}


/*
 * pte_set_swap - Set PTE entry for swapped page
 * @pte    : target page table entry (PTE)
 * @swptyp : swap type
 * @swpoff : swap offset
 */
int pte_set_swap(struct pcb_t *caller, addr_t pgn, int swptyp, addr_t swpoff)
{
//struct krnl_t *krnl = caller->krnl;

  addr_t pte;
  pte = pte_get_entry(caller, pgn);
  
  SETBIT(pte, PAGING_PTE_PRESENT_MASK);
  SETBIT(pte, PAGING_PTE_SWAPPED_MASK);
  
  SETVAL(pte, swptyp, PAGING_PTE_SWPTYP_MASK, PAGING_PTE_SWPTYP_LOBIT);
  SETVAL(pte, swpoff, PAGING_PTE_SWPOFF_MASK, PAGING_PTE_SWPOFF_LOBIT);
  
  pte_set_entry(caller, pgn, pte);
  
  return 0;
}

/*
 * pte_set_fpn - Set PTE entry for on-line page
 * @pte   : target page table entry (PTE)
 * @fpn   : frame page number (FPN)
 */
int pte_set_fpn(struct pcb_t *caller, addr_t pgn, addr_t fpn)
{
  addr_t pte = pte_get_entry(caller, pgn);
  
  // if (PAGING_PAGE_PRESENT(pte)) {
  //   SETVAL(pte, fpn, PAGING_PTE_FPN_MASK, PAGING_PTE_FPN_LOBIT);
  //   pte_set_entry(caller, pgn, pte);
  //   return 0;
  // }
  
  // return -1;


  SETBIT(pte, PAGING_PTE_PRESENT_MASK);   // ✅ Bật PRESENT
  CLRBIT(pte, PAGING_PTE_SWAPPED_MASK);   // ✅ Xóa cờ SWAP
  SETVAL(pte, fpn, PAGING_PTE_FPN_MASK, PAGING_PTE_FPN_LOBIT); // ✅ Set FPN
  
  return pte_set_entry(caller, pgn, pte);
}


/* Get PTE page table entry
 * @caller : caller
 * @pgn    : page number
 * @ret    : page table entry
 **/
uint32_t pte_get_entry(struct pcb_t *caller, addr_t pgn)
{
//struct krnl_t *krnl = caller->krnl;
  addr_t addr = pgn << PAGING64_ADDR_PT_SHIFT;
  addr_t pgd_idx, p4d_idx, pud_idx, pmd_idx, pt_idx;
  
  get_pd_from_address(addr, &pgd_idx, &p4d_idx, &pud_idx, &pmd_idx, &pt_idx);

  if (caller->mm->pgd == NULL) return 0;
  
  addr_t *p4d = (addr_t *)caller->mm->pgd[pgd_idx];
  if (p4d == NULL) return 0;

  addr_t *pud = (addr_t *)p4d[p4d_idx];
  if (pud == NULL) return 0;

  addr_t *pmd = (addr_t *)pud[pud_idx];
  if (pmd == NULL) return 0;

  addr_t *pt = (addr_t *)pmd[pmd_idx];
  if (pt == NULL) return 0;

  return (uint32_t)pt[pt_idx];
}

/* Set PTE page table entry
 * @caller : caller
 * @pgn    : page number
 * @ret    : page table entry
 **/
int pte_set_entry(struct pcb_t *caller, addr_t pgn, uint32_t pte_val)
{
	addr_t addr = pgn << PAGING64_ADDR_PT_SHIFT;
  addr_t pgd_idx, p4d_idx, pud_idx, pmd_idx, pt_idx;
  
  get_pd_from_address(addr, &pgd_idx, &p4d_idx, &pud_idx, &pmd_idx, &pt_idx);

  if (caller->mm->pgd == NULL) return -1;
  
  addr_t *p4d = (addr_t *)caller->mm->pgd[pgd_idx];
  if (p4d == NULL) return -1;

  addr_t *pud = (addr_t *)p4d[p4d_idx];
  if (pud == NULL) return -1;

  addr_t *pmd = (addr_t *)pud[pud_idx];
  if (pmd == NULL) return -1;

  addr_t *pt = (addr_t *)pmd[pmd_idx];
  if (pt == NULL) return -1;

  pt[pt_idx] = (addr_t)pte_val;
  return 0;
}


/*
 * vmap_pgd_memset - map a range of page at aligned address
 */
int vmap_pgd_memset(struct pcb_t *caller, addr_t addr, int pgnum)
{
  int pgit = 0;
  uint64_t pattern = 0xdeadbeef;
  addr_t pgn;

  for (pgit = 0; pgit < pgnum; pgit++) {
      pgn = (addr >> PAGING64_ADDR_PT_SHIFT) + pgit;
      
      addr_t pgd_idx, p4d_idx, pud_idx, pmd_idx, pt_idx;
      get_pd_from_pagenum(pgn, &pgd_idx, &p4d_idx, &pud_idx, &pmd_idx, &pt_idx);

      if (caller->mm->pgd == NULL) 
          caller->mm->pgd = calloc(512, sizeof(addr_t));
      
      addr_t *p4d = (addr_t *)caller->mm->pgd[pgd_idx];
      if (p4d == NULL) {
          p4d = calloc(512, sizeof(addr_t));
          caller->mm->pgd[pgd_idx] = (addr_t)p4d;
      }

      addr_t *pud = (addr_t *)p4d[p4d_idx];
      if (pud == NULL) {
          pud = calloc(512, sizeof(addr_t));
          p4d[p4d_idx] = (addr_t)pud;
      }

      addr_t *pmd = (addr_t *)pud[pud_idx];
      if (pmd == NULL) {
          pmd = calloc(512, sizeof(addr_t));
          pud[pud_idx] = (addr_t)pmd;
      }

      addr_t *pt = (addr_t *)pmd[pmd_idx];
      if (pt == NULL) {
          pt = calloc(512, sizeof(addr_t));
          pmd[pmd_idx] = (addr_t)pt;
      }

      /* Set dummy pattern cho page table entry */
      pt[pt_idx] = pattern;
  }
  return 0;
}

/*
 * vmap_page_range - map a range of page at aligned address
 */
addr_t vmap_page_range(struct pcb_t *caller, addr_t addr, int pgnum, 
                       struct framephy_struct *frames, struct vm_rg_struct *ret_rg)
{
  struct framephy_struct *fpit = frames;
  int pgit = 0;
  addr_t pgn;

  ret_rg->rg_start = addr;
  ret_rg->rg_end = addr + pgnum * PAGING64_PAGESZ;
  ret_rg->vmaid = 0;

  for (pgit = 0; pgit < pgnum; pgit++) {
      pgn = (addr >> PAGING64_ADDR_PT_SHIFT) + pgit;
      
      addr_t pgd_idx, p4d_idx, pud_idx, pmd_idx, pt_idx;
      get_pd_from_pagenum(pgn, &pgd_idx, &p4d_idx, &pud_idx, &pmd_idx, &pt_idx);

      if (caller->mm->pgd == NULL) 
          caller->mm->pgd = calloc(512, sizeof(addr_t));
      
      addr_t *p4d = (addr_t *)caller->mm->pgd[pgd_idx];
      if (p4d == NULL) {
          p4d = calloc(512, sizeof(addr_t));
          caller->mm->pgd[pgd_idx] = (addr_t)p4d;
      }

      addr_t *pud = (addr_t *)p4d[p4d_idx];
      if (pud == NULL) {
          pud = calloc(512, sizeof(addr_t));
          p4d[p4d_idx] = (addr_t)pud;
      }

      addr_t *pmd = (addr_t *)pud[pud_idx];
      if (pmd == NULL) {
          pmd = calloc(512, sizeof(addr_t));
          pud[pud_idx] = (addr_t)pmd;
      }

      addr_t *pt = (addr_t *)pmd[pmd_idx];
      if (pt == NULL) {
          pt = calloc(512, sizeof(addr_t));
          pmd[pmd_idx] = (addr_t)pt;
      }

      /* Lấy khung trang vật lý và ghi xuống PTE */
      addr_t pte = 0;
      if (fpit != NULL) {
          init_pte(&pte, 1, fpit->fpn, 0, 0, 0, 0); // Present = 1, Swap = 0
          fpit = fpit->fp_next;
      }
      pt[pt_idx] = pte;

      enlist_pgn_node(&caller->mm->fifo_pgn, pgn);
  }

  return 0;
}                                         


/*
 * alloc_pages_range - allocate req_pgnum of frame in ram
 * @caller    : caller
 * @req_pgnum : request page num
 * @frm_lst   : frame list
 */

addr_t alloc_pages_range(struct pcb_t *caller, int req_pgnum, struct framephy_struct **frm_lst)
{
  addr_t fpn;
  int pgit;
  struct framephy_struct *head = NULL;
  struct framephy_struct *tail = NULL;

  for (pgit = 0; pgit < req_pgnum; pgit++)
  {
    /* Lấy 1 khung trang trống từ thiết bị RAM của kernel */
    if (MEMPHY_get_freefp(caller->krnl->mram, &fpn) == 0)
    {
       struct framephy_struct *newfp = malloc(sizeof(struct framephy_struct));
       newfp->fpn = fpn;
       newfp->fp_next = NULL;
       
       if (head == NULL) {
           head = newfp;
           tail = newfp;
       } else {
           tail->fp_next = newfp;
           tail = newfp;
       }
    }
    else
    { 
       /* Hết bộ nhớ (Out of Memory) */
       *frm_lst = head;
       return -3000;
    }
  }
  
  *frm_lst = head;
  return 0;
}

/*
 * vm_map_ram - do the mapping all vm are to ram storage device
 * @caller    : caller
 * @astart    : vm area start
 * @aend      : vm area end
 * @mapstart  : start mapping point
 * @incpgnum  : number of mapped page
 * @ret_rg    : returned region
 */
addr_t vm_map_ram(struct pcb_t *caller, addr_t astart, addr_t aend, addr_t mapstart, int incpgnum, struct vm_rg_struct *ret_rg)
{
  struct framephy_struct *frm_lst = NULL;
  addr_t ret_alloc = 0;

  ret_alloc = alloc_pages_range(caller, incpgnum, &frm_lst);

  if (ret_alloc < 0 && ret_alloc != -3000)
    return -1;

  /* Out of memory */
  if (ret_alloc == -3000)
  {
    return -1;
  }
  vmap_page_range(caller, mapstart, incpgnum, frm_lst, ret_rg);

  return 0;
}

/* Swap copy content page from source frame to destination frame
 * @mpsrc  : source memphy
 * @srcfpn : source physical page number (FPN)
 * @mpdst  : destination memphy
 * @dstfpn : destination physical page number (FPN)
 **/
int __swap_cp_page(struct memphy_struct *mpsrc, addr_t srcfpn,
                   struct memphy_struct *mpdst, addr_t dstfpn)
{
  int cellidx;
  addr_t addrsrc, addrdst;
  for (cellidx = 0; cellidx < PAGING64_PAGESZ; cellidx++)
  {
    addrsrc = srcfpn * PAGING64_PAGESZ + cellidx;
    addrdst = dstfpn * PAGING64_PAGESZ + cellidx;

    BYTE data;
    MEMPHY_read(mpsrc, addrsrc, &data);
    MEMPHY_write(mpdst, addrdst, data);
  }

  return 0;
}

/*
 *Initialize a empty Memory Management instance
 * @mm:     self mm
 * @caller: mm owner
 */
int init_mm(struct mm_struct *mm, struct pcb_t *caller)
{
  if (mm == NULL || caller == NULL)
    return -1;

  caller->mm = mm;

  struct vm_area_struct *vma0 = malloc(sizeof(struct vm_area_struct));

  
  /* Khởi tạo thư mục gốc cấp 1 (PGD) */
  mm->pgd = calloc(512, sizeof(addr_t));
  mm->p4d = NULL;
  mm->pud = NULL;
  mm->pmd = NULL;
  mm->pt = NULL;

  /* By default the owner comes with at least one vma */
  vma0->vm_id = 0;
  vma0->vm_start = 0;
  vma0->vm_end = vma0->vm_start;
  vma0->sbrk = vma0->vm_start;
  struct vm_rg_struct *first_rg = init_vm_rg(vma0->vm_start, vma0->vm_end);
  enlist_vm_rg_node(&vma0->vm_freerg_list, first_rg);

  vma0->vm_next = NULL;
  vma0->vm_mm = mm;

  /* Liên kết cấu trúc */
  mm->mmap = vma0;
  mm->fifo_pgn = NULL;
  mm->kcpooltbl = NULL;

  return 0;
}

struct vm_rg_struct *init_vm_rg(addr_t rg_start, addr_t rg_end)
{
  struct vm_rg_struct *rgnode = malloc(sizeof(struct vm_rg_struct));

  rgnode->vmaid = 0;
  rgnode->rg_start = rg_start;
  rgnode->rg_end = rg_end;
  rgnode->rg_next = NULL;

  return rgnode;
}

int enlist_vm_rg_node(struct vm_rg_struct **rglist, struct vm_rg_struct *rgnode)
{
  rgnode->rg_next = *rglist;
  *rglist = rgnode;

  return 0;
}

int enlist_pgn_node(struct pgn_t **plist, addr_t pgn)
{
  struct pgn_t *pnode = malloc(sizeof(struct pgn_t));

  pnode->pgn = pgn;
  pnode->pg_next = *plist;
  *plist = pnode;

  return 0;
}

int print_list_fp(struct framephy_struct *ifp)
{
  struct framephy_struct *fp = ifp;

  printf("print_list_fp: ");
  if (fp == NULL) { printf("NULL list\n"); return -1;}
  printf("\n");
  while (fp != NULL)
  {
    printf("fp[" FORMAT_ADDR "]\n", fp->fpn);
    fp = fp->fp_next;
  }
  printf("\n");
  return 0;
}

int print_list_rg(struct vm_rg_struct *irg)
{
  struct vm_rg_struct *rg = irg;

  printf("print_list_rg: ");
  if (rg == NULL) { printf("NULL list\n"); return -1; }
  printf("\n");
  while (rg != NULL)
  {
    printf("rg[" FORMAT_ADDR "->"  FORMAT_ADDR "]\n", rg->rg_start, rg->rg_end);
    rg = rg->rg_next;
  }
  printf("\n");
  return 0;
}

int print_list_vma(struct vm_area_struct *ivma)
{
  struct vm_area_struct *vma = ivma;

  printf("print_list_vma: ");
  if (vma == NULL) { printf("NULL list\n"); return -1; }
  printf("\n");
  while (vma != NULL)
  {
    printf("va[" FORMAT_ADDR "->" FORMAT_ADDR "]\n", vma->vm_start, vma->vm_end);
    vma = vma->vm_next;
  }
  printf("\n");
  return 0;
}

int print_list_pgn(struct pgn_t *ip)
{
  printf("print_list_pgn: ");
  if (ip == NULL) { printf("NULL list\n"); return -1; }
  printf("\n");
  while (ip != NULL)
  {
    printf("va[" FORMAT_ADDR "]-\n", ip->pgn);
    ip = ip->pg_next;
  }
  printf("n");
  return 0;
}

int print_pgtbl(struct pcb_t *caller, addr_t start, addr_t end)
{
  addr_t pgd=0;
  addr_t p4d=0;
  addr_t pud=0;
  addr_t pmd=0;
  addr_t pt=0;

  get_pd_from_address(start, &pgd, &p4d, &pud, &pmd, &pt);

  printf("print_pgtbl:\n");
  if (caller->mm->pgd == NULL) {
      return -1;
  }

  /* Định vị các con trỏ tương ứng dựa vào bảng băm (hash) địa chỉ */
  addr_t *p4d_tbl = (addr_t *)caller->mm->pgd[pgd];
  addr_t *pud_tbl = p4d_tbl ? (addr_t *)p4d_tbl[p4d] : NULL;
  addr_t *pmd_tbl = pud_tbl ? (addr_t *)pud_tbl[pud] : NULL;
  

  printf(" PGD=%lx P4g=%lx PUD=%lx PMD=%lx\n", 
           (uintptr_t)caller->mm->pgd, 
           (uintptr_t)p4d_tbl, 
           (uintptr_t)pud_tbl, 
           (uintptr_t)pmd_tbl);

  return 0;
}

#endif  //def MM64