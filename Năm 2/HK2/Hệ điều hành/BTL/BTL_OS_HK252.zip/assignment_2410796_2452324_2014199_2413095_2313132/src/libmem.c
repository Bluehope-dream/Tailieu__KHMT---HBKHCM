/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

// #ifdef MM_PAGING
/*
 * System Library
 * Memory Module Library libmem.c 
 */

#include "string.h"
#include "mm.h"

#ifdef MM64
#include "mm64.h"
#endif

#include "syscall.h"
#include "libmem.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

static pthread_mutex_t mmvm_lock = PTHREAD_MUTEX_INITIALIZER;
#define KERNEL_VMA_BASE ((addr_t)0x8000)
static addr_t kernel_brk = KERNEL_VMA_BASE;

/*enlist_vm_freerg_list - add new rg to freerg_list
 *@mm: memory region
 *@rg_elmt: new region
 *
 */
int enlist_vm_freerg_list(struct mm_struct *mm, struct vm_rg_struct *rg_elmt)
{
  struct vm_rg_struct *rg_node = mm->mmap->vm_freerg_list;

  if (rg_elmt->rg_start >= rg_elmt->rg_end)
    return -1;

  if (rg_node != NULL)
    rg_elmt->rg_next = rg_node;

  /* Enlist the new region */
  mm->mmap->vm_freerg_list = rg_elmt;

  return 0;
}

/*get_symrg_byid - get mem region by region ID
 *@mm: memory region
 *@rgid: region ID act as symbol index of variable
 *
 */
struct vm_rg_struct *get_symrg_byid(struct mm_struct *mm, int rgid)
{
  if (rgid < 0 || rgid > PAGING_MAX_SYMTBL_SZ)
    return NULL;

  return &mm->symrgtbl[rgid];
}

/*__alloc - allocate a region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *@alloc_addr: address of allocated memory region
 *
 */
int __alloc(struct pcb_t *caller, int vmaid, int rgid, addr_t size, addr_t *alloc_addr)
{
  /*Allocate at the toproof */
  pthread_mutex_lock(&mmvm_lock);
  struct vm_rg_struct rgnode;
  struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);
  int inc_sz=0;

  if (get_free_vmrg_area(caller, vmaid, size, &rgnode) == 0)
  {
    caller->mm->symrgtbl[rgid].rg_start = rgnode.rg_start;
    caller->mm->symrgtbl[rgid].rg_end = rgnode.rg_end;
 
    *alloc_addr = rgnode.rg_start;

    pthread_mutex_unlock(&mmvm_lock);
    return 0;
  }

  /* TODO get_free_vmrg_area FAILED handle the region management (Fig.6)*/

  /*Attempt to increate limit to get space */
#ifdef MM64
  inc_sz = (uint32_t)(size/(int)PAGING64_PAGESZ);
  inc_sz = inc_sz + 1;
#else
  inc_sz = PAGING_PAGE_ALIGNSZ(size);
#endif
  int old_sbrk;
  inc_sz = inc_sz + 1;

  old_sbrk = cur_vma->sbrk;

  /* TODO INCREASE THE LIMIT
   * SYSCALL 1 sys_memmap
   */
  struct sc_regs regs;
  regs.a1 = SYSMEM_INC_OP;
  regs.a2 = vmaid;
#ifdef MM64
  regs.a3 = size;
#else
  regs.a3 = PAGING_PAGE_ALIGNSZ(size);
#endif  
  _syscall(caller->krnl, caller->pid, 17, &regs); /* SYSCALL 17 sys_memmap */

  /*Successful increase limit */
  caller->mm->symrgtbl[rgid].rg_start = old_sbrk;
  caller->mm->symrgtbl[rgid].rg_end = old_sbrk + size;

  *alloc_addr = old_sbrk;

  pthread_mutex_unlock(&mmvm_lock);
  return 0;

}

/*__free - remove a region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *
 */
int __free(struct pcb_t *caller, int vmaid, int rgid)
{
  pthread_mutex_lock(&mmvm_lock);

  if (rgid < 0 || rgid > PAGING_MAX_SYMTBL_SZ)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  /* TODO: Manage the collect freed region to freerg_list */
  struct vm_rg_struct *rgnode = get_symrg_byid(caller->mm, rgid);

  if (rgnode->rg_start == 0 && rgnode->rg_end == 0)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }
  struct vm_rg_struct *freerg_node = malloc(sizeof(struct vm_rg_struct));
  freerg_node->rg_start = rgnode->rg_start;
  freerg_node->rg_end = rgnode->rg_end;
  freerg_node->rg_next = NULL;

  rgnode->rg_start = rgnode->rg_end = 0;
  rgnode->rg_next = NULL;

  /*enlist the obsoleted memory region */
  enlist_vm_freerg_list(caller->mm, freerg_node);

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}

/*liballoc - PAGING-based allocate a region memory
 *@proc:  Process executing the instruction
 *@size: allocated size
 *@reg_index: memory region ID (used to identify variable in symbole table)
 */

int liballoc(struct pcb_t *proc, addr_t size, uint32_t reg_index)
{
   pthread_mutex_lock(&mmvm_lock);
   struct vm_rg_struct newrg;
   int vmaid = 0;

   if (get_free_vmrg_area(proc, vmaid, size, &newrg) == 0) {
      proc->regs[reg_index] = newrg.rg_start;
      proc->mm->symrgtbl[reg_index].rg_start = newrg.rg_start;
      proc->mm->symrgtbl[reg_index].rg_end   = newrg.rg_end;
   } else {
      int res = libsyscall(proc, 17, SYSMEM_INC_OP, vmaid, size);
      if (res < 0) {
          pthread_mutex_unlock(&mmvm_lock);
          return -1;
      }
      
      if (get_free_vmrg_area(proc, vmaid, size, &newrg) == 0) {
          proc->regs[reg_index] = newrg.rg_start;
          proc->mm->symrgtbl[reg_index].rg_start = newrg.rg_start;
          proc->mm->symrgtbl[reg_index].rg_end   = newrg.rg_end;
      } else {
          pthread_mutex_unlock(&mmvm_lock);
          return -1;
      }
   }

   pthread_mutex_unlock(&mmvm_lock);

   #ifdef IODUMP
    printf("liballoc:178\n");
   #ifdef PAGETBL_DUMP
    print_pgtbl(proc, 0, -1);
   #endif
   #endif
   return 0;
}

/*libfree - PAGING-based free a region memory
 *@proc: Process executing the instruction
 *@size: allocated size
 *@reg_index: memory region ID (used to identify variable in symbole table)
 */

int libfree(struct pcb_t *proc, uint32_t reg_index)
{
   int ret = __free(proc, 0, reg_index);
   

   #ifdef IODUMP
    printf("libfree:218\n");
   #ifdef PAGETBL_DUMP
    print_pgtbl(proc, 0, -1);
   #endif
   #endif
   return ret;
}

/*pg_getpage - get the page in ram
 *@mm: memory region
 *@pagenum: PGN
 *@framenum: return FPN
 *@caller: caller
 *
 */
int pg_getpage(struct pcb_t *caller, addr_t pgn, addr_t *fpn)
{
    uint32_t pte = pte_get_entry(caller, pgn);
    if (PAGING_PAGE_PRESENT(pte)) {
        *fpn = PAGING_PTE_FPN(pte);
        return 0;
    } else if (pte & PAGING_PTE_SWAPPED_MASK) {
        addr_t swpoff = PAGING_PTE_SWP(pte);
        addr_t vicpgn;
        addr_t vicfpn;

        if (MEMPHY_get_freefp(caller->krnl->mram, fpn) < 0) {
            find_victim_page(caller->mm, &vicpgn);
            uint32_t vicpte = pte_get_entry(caller, vicpgn);
            vicfpn = PAGING_PTE_FPN(vicpte);

            addr_t newswp;
            MEMPHY_get_freefp(caller->krnl->active_mswp, &newswp);
            __swap_cp_page(caller->krnl->mram, vicfpn, caller->krnl->active_mswp, newswp);
            pte_set_swap(caller, vicpgn, caller->krnl->active_mswp_id, newswp);

            *fpn = vicfpn;
        }

        __swap_cp_page(caller->krnl->active_mswp, swpoff, caller->krnl->mram, *fpn);
        MEMPHY_put_freefp(caller->krnl->active_mswp, swpoff);
        pte_set_fpn(caller, pgn, *fpn);
        enlist_pgn_node(&caller->mm->fifo_pgn, pgn);
        return 0;
    }
    return -1;
}

/*pg_getval - read value at given offset
 *@mm: memory region
 *@addr: virtual address to acess
 *@value: value
 *
 */
int pg_getval(struct mm_struct *mm, addr_t addr, BYTE *data, struct pcb_t *caller)
{
    int pgn = addr >> PAGING64_ADDR_PT_SHIFT; 
    int off = addr & PAGING64_ADDR_OFFST_MASK;
    addr_t fpn;

    if (pg_getpage(caller, pgn, &fpn) != 0) {
        return -1; 
    }

    addr_t phyaddr = (fpn << PAGING64_ADDR_PT_SHIFT) + off;

    MEMPHY_read(caller->krnl->mram, phyaddr, data);

    return 0;
}

/*pg_setval - write value to given offset
 *@mm: memory region
 *@addr: virtual address to acess
 *@value: value
 *
 */
int pg_setval(struct mm_struct *mm, addr_t addr, BYTE value, struct pcb_t *caller)
{
  int pgn = addr >> PAGING64_ADDR_PT_SHIFT; 
  int off = addr & PAGING64_ADDR_OFFST_MASK;
  addr_t fpn;

  if (pg_getpage(caller, pgn, &fpn) != 0) 
    return -1; 

  addr_t phyaddr = (fpn << PAGING64_ADDR_PT_SHIFT) + off;
  MEMPHY_write(caller->krnl->mram, phyaddr, value);

  return 0;
}

/*__read - read value in region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@offset: offset to acess in memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *
 */
int __read(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE *data)
{
  struct vm_rg_struct *currg = get_symrg_byid(caller->mm, rgid);

//struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);

  /* TODO Invalid memory identify */

  pg_getval(caller->mm, currg->rg_start + offset, data, caller);

  return 0;
}

/*libread - PAGING-based read a region memory */

int libread(struct pcb_t *proc, uint32_t source, addr_t offset, uint32_t *destination)
{
   pthread_mutex_lock(&mmvm_lock);
   
   addr_t vaddr = proc->regs[source] + offset;
   BYTE data = 0;
   
   // Gọi trực tiếp pg_getval thay vì đi qua syscall
   pg_getval(proc->mm, vaddr, &data, proc);
   *destination = (uint32_t)data;
   
   pthread_mutex_unlock(&mmvm_lock);
   
   #ifdef IODUMP
    printf("libread:426\n");
   #endif
   return 0;
}

/*__write - write a region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@offset: offset to acess in memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *
 */
int __write(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE value)
{
  pthread_mutex_lock(&mmvm_lock);
  struct vm_rg_struct *currg = get_symrg_byid(caller->mm, rgid);

  struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);

  if (currg == NULL || cur_vma == NULL) /* Invalid memory identify */
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  pg_setval(caller->mm, currg->rg_start + offset, value, caller);

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}

/*libwrite - PAGING-based write a region memory */
int libwrite(struct pcb_t *proc, BYTE data, uint32_t destination, addr_t offset)
{
   pthread_mutex_lock(&mmvm_lock);

   /* Xác định địa chỉ ảo đích cần ghi xuống */
   addr_t vaddr = proc->regs[destination] + offset;

   /* Gọi System Call chuyển giao dữ liệu xuống phân hệ quản lý bộ nhớ của Kernel */
   pg_setval(proc->mm, vaddr, (BYTE)data, proc);

   pthread_mutex_unlock(&mmvm_lock);

   #ifdef IODUMP
    printf("libwrite:502\n");
   #ifdef PAGETBL_DUMP
    print_pgtbl(proc, 0, -1);
   #endif
   #endif
   return 0;
}


//      ### Helper
static int update_kernel_page_entry(struct krnl_t *system_krnl, addr_t page_idx, addr_t frame_num)
{
    addr_t raw_pte = 0;

    if (!system_krnl || !system_krnl->krnl_pt || page_idx >= PAGING_MAX_PGN) {
        return -1;
    }

    // Thiết lập thuộc tính trực tiếp cho trang hiện diện (present = 1)
    init_pte(&raw_pte, 1, frame_num, 0, 0, 0, 0);
    system_krnl->krnl_pt[page_idx] = raw_pte;
    return 0;
}

/**
 * @brief Truy vấn giá trị PTE từ bảng trang bộ nhớ nhân
 * @note Thay thế cho hàm kernel_pte_get_entry cũ
 */
static uint32_t fetch_kernel_pte(struct krnl_t *system_krnl, addr_t page_idx)
{
    if (!system_krnl || !system_krnl->krnl_pt || page_idx >= PAGING_MAX_PGN) {
        return 0;
    }
    return (uint32_t)system_krnl->krnl_pt[page_idx];
}

/**
 * @brief Thực hiện cấp phát khung trang và ánh xạ cho một dải địa chỉ của Kernel
 * @note Thay thế cho hàm kernel_map_range cũ
 */
static int map_kernel_virtual_range(struct pcb_t *process_owner, addr_t start_addr, addr_t byte_size)
{
    addr_t aligned_size = PAGING_PAGE_ALIGNSZ(byte_size);
    int total_pages = aligned_size / PAGING_PAGESZ;
    addr_t base_page_idx = PAGING_PGN(start_addr);

    for (int page_offset = 0; page_offset < total_pages; page_offset++)
    {
        addr_t allocated_fpn;
        // Thu hồi một khung trang trống từ RAM vật lý
        if (MEMPHY_get_freefp(process_owner->krnl->mram, &allocated_fpn) != 0) {
            return -1;
        }
        // Ánh xạ tuần tiến vào bảng trang cấu trúc phẳng
        if (update_kernel_page_entry(process_owner->krnl, base_page_idx + page_offset, allocated_fpn) != 0) {
            return -1;
        }
    }
    return 0;
}


/* libkmem_malloc - allocate a kernel-space region. */
int libkmem_malloc(struct pcb_t *caller, uint32_t size, uint32_t reg_index)
{
   
    addr_t allocated_vaddr;
    int execution_result = __kmalloc(caller, -1, reg_index, size, &allocated_vaddr);
    // printf("Execution res at line 550 = %d\n" ,execution_result);
    if (execution_result == 0) {
        return -1;
    }
    
    
    caller->regs[reg_index] = allocated_vaddr;
    // printf("[kmalloc] pid=%u rg=%u kernel_addr=" FORMAT_ADDR " size=%u\n",
    //        caller->pid, reg_index, allocated_vaddr, size);
    // fflush(stdout);
    
    printf(
        "[kmalloc] pid=%u rg=%u kernel_addr="
        FORMAT_ARG
        " size=%u\n",
        caller->pid,
        reg_index,
        allocated_vaddr,
        size);

    
      // printf("Exit malloc...");
      fflush(stdout);
    return 0;
}

addr_t __kmalloc(struct pcb_t *caller, int vmaid, int rgid, addr_t size, addr_t *alloc_addr)
{
  addr_t addr;

  (void)vmaid;
// printf("1..\n");
  if (caller == NULL || caller->mm == NULL || caller->krnl == NULL ||
      alloc_addr == NULL || rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ || size == 0)
    return -1;
    // printf("2..\n");
  pthread_mutex_lock(&mmvm_lock);
  addr = kernel_brk;
  kernel_brk += PAGING_PAGE_ALIGNSZ(size);
    // printf("3..\n");
  if (map_kernel_virtual_range(caller, addr, size) != 0)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }
  // printf("4..\n");
  caller->mm->symrgtbl[rgid].vmaid = -1; /* kernel-space marker */
  caller->mm->symrgtbl[rgid].rg_start = addr;
  caller->mm->symrgtbl[rgid].rg_end = addr + size;
  caller->mm->symrgtbl[rgid].rg_next = NULL;
  *alloc_addr = addr;

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}


int libkmem_cache_pool_create(struct pcb_t *caller, uint32_t size, uint32_t align, uint32_t cache_pool_id)
{
    addr_t pool_base_address;

    if (caller == NULL || caller->mm == NULL || caller->mm->kcpooltbl == NULL ||
        cache_pool_id >= PAGING_MAX_SYMTBL_SZ || align == 0 || size == 0) {
        return -1;
    }

    // Khởi tạo vùng không gian đệm thô từ kmalloc chuẩn hệ thống
    if (__kmalloc(caller, -1, cache_pool_id, size, &pool_base_address) != 0) {
        return -1;
    }

    caller->mm->kcpooltbl[cache_pool_id].size = size;
    caller->mm->kcpooltbl[cache_pool_id].align = align;
    caller->mm->kcpooltbl[cache_pool_id].storage = pool_base_address;
    return 0;
}

int libkmem_cache_alloc(struct pcb_t *proc, uint32_t cache_pool_id, uint32_t reg_index)
{
    addr_t allocated_slot_address;
    int allocation_status = __kmem_cache_alloc(proc, -1, reg_index, cache_pool_id, &allocated_slot_address);
    
    if (allocation_status != 0) {
        return -1;
    }

    proc->regs[reg_index] = allocated_slot_address;
    return 0;
}

addr_t __kmem_cache_alloc(struct pcb_t *caller, int vmaid, int rgid, int cache_pool_id, addr_t *alloc_addr)
{
    struct kcache_pool_struct *target_pool;
    (void)vmaid;

    if (caller == NULL || caller->mm == NULL || caller->mm->kcpooltbl == NULL ||
        alloc_addr == NULL || rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ ||
        cache_pool_id < 0 || cache_pool_id >= PAGING_MAX_SYMTBL_SZ) {
        return -1;
    }

    target_pool = &caller->mm->kcpooltbl[cache_pool_id];
    if (target_pool->storage == 0 || target_pool->align == 0) {
        return -1;
    }

    /* Triển khai mô hình Slab tối giản cho đồ án: Trả về slot khả dụng đầu tiên */
    caller->mm->symrgtbl[rgid].vmaid = -1;
    caller->mm->symrgtbl[rgid].rg_start = target_pool->storage;
    caller->mm->symrgtbl[rgid].rg_end = target_pool->storage + target_pool->align;
    caller->mm->symrgtbl[rgid].rg_next = NULL;
    
    *alloc_addr = target_pool->storage;
    return 0;
}

int libkmem_copy_from_user(struct pcb_t *caller, uint32_t source, uint32_t destination, uint32_t offset, uint32_t size)
{
    for (uint32_t byte_idx = 0; byte_idx < size; byte_idx++)
    {
        BYTE temporary_buffer;
        if (__read_user_mem(caller, 0, source, offset + byte_idx, &temporary_buffer) != 0) {
            return -1;
        }
        if (__write_kernel_mem(caller, -1, destination, offset + byte_idx, temporary_buffer) != 0) {
            return -1;
        }
    }
    printf("[copy_from_user] pid=%u user_rg=%u -> kernel_rg=%u offset=%u size=%u\n",
           caller->pid, source, destination, offset, size);
    fflush(stdout);
    
    return 0;
}

int libkmem_copy_to_user(struct pcb_t *caller, uint32_t source, uint32_t destination, uint32_t offset, uint32_t size)
{
    
    for (uint32_t byte_idx = 0; byte_idx < size; byte_idx++)
    {
        BYTE temporary_buffer;
        if (__read_kernel_mem(caller, -1, source, offset + byte_idx, &temporary_buffer) != 0) {
            return -1;
        }
        if (__write_user_mem(caller, 0, destination, offset + byte_idx, temporary_buffer) != 0) {
            return -1;
        }
    }
    printf("[copy_to_user] pid=%u kernel_rg=%u -> user_rg=%u offset=%u size=%u\n",
           caller->pid, source, destination, offset, size);
    fflush(stdout);
    return 0;
}

int __read_kernel_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE *data)
{
    struct vm_rg_struct *kernel_region;
    uint32_t current_pte;
    int target_pgn, page_offset, target_fpn, computed_phyaddr;
    (void)vmaid;

    if (caller == NULL || caller->mm == NULL || data == NULL) {
        return -1;
    }

    kernel_region = get_symrg_byid(caller->mm, rgid);
    if (kernel_region == NULL || kernel_region->vmaid != -1 ||
        kernel_region->rg_start >= kernel_region->rg_end || 
        kernel_region->rg_start + offset >= kernel_region->rg_end) {
        return -1;
    }

    target_pgn = PAGING_PGN((kernel_region->rg_start + offset));
    page_offset = PAGING_OFFST((kernel_region->rg_start + offset));
    
    current_pte = fetch_kernel_pte(caller->krnl, target_pgn);
    if (!PAGING_PAGE_PRESENT(current_pte)) {
        return -1;
    }

    target_fpn = PAGING_FPN(current_pte);
    computed_phyaddr = target_fpn * PAGING_PAGESZ + page_offset;
    
    return MEMPHY_read(caller->krnl->mram, computed_phyaddr, data);
}

int __write_kernel_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE value)
{
    struct vm_rg_struct *kernel_region;
    uint32_t current_pte;
    int target_pgn, page_offset, target_fpn, computed_phyaddr;
    (void)vmaid;

    if (caller == NULL || caller->mm == NULL) {
        return -1;
    }

    kernel_region = get_symrg_byid(caller->mm, rgid);
    if (kernel_region == NULL || kernel_region->vmaid != -1 ||
        kernel_region->rg_start >= kernel_region->rg_end || 
        kernel_region->rg_start + offset >= kernel_region->rg_end) {
        return -1;
    }

    target_pgn = PAGING_PGN((kernel_region->rg_start + offset));
    page_offset = PAGING_OFFST((kernel_region->rg_start + offset));
    
    current_pte = fetch_kernel_pte(caller->krnl, target_pgn);
    if (!PAGING_PAGE_PRESENT(current_pte)) {
        return -1;
    }

    target_fpn = PAGING_FPN(current_pte);
    computed_phyaddr = target_fpn * PAGING_PAGESZ + page_offset;
    
    return MEMPHY_write(caller->krnl->mram, computed_phyaddr, value);
}

int __read_user_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE *data)
{
    return __read(caller, vmaid, rgid, offset, data);
}

int __write_user_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE value)
{
    return __write(caller, vmaid, rgid, offset, value);
}


/*free_pcb_memphy - collect all memphy of pcb
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@incpgnum: number of page
 */
int free_pcb_memph(struct pcb_t *caller)
{
  pthread_mutex_lock(&mmvm_lock);
  int pagenum, fpn;
  uint32_t pte;

  for (pagenum = 0; pagenum < PAGING_MAX_PGN; pagenum++)
  {
    pte = caller->mm->pgd[pagenum];

    if (PAGING_PAGE_PRESENT(pte))
    {
      fpn = PAGING_FPN(pte);
      MEMPHY_put_freefp(caller->krnl->mram, fpn);
    }
    else
    {
      fpn = PAGING_SWP(pte);
      MEMPHY_put_freefp(caller->krnl->active_mswp, fpn);
    }
  }

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}


/*find_victim_page - find victim page
 *@caller: caller
 *@pgn: return page number
 *
 */
int find_victim_page(struct mm_struct *mm, addr_t *pgn)
{
    struct pgn_t *pg = mm->fifo_pgn;
    struct pgn_t *prev = NULL;

    if (pg == NULL) return -1;
    while (pg->pg_next != NULL) {
        prev = pg;
        pg = pg->pg_next;
    }

    *pgn = pg->pgn;
    if (prev == NULL) {
        mm->fifo_pgn = NULL;
    } else {
        prev->pg_next = NULL;
    }
    free(pg);
    return 0;
}

/*get_free_vmrg_area - get a free vm region
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@size: allocated size
 *
 */
int get_free_vmrg_area(struct pcb_t *caller, int vmaid, int size, struct vm_rg_struct *newrg)
{
    struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);
    struct vm_rg_struct *rgit = cur_vma->vm_freerg_list;
    struct vm_rg_struct *prev = NULL;

    if (rgit == NULL) return -1;

    newrg->rg_start = -1;
    newrg->rg_end = -1;

    while (rgit != NULL) {
        if (rgit->rg_start + size <= rgit->rg_end) {
            newrg->rg_start = rgit->rg_start;
            newrg->rg_end = rgit->rg_start + size;

            if (rgit->rg_start + size <= rgit->rg_end) {
                rgit->rg_start = rgit->rg_start + size;
            } else {
                if (prev == NULL) {
                    cur_vma->vm_freerg_list = rgit->rg_next;
                } else {
                    prev->rg_next = rgit->rg_next;
                }
                free(rgit);
            }
            return 0;
        }
        prev = rgit;
        rgit = rgit->rg_next;
    }
    return -1;
}

// #endif
