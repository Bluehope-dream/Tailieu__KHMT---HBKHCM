/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

//#ifdef MM_PAGING
/*
 * PAGING based Memory Management
 * Virtual memory module mm/mm-vm.c
 */

#include "string.h"
#include "mm.h"

#ifdef MM64
#include "mm64.h"
#endif
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

/*get_vma_by_num - get vm area by numID
 *@mm: memory region
 *@vmaid: ID vm area to alloc memory region
 *
 */
struct vm_area_struct *get_vma_by_num(struct mm_struct *mm, int vmaid)
{
  struct vm_area_struct *pvma = mm->mmap;
    while (pvma != NULL) {
        if (pvma->vm_id == vmaid) return pvma;
        pvma = pvma->vm_next;
    }
    return NULL;
}

int __mm_swap_page(struct pcb_t *caller, addr_t vicfpn , addr_t swpfpn)
{
    __swap_cp_page(caller->krnl->mram, vicfpn, caller->krnl->active_mswp, swpfpn);
    return 0;
}

/*get_vm_area_node - get vm area for a number of pages
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@incpgnum: number of page
 *@vmastart: vma end
 *@vmaend: vma end
 *
 */
struct vm_rg_struct *get_vm_area_node_at_brk(struct pcb_t *caller, int vmaid, addr_t size, addr_t alignedsz)
{
  struct vm_rg_struct * newrg;
  /* TODO retrive current vma to obtain newrg, current comment out due to compiler redundant warning*/
  //struct vm_area_struct *cur_vma = get_vma_by_num(caller->kernl->mm, vmaid);

  //newrg = malloc(sizeof(struct vm_rg_struct));

  /* TODO: update the newrg boundary
  // newrg->rg_start = ...
  // newrg->rg_end = ...
  */
  struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);

  newrg = malloc(sizeof(struct vm_rg_struct));
  newrg->rg_start = cur_vma->sbrk;
  newrg->rg_end = newrg->rg_start + size;
  /* END TODO */

  return newrg;
}

/*validate_overlap_vm_area
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@vmastart: vma end
 *@vmaend: vma end
 *
 */
int validate_overlap_vm_area(struct pcb_t *caller, int vmaid, addr_t vmastart, addr_t vmaend)
{
    struct vm_area_struct *vma = caller->mm->mmap;

    while (vma != NULL) {
        if (vma->vm_id != vmaid) {

            if (!(vmaend <= vma->vm_start || vmastart >= vma->vm_end)) {
                return -1; 
            }
        }
        vma = vma->vm_next;
    }
    return 0; 
}

/*inc_vma_limit - increase vm area limits to reserve space for new variable
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@inc_sz: increment size
 *
 */
int inc_vma_limit(struct pcb_t *caller, int vmaid, addr_t inc_sz)
{
  struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);
    if (cur_vma == NULL) return -1;

#ifdef MM64
    addr_t inc_amt = PAGING64_PAGE_ALIGNSZ(inc_sz);
    int incnumpage = inc_amt / PAGING64_PAGESZ;
#else
    addr_t inc_amt = PAGING_PAGE_ALIGNSZ(inc_sz);
    int incnumpage = inc_amt / PAGING_PAGESZ;
#endif

    if (validate_overlap_vm_area(caller, vmaid, cur_vma->sbrk, cur_vma->sbrk + inc_amt) < 0)
        return -1;

    struct framephy_struct *frm_lst = NULL;
    if ((int64_t)alloc_pages_range(caller, incnumpage, &frm_lst) < 0) {
        return -1;
    }

    struct vm_rg_struct *new_rg = malloc(sizeof(struct vm_rg_struct));
    vmap_page_range(caller, cur_vma->sbrk, incnumpage, frm_lst, new_rg);

    struct framephy_struct *curr = frm_lst;
    struct framephy_struct *next;
    while (curr != NULL) {
        next = curr->fp_next;
        free(curr);
        curr = next;
    }

    cur_vma->vm_end += inc_amt;
    cur_vma->sbrk += inc_amt;

    enlist_vm_rg_node(&cur_vma->vm_freerg_list, new_rg);
    return 0;
}

// #endif
