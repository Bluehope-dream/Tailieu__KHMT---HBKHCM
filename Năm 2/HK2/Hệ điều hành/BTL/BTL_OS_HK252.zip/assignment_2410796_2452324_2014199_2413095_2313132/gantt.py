import re
import sys
import os
import matplotlib.pyplot as plt

def parse_input(input_filename):
    """
    Đọc file input để lấy cấu hình hệ thống (ví dụ file sched_0).
    Định dạng dòng đầu tiên luôn là: [time_slice] [num_cpus] [num_processes]
    """
    num_cpus = 1 # khởi tạo mặc định hệ thống có 1 CPU
    try:
        with open(input_filename, 'r') as f: # mở file input ở chế độ đọc ('r')
            first_line = f.readline().strip() # đọc dòng đầu tiên và xóa khoảng trắng thừa ở 2 đầu
            if first_line: # nếu dòng đầu tiên không bị trống
                parts = first_line.split() # cắt dòng đó ra thành một mảng các chữ số (ngăn cách bởi dấu cách)
                if len(parts) >= 2: # đảm bảo dòng đó có ít nhất 2 chữ số
                    num_cpus = int(parts[1]) # chữ số thứ 2 (index 1) chính là số lượng CPU, ép kiểu về số nguyên
    except Exception as e:
        print(f"Lỗi đọc file input: {e}") # in ra lỗi nếu không tìm thấy file hoặc file bị hỏng
    return num_cpus # trả về số lượng CPU để dùng cho các hàm sau

def parse_log(filename, num_cpus):
    """
    Đọc file log (.text) và xây dựng lịch chạy cho mỗi CPU.
    Trả về một từ điển (dict) có cấu trúc: {cpu_id: {time_slot: process_id hoặc None}}.
    """
    # khởi tạo trạng thái ban đầu của các CPU là None (đang rảnh, không chạy process nào)
    cpu_state = {i: None for i in range(num_cpus)} 
    
    # khởi tạo từ điển trống để lưu lịch sử chạy theo từng mốc thời gian của từng CPU
    cpu_schedule = {i: {} for i in range(num_cpus)} 
    current_time = None # biến lưu mốc thời gian hiện tại đang xét

    # Cài đặt các bộ lọc (Regex) để nhận diện tự động các dòng log đặc biệt
    time_slot_pattern = re.compile(r"Time slot\s+(\d+)") # Bắt dòng "Time slot X"
    dispatched_pattern = re.compile(r"CPU\s+(\d+):\s+Dispatched process\s+(\d+)") # Bắt dòng "CPU X: Dispatched process Y"
    processed_pattern = re.compile(r"CPU\s+(\d+):\s+Processed\s+(\d+)\s+has finished") # Bắt dòng process đã chạy xong
    stopped_pattern = re.compile(r"CPU\s+(\d+)\s+stopped") # Bắt dòng CPU đã dừng hoàn toàn

    with open(filename, 'r') as f: # mở file log để đọc từng dòng
        for line in f:
            line = line.strip() # cắt khoảng trắng đầu/cuối dòng
            if not line: # nếu là dòng trống thì bỏ qua, đọc dòng tiếp theo
                continue
            
            # 1. Nếu gặp dòng "Time slot"
            ts_match = time_slot_pattern.search(line)
            if ts_match:
                current_time = int(ts_match.group(1)) # trích xuất con số thời gian ra
                # chốt trạng thái của tất cả CPU tại mốc thời gian này vào lịch sử
                for cpu in cpu_state:
                    cpu_schedule[cpu][current_time] = cpu_state[cpu]
                continue
            
            # 2. Nếu gặp dòng "Dispatched process" (CPU bốc 1 tiến trình vào chạy)
            d_match = dispatched_pattern.search(line)
            if d_match:
                cpu = int(d_match.group(1)) # trích xuất số ID của CPU
                proc = int(d_match.group(2)) # trích xuất số ID của Process
                if cpu in cpu_state:
                    cpu_state[cpu] = proc # cập nhật CPU này đang chạy Process này
                    if current_time is not None:
                        cpu_schedule[cpu][current_time] = proc # lưu ngay vào lịch sử tại time slot hiện tại
                continue
            
            # 3. Nếu gặp dòng "Processed ... has finished" (Tiến trình chạy xong)
            p_match = processed_pattern.search(line)
            if p_match:
                cpu = int(p_match.group(1))
                if cpu in cpu_state:
                    cpu_state[cpu] = None # CPU được trả về trạng thái rảnh rỗi (None)
                    if current_time is not None:
                        cpu_schedule[cpu][current_time] = None
                continue
            
            # 4. Nếu gặp dòng "stopped" (CPU tắt máy)
            s_match = stopped_pattern.search(line)
            if s_match:
                cpu = int(s_match.group(1))
                if cpu in cpu_state:
                    cpu_state[cpu] = None # CPU rảnh rỗi hoàn toàn
                    if current_time is not None:
                        cpu_schedule[cpu][current_time] = None
                continue
                
    return cpu_schedule # trả về quyển sổ lịch sử đã ghi chép đầy đủ

def merge_schedule(schedule):
    """
    Hàm này có tác dụng gom các khoảng thời gian bị vụn vặt lại thành một thanh dài (để vẽ hình cho đẹp).
    Ví dụ: P1 chạy ở slot 1, 2, 3 -> Gom thành một khối duy nhất từ 1 đến 4.
    """
    intervals = [] # mảng lưu các khối thời gian đã gom
    sorted_times = sorted(schedule.keys()) # sắp xếp các mốc thời gian tăng dần từ bé đến lớn
    if not sorted_times: # nếu không có dữ liệu thời gian thì trả về mảng rỗng
        return intervals
    
    current_proc = schedule[sorted_times[0]] # lấy tiến trình chạy ở mốc thời gian đầu tiên
    start_time = sorted_times[0] # đánh dấu thời điểm bắt đầu của khối màu
    
    for t in sorted_times[1:]: # duyệt qua các mốc thời gian tiếp theo
        if schedule[t] == current_proc:
            continue # nếu vẫn là tiến trình cũ đang chạy thì cứ bỏ qua, cho nó chạy tiếp
        else:
            # nếu tiến trình bị đổi (Context Switch), ta tính toán độ dài của khối màu vừa xong
            duration = t - start_time 
            if duration > 0:
                intervals.append((start_time, duration, current_proc)) # đóng gói khối màu lưu vào mảng
            start_time = t # cập nhật lại thời điểm bắt đầu cho khối màu của tiến trình mới
            current_proc = schedule[t] # cập nhật lại tiến trình mới
            
    # Xử lý khối màu cuối cùng khi đã duyệt hết vòng lặp
    if sorted_times:
        t = sorted_times[-1] + 1 # cầm mốc thời gian cuối + 1 làm điểm kết thúc
        duration = t - start_time
        if duration > 0:
            intervals.append((start_time, duration, current_proc))
            
    return intervals

def main():
    # Kiểm tra xem người dùng gõ lệnh có đủ 3 tham số không (input, log, ảnh đầu ra)
    if len(sys.argv) < 4:
        print("Cú pháp: python ganttchart.py <đường_dẫn_input> <đường_dẫn_log> <tên_file_xuất>")
        print("Ví dụ: python ganttchart.py TASK_1_BTL/input/sched_2 TASK_1_BTL/expected/sched_2.output chart_sched_2.png")
        sys.exit(1) # thiếu tham số thì thoát chương trình
        
    input_file = sys.argv[1] # Lấy tham số 1 (Ví dụ: input/sched_0)
    log_file = sys.argv[2] # Lấy tham số 2 (Ví dụ: result_sched/sched_0.text)
    out_img = sys.argv[3] # Lấy tham số 3 (Ví dụ: result_sched/sched_0.png)
    
    # 1. Gọi hàm để trích xuất số lượng CPU từ file input
    num_cpus = parse_input(input_file)
    print(f"[INFO] Hệ thống được cấu hình với {num_cpus} CPU.")
    
    # 2. Gọi hàm để phân tích file log và lấy quyển sổ lịch sử
    cpu_schedule = parse_log(log_file, num_cpus)
    
    # 3. Tìm mốc thời gian cuối cùng của toàn bộ hệ thống để làm điểm chốt trục X của biểu đồ
    max_time = 0
    for schedule in cpu_schedule.values():
        if schedule:
            max_time = max(max_time, max(schedule.keys()))
    max_time += 1
    
    # 4. Gom các khoảng thời gian vụn vặt lại thành các khối lớn cho mỗi CPU
    cpu_intervals = {}
    for cpu, schedule in cpu_schedule.items():
        cpu_intervals[cpu] = merge_schedule(schedule)
    
    # 5. Định nghĩa màu sắc cho các process (mở rộng thêm màu cho nhiều process)
    process_colors = {
        1: '#E63946',  # P1: Đỏ tươi sậm
        2: '#2A9D8F',  # P2: Xanh ngọc bích
        3: '#E9C46A',  # P3: Vàng cát
        4: '#F4A261',  # P4: Cam sáng
        5: '#264653',  # P5: Xanh dương đậm
        6: '#8AB17D',  # P6: Xanh lá cây nhạt
        7: '#B5838D',  # P7: Tím tro
        8: '#FFB703',  # P8: Vàng cam
        9: '#C1121F',  # P9: Đỏ đun
        10: '#003049', # P10: Xanh lính thủy
        None: '#F5F5F5' # None: Xám rất nhạt (để hiển thị khoảng CPU rảnh rỗi)
    }
    
    # bắt đầu khởi tạo khung vẽ biểu đồ bằng thư viện matplotlib
    fig, ax = plt.subplots(figsize=(12, max(4, num_cpus * 2)))
    row_height = 8 # chiều cao của mỗi thanh CPU
    row_gap = 10 # khoảng cách giữa các thanh CPU
    yticks = [] # chứa tọa độ Y để gắn nhãn "CPU 0, CPU 1..."
    y_labels = [] # chứa chữ "CPU 0", "CPU 1"
    
    # bắt đầu vòng lặp vẽ từng khối màu lên khung
    for cpu, intervals in cpu_intervals.items():
        y = cpu * row_gap # tính toán độ cao (tọa độ Y) cho CPU hiện tại
        yticks.append(y + row_height / 2) # căn giữa chữ nhãn vào thanh
        y_labels.append(f"CPU {cpu}")
        for (start, duration, proc) in intervals:
            # lấy màu dựa theo ID của Process. Nếu không có trong bảng thì lấy màu xám.
            color = process_colors.get(proc, '#B0BEC5') if proc is not None else '#F5F5F5'
            
            # lệnh vẽ trực tiếp một khối màu chữ nhật
            ax.broken_barh([(start, duration)], (y, row_height),
                           facecolors=color, edgecolor='black', linewidth=1)
            
            # gắn chữ P1, P2... vào giữa khối màu vừa vẽ
            if proc is not None:
                ax.text(start + duration/2, y + row_height/2, f"P{proc}",
                        ha='center', va='center', color='white', fontsize=10, fontweight='bold')
    
    # cấu hình lưới trục hoành (Ox) - Trục thời gian
    ax.set_xticks([x + 0.5 for x in range(max_time)], minor=False) # căn số ở giữa các vạch
    ax.set_xticklabels(range(max_time))
    ax.set_xticks(range(max_time + 1), minor=True) # vẽ các vạch đứt đoạn ở mỗi ô
    ax.grid(which='minor', axis='x', linestyle='--', color='gray', alpha=0.5)
    
    # gắn nhãn dán cho các trục và tiêu đề
    ax.set_xlabel("Time Slot")
    ax.set_yticks(yticks)
    ax.set_yticklabels(y_labels)
    ax.set_title("OS Scheduler Gantt Chart")
    ax.set_xlim(0, max_time) # giới hạn lại độ dài của toàn bộ hình vẽ
    
    # tạo thư mục nếu nó chưa tồn tại (ví dụ thư mục result_sched)
    os.makedirs(os.path.dirname(out_img) if os.path.dirname(out_img) else '.', exist_ok=True)
    
    # căn chỉnh lại các viền cho không bị lẹm chữ và lưu thành file ảnh
    plt.tight_layout()
    plt.savefig(out_img, dpi=150) # lưu với độ phân giải cao 150 DPI
    print(f"[SUCCESS] Đã xuất biểu đồ ra file: {out_img}") # In thông báo thành công

# Cú pháp chuẩn của Python để đảm bảo file chạy đúng khi được gọi từ Terminal
if __name__ == '__main__':
    main()