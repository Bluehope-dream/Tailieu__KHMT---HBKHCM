/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* LamiaAtrium release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

#include "queue.h"
#include "sched.h"
#include <pthread.h>

#include <stdlib.h>
#include <stdio.h>

static struct queue_t ready_queue;
static struct queue_t run_queue;
static pthread_mutex_t queue_lock;

static struct queue_t running_list;

#ifdef MLQ_SCHED
static struct queue_t mlq_ready_queue[MAX_PRIO];
static int slot[MAX_PRIO];
#endif

int queue_empty(void)
{
    int is_empty;
    pthread_mutex_lock(&queue_lock);

#ifdef MLQ_SCHED
    is_empty = 1;
    for (int i = 0; i < MAX_PRIO; i++) {
        if (!empty(&mlq_ready_queue[i])) {
            is_empty = 0;
            break;
        }
    }
#else
    /* run_queue đã obsoleted nhưng vẫn kiểm tra cho an toàn */
    is_empty = (empty(&ready_queue) && empty(&run_queue));
#endif
 
    pthread_mutex_unlock(&queue_lock);
    return is_empty;   /* 1 = rỗng hoàn toàn, 0 = còn process */
}

void init_scheduler(void)
{
#ifdef MLQ_SCHED
    int i;

    for (i = 0; i < MAX_PRIO; i++)
    {
        mlq_ready_queue[i].size = 0;
        slot[i] = MAX_PRIO - i;
    }
#endif
    ready_queue.size = 0;
    run_queue.size = 0;
    running_list.size = 0;
    pthread_mutex_init(&queue_lock, NULL);
}

void finish_proc(struct pcb_t *proc)
{
    pthread_mutex_lock(&queue_lock);
    purgequeue(&running_list, proc);
    pthread_mutex_unlock(&queue_lock);
}
 
/* finish_scheduler: placeholder - có thể dùng để cleanup mutex sau này */
void finish_scheduler(void)
{
    pthread_mutex_destroy(&queue_lock);
}

#ifdef MLQ_SCHED
/*
 *  Stateful design for routine calling
 *  based on the priority and our MLQ policy
 *  We implement stateful here using transition technique
 *  State representation   prio = 0 .. MAX_PRIO, curr_slot = 0..(MAX_PRIO - prio)
 */
struct pcb_t *get_mlq_proc(void)
{
    struct pcb_t *proc = NULL;

    pthread_mutex_lock(&queue_lock);
    /*TODO: get a process from PRIORITY [ready_queue].
     *      It worth to protect by a mechanism.
     * */

    int all_empty = 1;
    
    // BƯỚC 1: Tìm process trong các queue từ ưu tiên cao (0) đến thấp
    for (int i = 0; i < MAX_PRIO; i++) {
        if (!empty(&mlq_ready_queue[i])) {
            all_empty = 0; // Đánh dấu là hệ thống vẫn còn process đang đợi
            if (slot[i] > 0) {
                proc = dequeue(&mlq_ready_queue[i]);
                slot[i]--; // Lấy ra thì phải trừ slot đi 1
                break;
            }
        }
    }

    // BƯỚC 2: Nếu có process đang đợi nhưng không lấy được cái nào -> TẤT CẢ ĐỀU HẾT SLOT
    if (!all_empty && proc == NULL) {
        // Reset lại toàn bộ slot về giá trị ban đầu
        for (int i = 0; i < MAX_PRIO; i++)
            slot[i] = MAX_PRIO - i;
        
        // Sau khi reset, quét lại lần nữa để lấy process
        for (int i = 0; i < MAX_PRIO; i++) {
            if (!empty(&mlq_ready_queue[i]) && slot[i] > 0) {
                proc = dequeue(&mlq_ready_queue[i]);
                slot[i]--;
                break;
            }
        }
    }

    // Đưa process vào danh sách đang chạy
    if (proc != NULL) 
        enqueue(&running_list, proc);

    // BƯỚC 3: Mở khóa (CỰC KỲ QUAN TRỌNG, THIẾU LÀ TREO MÁY)
    pthread_mutex_unlock(&queue_lock);

    return proc;
}

void put_mlq_proc(struct pcb_t *proc)
{
    proc->krnl->ready_queue = &ready_queue;
    proc->krnl->mlq_ready_queue = mlq_ready_queue;
    proc->krnl->running_list = &running_list;

    /* TODO: put running proc to running_list
     *       It worth to protect by a mechanism.
     *
     */

    pthread_mutex_lock(&queue_lock);
    purgequeue(&running_list, proc);

    enqueue(&mlq_ready_queue[proc->prio], proc);
    pthread_mutex_unlock(&queue_lock);
}

void add_mlq_proc(struct pcb_t *proc)
{
    proc->krnl->ready_queue = &ready_queue;
    proc->krnl->mlq_ready_queue = mlq_ready_queue;
    proc->krnl->running_list = &running_list;

    /* TODO: put running proc to running_list
     *       It worth to protect by a mechanism.
     *
     */

    pthread_mutex_lock(&queue_lock);
    enqueue(&mlq_ready_queue[proc->prio], proc);
    pthread_mutex_unlock(&queue_lock);
}

struct pcb_t *get_proc(void)
{
    return get_mlq_proc();
}

void put_proc(struct pcb_t *proc)
{
    return put_mlq_proc(proc);
}

void add_proc(struct pcb_t *proc)
{
    return add_mlq_proc(proc);
}
#else
struct pcb_t *get_proc(void)
{
    struct pcb_t *proc = NULL;

    pthread_mutex_lock(&queue_lock);
    /*TODO: get a process from [ready_queue].
     *       It worth to protect by a mechanism.
     *
     */
    // Lấy tiến trình đứng đầu hàng đợi ready_queue
    if (!empty(&ready_queue)) 
        proc = dequeue(&ready_queue);

    // Đưa vào danh sách đang chạy
    if (proc != NULL) 
        enqueue(&running_list, proc);

    pthread_mutex_unlock(&queue_lock);

    return proc;
}

void put_proc(struct pcb_t *proc)
{
    proc->krnl->ready_queue = &ready_queue;
    proc->krnl->running_list = &running_list;

    /* TODO: put running proc to running_list
     *       It worth to protect by a mechanism.
     *
     */

    pthread_mutex_lock(&queue_lock);
    purgequeue(&running_list, proc);
    enqueue(&ready_queue, proc);
    pthread_mutex_unlock(&queue_lock);
}

void add_proc(struct pcb_t *proc)
{
    proc->krnl->ready_queue = &ready_queue;
    proc->krnl->running_list = &running_list;

    /* TODO: put running proc to running_list
     *       It worth to protect by a mechanism.
     *
     */

    pthread_mutex_lock(&queue_lock);
    enqueue(&ready_queue, proc);
    pthread_mutex_unlock(&queue_lock);
}
#endif
