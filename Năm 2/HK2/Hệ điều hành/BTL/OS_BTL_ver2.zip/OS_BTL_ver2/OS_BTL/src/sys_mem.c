/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

#include "os-mm.h"
#include "syscall.h"
#include "libmem.h"
#include "queue.h"
#include <stdio.h>
#include <stdlib.h>

#ifdef MM64
#include "mm64.h"
#else
#include "mm.h"
#endif

static struct pcb_t *find_proc_in_queue(struct queue_t *q, uint32_t pid)
{
    int i;

    if (q == NULL)
        return NULL;

    for (i = 0; i < q->size; i++)
    {
        if (q->proc[i] != NULL && q->proc[i]->pid == pid)
            return q->proc[i];
    }

    return NULL;
}

static struct pcb_t *find_proc_by_pid(struct krnl_t *krnl, uint32_t pid)
{
    struct pcb_t *proc;
    int prio;

    if (krnl == NULL)
        return NULL;

    proc = find_proc_in_queue(krnl->running_list, pid);
    if (proc != NULL)
        return proc;

#ifdef MLQ_SCHED
    if (krnl->mlq_ready_queue != NULL)
    {
        for (prio = 0; prio < MAX_PRIO; prio++)
        {
            proc = find_proc_in_queue(&krnl->mlq_ready_queue[prio], pid);
            if (proc != NULL)
                return proc;
        }
    }
#endif

    proc = find_proc_in_queue(krnl->ready_queue, pid);
    if (proc != NULL)
        return proc;

    return NULL;
}

int __sys_memmap(struct krnl_t *krnl, uint32_t pid, struct sc_regs *regs)
{
    int memop;
    BYTE value;
    struct pcb_t *caller;

    if (krnl == NULL || regs == NULL)
        return -1;

    memop = regs->a1;
    caller = find_proc_by_pid(krnl, pid);

    if (caller == NULL)
    {
        printf("[sys_memmap] PID %u not found in kernel process lists\n", pid);
        return -1;
    }

    switch (memop)
    {
    case SYSMEM_MAP_OP:
        return vmap_pgd_memset(caller, regs->a2, regs->a3);

    case SYSMEM_INC_OP:
        return inc_vma_limit(caller, regs->a2, regs->a3);

    case SYSMEM_SWP_OP:
        return __mm_swap_page(caller, regs->a2, regs->a3);

    case SYSMEM_IO_READ:
        if (MEMPHY_read(krnl->mram, regs->a2, &value) != 0)
            return -1;
        regs->a3 = value;
        return 0;

    case SYSMEM_IO_WRITE:
        return MEMPHY_write(krnl->mram, regs->a2, regs->a3);

    default:
        printf("[sys_memmap] invalid memop code: %d\n", memop);
        return -1;
    }
}
