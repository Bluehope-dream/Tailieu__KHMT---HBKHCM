/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

// #ifdef MM_PAGING
/*
 * System Library
 * Memory Module Library libmem.c
 */

#include "string.h"
#include "mm.h"
#include "mm64.h"
#include "syscall.h"
#include "libmem.h"
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <pthread.h>

static pthread_mutex_t mmvm_lock = PTHREAD_MUTEX_INITIALIZER;
#define KERNEL_VMA_BASE ((addr_t)0x8000)
static addr_t kernel_brk = KERNEL_VMA_BASE;

/*enlist_vm_freerg_list - add new rg to freerg_list
 *@mm: memory region
 *@rg_elmt: new region
 *
 */
int enlist_vm_freerg_list(struct mm_struct *mm, struct vm_rg_struct *rg_elmt)
{
  struct vm_rg_struct *rg_node = mm->mmap->vm_freerg_list;

  if (rg_elmt->rg_start >= rg_elmt->rg_end)
    return -1;

  if (rg_node != NULL)
    rg_elmt->rg_next = rg_node;

  /* Enlist the new region */
  mm->mmap->vm_freerg_list = rg_elmt;

  return 0;
}

/*get_symrg_byid - get mem region by region ID
 *@mm: memory region
 *@rgid: region ID act as symbol index of variable
 *
 */
struct vm_rg_struct *get_symrg_byid(struct mm_struct *mm, int rgid)
{
  if (mm == NULL || rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ)
    return NULL;

  return &mm->symrgtbl[rgid];
}

/*__alloc - allocate a region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *@alloc_addr: address of allocated memory region
 *
 */
int __alloc(struct pcb_t *caller, int vmaid, int rgid, addr_t size, addr_t *alloc_addr)
{
  pthread_mutex_lock(&mmvm_lock);

  struct vm_rg_struct rgnode;
  struct vm_area_struct *cur_vma;
  addr_t old_sbrk;
  struct sc_regs regs;

  if (caller == NULL || caller->mm == NULL || alloc_addr == NULL ||
      rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ || size == 0)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  cur_vma = get_vma_by_num(caller->mm, vmaid);
  if (cur_vma == NULL)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  if (get_free_vmrg_area(caller, vmaid, size, &rgnode) == 0)
  {
    caller->mm->symrgtbl[rgid].vmaid = vmaid;
    caller->mm->symrgtbl[rgid].rg_start = rgnode.rg_start;
    caller->mm->symrgtbl[rgid].rg_end = rgnode.rg_end;
    caller->mm->symrgtbl[rgid].rg_next = NULL;
    *alloc_addr = rgnode.rg_start;
    pthread_mutex_unlock(&mmvm_lock);
    return 0;
  }

  old_sbrk = cur_vma->sbrk;

  /* Grow user VMA through the kernel syscall layer. */
  memset(&regs, 0, sizeof(regs));
  regs.a1 = SYSMEM_INC_OP;
  regs.a2 = vmaid;
  regs.a3 = size;
  if (_syscall(caller->krnl, caller->pid, 17, &regs) != 0)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  caller->mm->symrgtbl[rgid].vmaid = vmaid;
  caller->mm->symrgtbl[rgid].rg_start = old_sbrk;
  caller->mm->symrgtbl[rgid].rg_end = old_sbrk + size;
  caller->mm->symrgtbl[rgid].rg_next = NULL;

  *alloc_addr = old_sbrk;
  caller->regs[rgid] = old_sbrk;

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}

/*__free - remove a region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *
 */
int __free(struct pcb_t *caller, int vmaid, int rgid)
{
  pthread_mutex_lock(&mmvm_lock);

  if (caller == NULL || caller->mm == NULL || rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  /* TODO: Manage the collect freed region to freerg_list */
  struct vm_rg_struct *rgnode = get_symrg_byid(caller->mm, rgid);

  if (rgnode->rg_start == 0 && rgnode->rg_end == 0)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }
  struct vm_rg_struct *freerg_node = malloc(sizeof(struct vm_rg_struct));
  freerg_node->rg_start = rgnode->rg_start;
  freerg_node->rg_end = rgnode->rg_end;
  freerg_node->rg_next = NULL;

  rgnode->rg_start = rgnode->rg_end = 0;
  rgnode->rg_next = NULL;

  /*enlist the obsoleted memory region */
  enlist_vm_freerg_list(caller->mm, freerg_node);

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}

/*liballoc - PAGING-based allocate a region memory
 *@proc:  Process executing the instruction
 *@size: allocated size
 *@reg_index: memory region ID (used to identify variable in symbole table)
 */
int liballoc(struct pcb_t *proc, addr_t size, uint32_t reg_index)
{
  addr_t addr;
  int val = __alloc(proc, 0, reg_index, size, &addr);
  if (val == -1)
  {
    return -1;
  }
  if (reg_index < 10)
    proc->regs[reg_index] = addr;
#ifdef IODUMP
  /* TODO dump IO content (if needed) */
#ifdef PAGETBL_DUMP
  print_pgtbl(proc, 0, -1); // print max TBL
#endif
#endif

  /* By default using vmaid = 0 */
  return val;
}

/*libfree - PAGING-based free a region memory
 *@proc: Process executing the instruction
 *@size: allocated size
 *@reg_index: memory region ID (used to identify variable in symbole table)
 */

int libfree(struct pcb_t *proc, uint32_t reg_index)
{
  int val = __free(proc, 0, reg_index);
  if (val == -1)
  {
    return -1;
  }
  printf("[libfree] pid=%u rg=%u released\n", proc->pid, reg_index);
#ifdef IODUMP
  /* TODO dump IO content (if needed) */
#ifdef PAGETBL_DUMP
  print_pgtbl(proc, 0, -1); // print max TBL
#endif
#endif
  return 0; // val;
}

/*pg_getpage - get the page in ram
 *@mm: memory region
 *@pagenum: PGN
 *@framenum: return FPN
 *@caller: caller
 *
 */
int pg_getpage(struct mm_struct *mm, int pgn, int *fpn, struct pcb_t *caller)
{
  uint32_t pte;

  if (mm == NULL || fpn == NULL || caller == NULL)
    return -1;

  pte = pte_get_entry(caller, pgn);
  if (!PAGING_PAGE_PRESENT(pte) || (pte & PAGING_PTE_SWAPPED_MASK))
    return -1;

  *fpn = PAGING_FPN(pte);
  return 0;
}

/*pg_getval - read value at given offset
 *@mm: memory region
 *@addr: virtual address to acess
 *@value: value
 *
 */
int pg_getval(struct mm_struct *mm, int addr, BYTE *data, struct pcb_t *caller)
{
  int pgn = PAGING_PGN(addr);
  int off = PAGING_OFFST(addr);
  int fpn;
  int phyaddr;
  struct sc_regs regs;

  if (data == NULL)
    return -1;

  /* BƯỚC 1: Lấy khung trang. Nếu lỗi -> Xảy ra Page Fault (Trang nằm ở SWAP) */
  if (pg_getpage(mm, pgn, &fpn, caller) != 0)
  {
    addr_t vicpgn;
    int vicfpn, swpfpn;
    uint32_t vicpte, pte;

    // 1.1 Tìm một trang nạn nhân (victim page)
    if (find_victim_page(caller->mm, &vicpgn) < 0)
      return -1; // Không thể tìm thấy trang nạn nhân

    // Lấy FPN của trang nạn nhân trên RAM
    vicpte = pte_get_entry(caller, vicpgn);
    vicfpn = PAGING_FPN(vicpte);

    // Lấy SWPFPN của trang hiện tại đang cần đọc
    pte = pte_get_entry(caller, pgn);
    swpfpn = PAGING_SWP(pte);

    // 1.2 Gọi Syscall để Kernel tiến hành Swap 2 trang này trên phần cứng
    memset(&regs, 0, sizeof(regs));
    regs.a1 = SYSMEM_SWP_OP;
    regs.a2 = vicfpn;
    regs.a3 = swpfpn;
    if (_syscall(caller->krnl, caller->pid, 17, &regs) != 0)
      return -1;

    // 1.3 Cập nhật Bảng phân trang (Page Table)
    pte_set_swap(caller, vicpgn, 0, swpfpn); // Nạn nhân bị đẩy xuống SWAP
    pte_set_fpn(caller, pgn, vicfpn);        // Trang hiện tại được nạp lên RAM

    // Cập nhật fpn để thực hiện thao tác I/O
    fpn = vicfpn; 

    // QUAN TRỌNG: Đưa trang vừa nạp vào lại hàng đợi FIFO để sau này có thể làm nạn nhân
    enlist_pgn_node(&caller->mm->fifo_pgn, pgn); 
  }

  /* BƯỚC 2: Trang đã có trên RAM, tiến hành tính địa chỉ và gọi Syscall Đọc I/O */
  phyaddr = fpn * PAGING_PAGESZ + off;
  memset(&regs, 0, sizeof(regs));
  regs.a1 = SYSMEM_IO_READ;
  regs.a2 = phyaddr;
  
  if (_syscall(caller->krnl, caller->pid, 17, &regs) != 0)
    return -1;

  *data = (BYTE)regs.a3;
  return 0;
}

/*pg_setval - write value to given offset
 *@mm: memory region
 *@addr: virtual address to acess
 *@value: value
 *
 */
int pg_setval(struct mm_struct *mm, int addr, BYTE value, struct pcb_t *caller)
{
  int pgn = PAGING_PGN(addr);
  int off = PAGING_OFFST(addr);
  int fpn;
  int phyaddr;
  struct sc_regs regs;

  /* BƯỚC 1: Lấy khung trang. Nếu lỗi -> Xảy ra Page Fault (Trang nằm ở SWAP) */
  if (pg_getpage(mm, pgn, &fpn, caller) != 0)
  {
    addr_t vicpgn;
    int vicfpn, swpfpn;
    uint32_t vicpte, pte;

    // 1.1 Tìm một trang nạn nhân (victim page)
    if (find_victim_page(caller->mm, &vicpgn) < 0)
      return -1; // Không thể tìm thấy trang nạn nhân

    // Lấy FPN của trang nạn nhân trên RAM
    vicpte = pte_get_entry(caller, vicpgn);
    vicfpn = PAGING_FPN(vicpte);

    // Lấy SWPFPN của trang hiện tại đang cần ghi
    pte = pte_get_entry(caller, pgn);
    swpfpn = PAGING_SWP(pte);

    // 1.2 Gọi Syscall để Kernel tiến hành Swap 2 trang này trên phần cứng
    memset(&regs, 0, sizeof(regs));
    regs.a1 = SYSMEM_SWP_OP;
    regs.a2 = vicfpn;
    regs.a3 = swpfpn;
    if (_syscall(caller->krnl, caller->pid, 17, &regs) != 0)
      return -1;

    // 1.3 Cập nhật Bảng phân trang (Page Table)
    pte_set_swap(caller, vicpgn, 0, swpfpn); // Nạn nhân bị đẩy xuống SWAP
    pte_set_fpn(caller, pgn, vicfpn);        // Trang hiện tại được nạp lên RAM

    // Cập nhật fpn để thực hiện thao tác I/O
    fpn = vicfpn; 

    // QUAN TRỌNG: Đưa trang vừa nạp vào lại hàng đợi FIFO để sau này có thể làm nạn nhân
    enlist_pgn_node(&caller->mm->fifo_pgn, pgn); 
  }

  /* BƯỚC 2: Trang đã có trên RAM, tiến hành tính địa chỉ và gọi Syscall Ghi I/O */
  phyaddr = fpn * PAGING_PAGESZ + off;
  memset(&regs, 0, sizeof(regs));
  regs.a1 = SYSMEM_IO_WRITE;
  regs.a2 = phyaddr;
  regs.a3 = value;
  
  return _syscall(caller->krnl, caller->pid, 17, &regs);
}

/*__read - read value in region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@offset: offset to acess in memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *
 */
int __read(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE *data)
{
    // BƯỚC 1: Khóa Mutex ngay khi bắt đầu thao tác
    pthread_mutex_lock(&mmvm_lock);

    struct vm_rg_struct *currg = get_symrg_byid(caller->mm, rgid);

    // BƯỚC 2: Kiểm tra tính hợp lệ của vùng nhớ
    if (currg == NULL || currg->vmaid != vmaid) {
        pthread_mutex_unlock(&mmvm_lock); // Mở khóa nếu có lỗi
        return -1;
    }
    if (currg->rg_start >= currg->rg_end || currg->rg_start + offset >= currg->rg_end) {
        pthread_mutex_unlock(&mmvm_lock); // Mở khóa nếu có lỗi
        return -1;
    }

    // BƯỚC 3: Thực hiện lấy dữ liệu (Hàm này sẽ xử lý Swap-in nếu cần)
    int ret = pg_getval(caller->mm, currg->rg_start + offset, data, caller);

    // BƯỚC 4: Mở khóa Mutex trước khi trả về kết quả
    pthread_mutex_unlock(&mmvm_lock);
    return ret;
}

/*libread - PAGING-based read a region memory */
int libread(
    struct pcb_t *proc,
    uint32_t source,
    addr_t offset,
    uint32_t *destination)
{
  BYTE data;
  int val = __read(proc, 0, source, offset, &data);

  if (val == 0)
  {
    *destination = data;
    printf("[libread] pid=%u rg=%u offset=" FORMAT_ADDR " -> value=%u\n",
           proc->pid, source, offset, (unsigned char)data);
  }
#ifdef IODUMP
#ifdef PAGETBL_DUMP
  print_pgtbl(proc, 0, -1);
#endif
#endif

  return val;
}

/*__write - write a region memory
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@offset: offset to acess in memory region
 *@rgid: memory region ID (used to identify variable in symbole table)
 *@size: allocated size
 *
 */
int __write(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE value)
{
  // BƯỚC 1: Khóa tài nguyên để đảm bảo an toàn đa luồng
  pthread_mutex_lock(&mmvm_lock);

  struct vm_rg_struct *currg = get_symrg_byid(caller->mm, rgid);

  // BƯỚC 2: Kiểm tra tính hợp lệ của vùng nhớ (Region)
  if (currg == NULL || currg->vmaid != vmaid) {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  // Kiểm tra tràn vùng nhớ (Out of bound)
  if (currg->rg_start >= currg->rg_end || currg->rg_start + offset >= currg->rg_end) {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  // BƯỚC 3: Gọi hàm ghi dữ liệu xuống tầng phân trang (Paging)
  // Địa chỉ ảo cần ghi = Địa chỉ bắt đầu của biến + khoảng lệch (offset)
  int ret = pg_setval(caller->mm, currg->rg_start + offset, value, caller);

  // BƯỚC 4: Luôn mở khóa trước khi kết thúc hàm
  pthread_mutex_unlock(&mmvm_lock);
  return ret;
}

/*libwrite - PAGING-based write a region memory */
int libwrite(
    struct pcb_t *proc,
    BYTE data,
    uint32_t destination,
    addr_t offset)
{
  int val = __write(proc, 0, destination, offset, data);
  if (val == 0)
    printf("[libwrite] pid=%u rg=%u offset=" FORMAT_ADDR " <- value=%u\n",
           proc->pid, destination, offset, (unsigned char)data);
#ifdef IODUMP
#ifdef PAGETBL_DUMP
  print_pgtbl(proc, 0, -1);
#endif
#endif

  return val;
}

// Helper function 
static int kernel_pte_set_fpn(struct krnl_t *krnl, addr_t pgn, addr_t fpn)
{
  addr_t pte = 0;

  if (krnl == NULL || krnl->krnl_pt == NULL || pgn >= PAGING_MAX_PGN)
    return -1;

  init_pte(&pte, 1, fpn, 0, 0, 0, 0);
  krnl->krnl_pt[pgn] = pte;
  return 0;
}

static uint32_t kernel_pte_get_entry(struct krnl_t *krnl, addr_t pgn)
{
  if (krnl == NULL || krnl->krnl_pt == NULL || pgn >= PAGING_MAX_PGN)
    return 0;

  return (uint32_t)krnl->krnl_pt[pgn];
}

static int kernel_map_range(struct pcb_t *caller, addr_t addr, addr_t size)
{
  addr_t alignedsz = PAGING_PAGE_ALIGNSZ(size);
  int pgnum = alignedsz / PAGING_PAGESZ;
  addr_t pgn = PAGING_PGN(addr);
  int i;

  for (i = 0; i < pgnum; i++)
  {
    addr_t fpn;
    if (MEMPHY_get_freefp(caller->krnl->mram, &fpn) != 0)
      return -1;
    if (kernel_pte_set_fpn(caller->krnl, pgn + i, fpn) != 0)
      return -1;
  }

  return 0;
}
// TODO FUNCTION 
/* libkmem_malloc - allocate a kernel-space region. */
int libkmem_malloc(struct pcb_t *caller, uint32_t size, uint32_t reg_index)
{
  addr_t addr;
  int val = __kmalloc(caller, -1, reg_index, size, &addr);
  if (val != 0)
    return -1;

  caller->regs[reg_index] = addr;
  printf("[kmalloc] pid=%u rg=%u kernel_addr=" FORMAT_ADDR " size=%u\n",
         caller->pid, reg_index, addr, size);
  return 0;
}

addr_t __kmalloc(struct pcb_t *caller, int vmaid, int rgid, addr_t size, addr_t *alloc_addr)
{
  addr_t addr;

  (void)vmaid;

  if (caller == NULL || caller->mm == NULL || caller->krnl == NULL ||
      alloc_addr == NULL || rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ || size == 0)
    return -1;

  pthread_mutex_lock(&mmvm_lock);
  addr = kernel_brk;
  kernel_brk += PAGING_PAGE_ALIGNSZ(size);

  if (kernel_map_range(caller, addr, size) != 0)
  {
    pthread_mutex_unlock(&mmvm_lock);
    return -1;
  }

  caller->mm->symrgtbl[rgid].vmaid = -1; /* kernel-space marker */
  caller->mm->symrgtbl[rgid].rg_start = addr;
  caller->mm->symrgtbl[rgid].rg_end = addr + size;
  caller->mm->symrgtbl[rgid].rg_next = NULL;
  *alloc_addr = addr;

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}

int libkmem_cache_pool_create(struct pcb_t *caller, uint32_t size, uint32_t align, uint32_t cache_pool_id)
{
  addr_t addr;

  if (caller == NULL || caller->mm == NULL || caller->mm->kcpooltbl == NULL ||
      cache_pool_id >= PAGING_MAX_SYMTBL_SZ || align == 0 || size == 0)
    return -1;

  if (__kmalloc(caller, -1, cache_pool_id, size, &addr) != 0)
    return -1;

  caller->mm->kcpooltbl[cache_pool_id].size = size;
  caller->mm->kcpooltbl[cache_pool_id].align = align;
  caller->mm->kcpooltbl[cache_pool_id].storage = addr;
  return 0;
}

int libkmem_cache_alloc(struct pcb_t *proc, uint32_t cache_pool_id, uint32_t reg_index)
{
  addr_t addr;
  int val = __kmem_cache_alloc(proc, -1, reg_index, cache_pool_id, &addr);
  if (val != 0)
    return -1;

  proc->regs[reg_index] = addr;
  return 0;
}

addr_t __kmem_cache_alloc(struct pcb_t *caller, int vmaid, int rgid, int cache_pool_id, addr_t *alloc_addr)
{
  struct kcache_pool_struct *pool;

  (void)vmaid;

  if (caller == NULL || caller->mm == NULL || caller->mm->kcpooltbl == NULL ||
      alloc_addr == NULL || rgid < 0 || rgid >= PAGING_MAX_SYMTBL_SZ ||
      cache_pool_id < 0 || cache_pool_id >= PAGING_MAX_SYMTBL_SZ)
    return -1;

  pool = &caller->mm->kcpooltbl[cache_pool_id];
  if (pool->storage == 0 || pool->align == 0)
    return -1;

  /* Minimal slab-like behavior for the assignment demo: return the first slot. */
  caller->mm->symrgtbl[rgid].vmaid = -1;
  caller->mm->symrgtbl[rgid].rg_start = pool->storage;
  caller->mm->symrgtbl[rgid].rg_end = pool->storage + pool->align;
  caller->mm->symrgtbl[rgid].rg_next = NULL;
  *alloc_addr = pool->storage;
  return 0;
}

int libkmem_copy_from_user(struct pcb_t *caller, uint32_t source, uint32_t destination, uint32_t offset, uint32_t size)
{
  uint32_t i;

  for (i = 0; i < size; i++)
  {
    BYTE data;
    if (__read_user_mem(caller, 0, source, offset + i, &data) != 0)
      return -1;
    if (__write_kernel_mem(caller, -1, destination, offset + i, data) != 0)
      return -1;
  }
  printf("[copy_from_user] pid=%u user_rg=%u -> kernel_rg=%u offset=%u size=%u\n",
         caller->pid, source, destination, offset, size);
  return 0;
}

int libkmem_copy_to_user(struct pcb_t *caller, uint32_t source, uint32_t destination, uint32_t offset, uint32_t size)
{
  uint32_t i;

  for (i = 0; i < size; i++)
  {
    BYTE data;
    if (__read_kernel_mem(caller, -1, source, offset + i, &data) != 0)
      return -1;
    if (__write_user_mem(caller, 0, destination, offset + i, data) != 0)
      return -1;
  }
  printf("[copy_to_user] pid=%u kernel_rg=%u -> user_rg=%u offset=%u size=%u\n",
         caller->pid, source, destination, offset, size);
  return 0;
}

int __read_kernel_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE *data)
{
  struct vm_rg_struct *currg;
  uint32_t pte;
  int pgn, off, fpn, phyaddr;

  (void)vmaid;

  if (caller == NULL || caller->mm == NULL || data == NULL)
    return -1;

  currg = get_symrg_byid(caller->mm, rgid);
  if (currg == NULL || currg->vmaid != -1 ||
      currg->rg_start >= currg->rg_end || currg->rg_start + offset >= currg->rg_end)
    return -1;

  pgn = PAGING_PGN((currg->rg_start + offset));
  off = PAGING_OFFST((currg->rg_start + offset));
  pte = kernel_pte_get_entry(caller->krnl, pgn);
  if (!PAGING_PAGE_PRESENT(pte))
    return -1;

  fpn = PAGING_FPN(pte);
  phyaddr = fpn * PAGING_PAGESZ + off;
  return MEMPHY_read(caller->krnl->mram, phyaddr, data);
}

int __write_kernel_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE value)
{
  struct vm_rg_struct *currg;
  uint32_t pte;
  int pgn, off, fpn, phyaddr;

  (void)vmaid;

  if (caller == NULL || caller->mm == NULL)
    return -1;

  currg = get_symrg_byid(caller->mm, rgid);
  if (currg == NULL || currg->vmaid != -1 ||
      currg->rg_start >= currg->rg_end || currg->rg_start + offset >= currg->rg_end)
    return -1;

  pgn = PAGING_PGN((currg->rg_start + offset));
  off = PAGING_OFFST((currg->rg_start + offset));
  pte = kernel_pte_get_entry(caller->krnl, pgn);
  if (!PAGING_PAGE_PRESENT(pte))
    return -1;

  fpn = PAGING_FPN(pte);
  phyaddr = fpn * PAGING_PAGESZ + off;
  return MEMPHY_write(caller->krnl->mram, phyaddr, value);
}

int __read_user_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE *data)
{
  return __read(caller, vmaid, rgid, offset, data);
}

int __write_user_mem(struct pcb_t *caller, int vmaid, int rgid, addr_t offset, BYTE value)
{
  return __write(caller, vmaid, rgid, offset, value);
}

/*free_pcb_memphy - collect all memphy of pcb
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@incpgnum: number of page
 */
int free_pcb_memph(struct pcb_t *caller)
{
  pthread_mutex_lock(&mmvm_lock);
  int pagenum, fpn;
  uint32_t pte;

  for (pagenum = 0; pagenum < PAGING_MAX_PGN; pagenum++)
  {
    pte = caller->mm->pgd[pagenum];

    if (PAGING_PAGE_PRESENT(pte))
    {
      fpn = PAGING_FPN(pte);
      MEMPHY_put_freefp(caller->krnl->mram, fpn);
    }
    else
    {
      fpn = PAGING_SWP(pte);
      MEMPHY_put_freefp(caller->krnl->active_mswp, fpn);
    }
  }

  pthread_mutex_unlock(&mmvm_lock);
  return 0;
}

/*find_victim_page - find victim page
 *@caller: caller
 *@pgn: return page number
 *
 */
int find_victim_page(struct mm_struct *mm, addr_t *retpgn)
{
  struct pgn_t *pg;
  struct pgn_t *prev = NULL;

  if (mm == NULL || retpgn == NULL || mm->fifo_pgn == NULL)
    return -1;

  pg = mm->fifo_pgn;
  while (pg->pg_next != NULL)
  {
    prev = pg;
    pg = pg->pg_next;
  }

  *retpgn = pg->pgn;
  if (prev == NULL)
    mm->fifo_pgn = NULL;
  else
    prev->pg_next = NULL;

  free(pg);
  return 0;
}

/*get_free_vmrg_area - get a free vm region
 *@caller: caller
 *@vmaid: ID vm area to alloc memory region
 *@size: allocated size
 *
 */
int get_free_vmrg_area(struct pcb_t *caller, int vmaid, int size, struct vm_rg_struct *newrg)
{
  struct vm_area_struct *cur_vma = get_vma_by_num(caller->mm, vmaid);

  struct vm_rg_struct *rgit = cur_vma->vm_freerg_list;

  if (rgit == NULL)
    return -1;

  /* Probe unintialized newrg */
  newrg->rg_start = newrg->rg_end = -1;

  /* Traverse on list of free vm region to find a fit space */
  while (rgit != NULL)
  {
    if (rgit->rg_start + size <= rgit->rg_end)
    { /* Current region has enough space */
      newrg->rg_start = rgit->rg_start;
      newrg->rg_end = rgit->rg_start + size;

      /* Update left space in chosen region */
      if (rgit->rg_start + size < rgit->rg_end)
      {
        rgit->rg_start = rgit->rg_start + size;
      }
      else
      { /*Use up all space, remove current node */
        /*Clone next rg node */
        struct vm_rg_struct *nextrg = rgit->rg_next;

        /*Cloning */
        if (nextrg != NULL)
        {
          rgit->rg_start = nextrg->rg_start;
          rgit->rg_end = nextrg->rg_end;

          rgit->rg_next = nextrg->rg_next;

          free(nextrg);
        }
        else
        {                                /*End of free list */
          rgit->rg_start = rgit->rg_end; // dummy, size 0 region
          rgit->rg_next = NULL;
        }
      }
      break;
    }
    else
    {
      rgit = rgit->rg_next; // Traverse next rg
    }
  }

  if (newrg->rg_start == -1) // new region not found
    return -1;

  return 0;
}

// #endif