/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* LamiaAtrium release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

/*
 * PAGING based Memory Management
 * 64-bit theoretical page-directory support + simulator page mapping.
 */

#include "mm64.h"
#include <stdlib.h>
#include <stdio.h>
#include <string.h>

#if defined(MM64)

static addr_t pgtbl_capacity(void)
{
  return PAGING_MAX_PGN;
}

int init_pte(addr_t *pte,
             int pre,
             addr_t fpn,
             int drt,
             int swp,
             int swptyp,
             addr_t swpoff)
{
  if (pte == NULL)
    return -1;

  *pte = 0;
  if (pre != 0)
  {
    SETBIT(*pte, PAGING_PTE_PRESENT_MASK);
    if (drt != 0)
      SETBIT(*pte, PAGING_PTE_DIRTY_MASK);
    else
      CLRBIT(*pte, PAGING_PTE_DIRTY_MASK);

    if (swp == 0)
    {
      CLRBIT(*pte, PAGING_PTE_SWAPPED_MASK);
      SETVAL(*pte, fpn, PAGING_PTE_FPN_MASK, PAGING_PTE_FPN_LOBIT);
    }
    else
    {
      SETBIT(*pte, PAGING_PTE_SWAPPED_MASK);
      SETVAL(*pte, swptyp, PAGING_PTE_SWPTYP_MASK, PAGING_PTE_SWPTYP_LOBIT);
      SETVAL(*pte, swpoff, PAGING_PTE_SWPOFF_MASK, PAGING_PTE_SWPOFF_LOBIT);
    }
  }

  return 0;
}

int get_pd_from_address(addr_t addr, addr_t *pgd, addr_t *p4d, addr_t *pud, addr_t *pmd, addr_t *pt)
{
  if (pgd == NULL || p4d == NULL || pud == NULL || pmd == NULL || pt == NULL)
    return -1;

  *pgd = (addr & PAGING64_ADDR_PGD_MASK) >> PAGING64_ADDR_PGD_LOBIT;
  *p4d = (addr & PAGING64_ADDR_P4D_MASK) >> PAGING64_ADDR_P4D_LOBIT;
  *pud = (addr & PAGING64_ADDR_PUD_MASK) >> PAGING64_ADDR_PUD_LOBIT;
  *pmd = (addr & PAGING64_ADDR_PMD_MASK) >> PAGING64_ADDR_PMD_LOBIT;
  *pt  = (addr & PAGING64_ADDR_PT_MASK)  >> PAGING64_ADDR_PT_LOBIT;

  return 0;
}

int get_pd_from_pagenum(addr_t pgn, addr_t *pgd, addr_t *p4d, addr_t *pud, addr_t *pmd, addr_t *pt)
{
  return get_pd_from_address(pgn << PAGING_ADDR_PGN_LOBIT, pgd, p4d, pud, pmd, pt);
}

int pte_set_swap(struct pcb_t *caller, addr_t pgn, int swptyp, addr_t swpoff)
{
  addr_t val = 0;

  if (caller == NULL || caller->mm == NULL || pgn >= pgtbl_capacity())
    return -1;

  init_pte(&val, 1, 0, 0, 1, swptyp, swpoff);
  caller->mm->pt[pgn] = val;
  caller->mm->pgd[pgn] = val; /* compatibility with older helper code */
  return 0;
}

int pte_set_fpn(struct pcb_t *caller, addr_t pgn, addr_t fpn)
{
  addr_t val = 0;

  if (caller == NULL || caller->mm == NULL || pgn >= pgtbl_capacity())
    return -1;

  init_pte(&val, 1, fpn, 0, 0, 0, 0);
  caller->mm->pt[pgn] = val;
  caller->mm->pgd[pgn] = val; /* compatibility with older helper code */
  return 0;
}

uint32_t pte_get_entry(struct pcb_t *caller, addr_t pgn)
{
  if (caller == NULL || caller->mm == NULL || pgn >= pgtbl_capacity())
    return 0;

  return (uint32_t)caller->mm->pt[pgn];
}

int pte_set_entry(struct pcb_t *caller, addr_t pgn, uint32_t pte_val)
{
  if (caller == NULL || caller->mm == NULL || pgn >= pgtbl_capacity())
    return -1;

  caller->mm->pt[pgn] = pte_val;
  caller->mm->pgd[pgn] = pte_val;
  return 0;
}

int vmap_pgd_memset(struct pcb_t *caller, addr_t addr, int pgnum)
{
  addr_t pgn;
  int pgit;

  if (caller == NULL || caller->mm == NULL || pgnum < 0)
    return -1;

  pgn = PAGING_PGN(addr);
  for (pgit = 0; pgit < pgnum && (pgn + pgit) < pgtbl_capacity(); pgit++)
  {
    caller->mm->pt[pgn + pgit] = 0xDEADBEEF;
    caller->mm->pgd[pgn + pgit] = 0xDEADBEEF;
  }

  printf("[sys_memmap] vmap_pgd_memset pid=%u addr=" FORMAT_ADDR " pages=%d\n",
         caller->pid, addr, pgnum);
  return 0;
}

addr_t vmap_page_range(struct pcb_t *caller,
                       addr_t addr,
                       int pgnum,
                       struct framephy_struct *frames,
                       struct vm_rg_struct *ret_rg)
{
  struct framephy_struct *fpit;
  addr_t pgn;
  int pgit;

  if (caller == NULL || caller->mm == NULL || ret_rg == NULL)
    return -1;

  pgn = PAGING_PGN(addr);
  fpit = frames;

  ret_rg->vmaid = 0;
  ret_rg->rg_start = addr;
  ret_rg->rg_end = addr;

  for (pgit = 0; pgit < pgnum; pgit++)
  {
    if (fpit == NULL || (pgn + pgit) >= pgtbl_capacity())
      return -1;

    pte_set_fpn(caller, pgn + pgit, fpit->fpn);
    enlist_pgn_node(&caller->mm->fifo_pgn, pgn + pgit);
    ret_rg->rg_end += PAGING_PAGESZ;
    fpit = fpit->fp_next;
  }

  return 0;
}

addr_t alloc_pages_range(struct pcb_t *caller, int req_pgnum, struct framephy_struct **frm_lst)
{
  int pgit;
  addr_t fpn;
  struct framephy_struct *head = NULL;
  struct framephy_struct *tail = NULL;

  if (caller == NULL || caller->krnl == NULL || frm_lst == NULL || req_pgnum <= 0)
    return -1;

  for (pgit = 0; pgit < req_pgnum; pgit++)
  {
    struct framephy_struct *newfp;

    if (MEMPHY_get_freefp(caller->krnl->mram, &fpn) != 0)
      return -3000;

    newfp = malloc(sizeof(struct framephy_struct));
    if (newfp == NULL)
      return -1;

    newfp->fpn = fpn;
    newfp->fp_next = NULL;
    newfp->owner = caller->mm;

    if (head == NULL)
      head = newfp;
    else
      tail->fp_next = newfp;
    tail = newfp;
  }

  *frm_lst = head;
  return 0;
}

addr_t vm_map_ram(struct pcb_t *caller, addr_t astart, addr_t aend,
                  addr_t mapstart, int incpgnum, struct vm_rg_struct *ret_rg)
{
  struct framephy_struct *frm_lst = NULL;
  addr_t ret_alloc;

  (void)astart;
  (void)aend;

  ret_alloc = alloc_pages_range(caller, incpgnum, &frm_lst);
  if (ret_alloc < 0)
    return -1;

  return vmap_page_range(caller, mapstart, incpgnum, frm_lst, ret_rg);
}

int __swap_cp_page(struct memphy_struct *mpsrc, addr_t srcfpn,
                   struct memphy_struct *mpdst, addr_t dstfpn)
{
  int cellidx;
  addr_t addrsrc, addrdst;

  if (mpsrc == NULL || mpdst == NULL)
    return -1;

  for (cellidx = 0; cellidx < PAGING_PAGESZ; cellidx++)
  {
    BYTE data;
    addrsrc = srcfpn * PAGING_PAGESZ + cellidx;
    addrdst = dstfpn * PAGING_PAGESZ + cellidx;
    MEMPHY_read(mpsrc, addrsrc, &data);
    MEMPHY_write(mpdst, addrdst, data);
  }

  return 0;
}

int init_mm(struct mm_struct *mm, struct pcb_t *caller)
{
  struct vm_area_struct *vma0;
  int i;
  addr_t cap = pgtbl_capacity();

  if (mm == NULL)
    return -1;

  mm->pgd = calloc(cap, sizeof(addr_t));
  mm->p4d = calloc(cap, sizeof(addr_t));
  mm->pud = calloc(cap, sizeof(addr_t));
  mm->pmd = calloc(cap, sizeof(addr_t));
  mm->pt  = calloc(cap, sizeof(addr_t));
  if (mm->pgd == NULL || mm->p4d == NULL || mm->pud == NULL ||
      mm->pmd == NULL || mm->pt == NULL)
    return -1;

  for (i = 0; i < PAGING_MAX_SYMTBL_SZ; i++)
  {
    mm->symrgtbl[i].vmaid = 0;
    mm->symrgtbl[i].rg_start = 0;
    mm->symrgtbl[i].rg_end = 0;
    mm->symrgtbl[i].rg_next = NULL;
  }

  mm->fifo_pgn = NULL;
  mm->kcpooltbl = calloc(PAGING_MAX_SYMTBL_SZ, sizeof(struct kcache_pool_struct));

  vma0 = malloc(sizeof(struct vm_area_struct));
  if (vma0 == NULL)
    return -1;

  vma0->vm_id = 0;
  vma0->vm_start = 0;
  vma0->vm_end = 0;
  vma0->sbrk = 0;
  vma0->vm_mm = mm;
  vma0->vm_freerg_list = NULL;
  vma0->vm_next = NULL;

  mm->mmap = vma0;
  if (caller != NULL)
    caller->mm = mm;

  return 0;
}

struct vm_rg_struct *init_vm_rg(addr_t rg_start, addr_t rg_end)
{
  struct vm_rg_struct *rgnode = malloc(sizeof(struct vm_rg_struct));
  if (rgnode == NULL)
    return NULL;

  rgnode->vmaid = 0;
  rgnode->rg_start = rg_start;
  rgnode->rg_end = rg_end;
  rgnode->rg_next = NULL;
  return rgnode;
}

int enlist_vm_rg_node(struct vm_rg_struct **rglist, struct vm_rg_struct *rgnode)
{
  if (rglist == NULL || rgnode == NULL)
    return -1;

  rgnode->rg_next = *rglist;
  *rglist = rgnode;
  return 0;
}

int enlist_pgn_node(struct pgn_t **plist, addr_t pgn)
{
  struct pgn_t *pnode;

  if (plist == NULL)
    return -1;

  pnode = malloc(sizeof(struct pgn_t));
  if (pnode == NULL)
    return -1;

  pnode->pgn = pgn;
  pnode->pg_next = *plist;
  *plist = pnode;
  return 0;
}

int print_list_fp(struct framephy_struct *ifp)
{
  struct framephy_struct *fp = ifp;

  printf("print_list_fp: ");
  if (fp == NULL)
  {
    printf("NULL list\n");
    return -1;
  }

  printf("\n");
  while (fp != NULL)
  {
    printf("fp[" FORMAT_ADDR "]\n", fp->fpn);
    fp = fp->fp_next;
  }
  printf("\n");
  return 0;
}

int print_list_rg(struct vm_rg_struct *irg)
{
  struct vm_rg_struct *rg = irg;

  printf("print_list_rg: ");
  if (rg == NULL)
  {
    printf("NULL list\n");
    return -1;
  }

  printf("\n");
  while (rg != NULL)
  {
    printf("rg[" FORMAT_ADDR "->" FORMAT_ADDR "]\n", rg->rg_start, rg->rg_end);
    rg = rg->rg_next;
  }
  printf("\n");
  return 0;
}

int print_list_vma(struct vm_area_struct *ivma)
{
  struct vm_area_struct *vma = ivma;

  printf("print_list_vma: ");
  if (vma == NULL)
  {
    printf("NULL list\n");
    return -1;
  }

  printf("\n");
  while (vma != NULL)
  {
    printf("va[" FORMAT_ADDR "->" FORMAT_ADDR "] sbrk=" FORMAT_ADDR "\n",
           vma->vm_start, vma->vm_end, vma->sbrk);
    vma = vma->vm_next;
  }
  printf("\n");
  return 0;
}

int print_list_pgn(struct pgn_t *ip)
{
  printf("print_list_pgn: ");
  if (ip == NULL)
  {
    printf("NULL list\n");
    return -1;
  }

  printf("\n");
  while (ip != NULL)
  {
    printf("pgn[" FORMAT_ADDR "]\n", ip->pgn);
    ip = ip->pg_next;
  }
  printf("\n");
  return 0;
}

int print_pgtbl(struct pcb_t *caller, addr_t start, addr_t end)
{
  addr_t pgn_start, pgn_end, pgit;

  if (caller == NULL || caller->mm == NULL)
    return -1;

  pgn_start = PAGING_PGN(start);
  if (end == (addr_t)-1)
    pgn_end = pgtbl_capacity() - 1;
  else
    pgn_end = PAGING_PGN(end);

  printf("print_pgtbl: pid=%u\n", caller->pid);
  for (pgit = pgn_start; pgit <= pgn_end && pgit < pgtbl_capacity(); pgit++)
  {
    uint32_t pte = pte_get_entry(caller, pgit);
    if (pte != 0)
    {
      addr_t pgd, p4d, pud, pmd, pt;
      get_pd_from_pagenum(pgit, &pgd, &p4d, &pud, &pmd, &pt);
      printf("  PGN=" FORMAT_ADDR " PGD=" FORMAT_ADDR " P4D=" FORMAT_ADDR
             " PUD=" FORMAT_ADDR " PMD=" FORMAT_ADDR " PT=" FORMAT_ADDR
             " PTE=0x%08x",
             pgit, pgd, p4d, pud, pmd, pt, pte);
      if (PAGING_PAGE_PRESENT(pte) && !(pte & PAGING_PTE_SWAPPED_MASK))
        printf(" FPN=%u", PAGING_FPN(pte));
      if (pte & PAGING_PTE_SWAPPED_MASK)
        printf(" SWP=%u", PAGING_SWP(pte));
      printf("\n");
    }
  }

  return 0;
}

#endif /* MM64 */
