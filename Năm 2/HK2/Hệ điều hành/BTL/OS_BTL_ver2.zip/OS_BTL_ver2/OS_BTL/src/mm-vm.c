/*
 * Copyright (C) 2026 pdnguyen of HCMC University of Technology VNU-HCM
 */

/* Caitoa release
 * Source Code License Grant: The authors hereby grant to Licensee
 * personal permission to use and modify the Licensed Source Code
 * for the sole purpose of studying while attending the course CO2018.
 */

/*
 * PAGING based Memory Management
 * Virtual memory module mm/mm-vm.c
 */

#include "string.h"
#include "mm.h"
#include <stdlib.h>
#include <stdio.h>
#include <pthread.h>

/* get_vma_by_num - get vm area by numID */
struct vm_area_struct *get_vma_by_num(struct mm_struct *mm, int vmaid)
{
  struct vm_area_struct *pvma;

  if (mm == NULL || mm->mmap == NULL)
    return NULL;

  pvma = mm->mmap;
  while (pvma != NULL)
  {
    if ((int)pvma->vm_id == vmaid)
      return pvma;
    pvma = pvma->vm_next;
  }

  return NULL;
}

int __mm_swap_page(struct pcb_t *caller, addr_t vicfpn, addr_t swpfpn)
{
  if (caller == NULL || caller->krnl == NULL)
    return -1;

  return __swap_cp_page(caller->krnl->mram, vicfpn,
                        caller->krnl->active_mswp, swpfpn);
}

/* get_vm_area_node_at_brk - create a new region at current sbrk */
struct vm_rg_struct *get_vm_area_node_at_brk(struct pcb_t *caller, int vmaid,
                                             addr_t size, addr_t alignedsz)
{
  struct vm_rg_struct *newrg;
  struct vm_area_struct *cur_vma;

  if (caller == NULL || caller->mm == NULL)
    return NULL;

  cur_vma = get_vma_by_num(caller->mm, vmaid);
  if (cur_vma == NULL)
    return NULL;

  newrg = malloc(sizeof(struct vm_rg_struct));
  if (newrg == NULL)
    return NULL;

  newrg->vmaid = vmaid;
  newrg->rg_start = cur_vma->sbrk;
  newrg->rg_end = cur_vma->sbrk + alignedsz;
  newrg->rg_next = NULL;

  (void)size;
  return newrg;
}

int validate_overlap_vm_area(struct pcb_t *caller, int vmaid,
                             addr_t vmastart, addr_t vmaend)
{
  struct vm_area_struct *vma;
  struct vm_area_struct *cur_area;

  if (caller == NULL || caller->mm == NULL || vmastart >= vmaend)
    return -1;

  cur_area = get_vma_by_num(caller->mm, vmaid);
  if (cur_area == NULL)
    return -1;

  vma = caller->mm->mmap;
  while (vma != NULL)
  {
    if (vma != cur_area && OVERLAP(vmastart, vmaend, vma->vm_start, vma->vm_end))
      return -1;
    vma = vma->vm_next;
  }

  return 0;
}

/* inc_vma_limit - increase vm area limit and map new pages */
int inc_vma_limit(struct pcb_t *caller, int vmaid, addr_t inc_sz)
{
  struct vm_area_struct *cur_vma;
  struct vm_rg_struct *newrg;
  addr_t old_sbrk;
  addr_t alignedsz;
  int incpgnum;

  if (caller == NULL || caller->mm == NULL || inc_sz == 0)
    return -1;

  cur_vma = get_vma_by_num(caller->mm, vmaid);
  if (cur_vma == NULL)
    return -1;

  /* The simulator's physical memory formatter uses PAGING_PAGESZ (256B).
   * MM64 is used here for long-address index extraction/logging, while the
   * actual RAM/SWAP frame granularity remains the simulator page size.
   */
  alignedsz = PAGING_PAGE_ALIGNSZ(inc_sz);
  incpgnum = alignedsz / PAGING_PAGESZ;

  old_sbrk = cur_vma->sbrk;
  newrg = get_vm_area_node_at_brk(caller, vmaid, inc_sz, alignedsz);
  if (newrg == NULL)
    return -1;

  if (validate_overlap_vm_area(caller, vmaid, old_sbrk, old_sbrk + alignedsz) < 0)
  {
    free(newrg);
    return -1;
  }

  if (vm_map_ram(caller, cur_vma->vm_start, cur_vma->vm_end,
                 old_sbrk, incpgnum, newrg) < 0)
  {
    free(newrg);
    return -1;
  }

  cur_vma->sbrk += alignedsz;
  if (cur_vma->sbrk > cur_vma->vm_end)
    cur_vma->vm_end = cur_vma->sbrk;

  enlist_vm_rg_node(&cur_vma->vm_freerg_list, newrg);
  return 0;
}
