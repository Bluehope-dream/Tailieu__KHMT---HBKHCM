#!/usr/bin/env bash
set -euo pipefail

make clean >/tmp/member2_make_clean.log 2>&1 || true
make all >/tmp/member2_make_all.log 2>&1

mkdir -p output

declare -A checks
checks[os_syscall_list]='0-sys_listsyscall|17-sys_memmap|CPU 0 stopped'
checks[member2_mem]='[libwrite] pid=1 rg=1 offset=0 <- value=65|[libread] pid=1 rg=1 offset=0 -> value=65|[libread] pid=1 rg=1 offset=1 -> value=66|[libfree] pid=1 rg=1 released|CPU 0 stopped'
checks[member2_kcopy]='[kmalloc] pid=1 rg=2|[copy_from_user] pid=1 user_rg=1 -> kernel_rg=2 offset=0 size=2|[copy_to_user] pid=1 kernel_rg=2 -> user_rg=3 offset=0 size=2|[libread] pid=1 rg=3 offset=0 -> value=65|[libread] pid=1 rg=3 offset=1 -> value=66|CPU 0 stopped'
checks[member2_sysmap]='[sys_memmap] vmap_pgd_memset pid=1 addr=0 pages=2|CPU 0 stopped'

for cfg in os_syscall_list member2_mem member2_kcopy member2_sysmap; do
  echo "[RUN] ./os $cfg"
  ./os "$cfg" > "output/${cfg}.output" 2>&1
  IFS='|' read -r -a tokens <<< "${checks[$cfg]}"
  for token in "${tokens[@]}"; do
    if ! grep -Fq "$token" "output/${cfg}.output"; then
      echo "[FAIL] $cfg missing token: $token"
      echo "--- output/${cfg}.output ---"
      cat "output/${cfg}.output"
      exit 1
    fi
  done
  echo "[PASS] $cfg"
done

echo "All Member 2 tests passed. Outputs are in output/*.output"
