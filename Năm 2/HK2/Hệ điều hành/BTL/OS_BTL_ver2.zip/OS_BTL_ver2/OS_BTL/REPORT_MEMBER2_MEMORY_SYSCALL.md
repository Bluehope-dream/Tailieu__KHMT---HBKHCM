# Thành viên 2 — Memory Management & System Call

## 1. Mục tiêu

Phần này hiện thực các yêu cầu chính sau:

1. Thiết lập paging cơ bản cho từng tiến trình.
2. Tách không gian bộ nhớ user space và kernel space.
3. Hiện thực system call `listsyscall` và `memmap`.
4. Không truyền trực tiếp con trỏ PCB từ user sang kernel; system call chỉ truyền `pid` và tham số qua `struct sc_regs`.
5. Bổ sung test input, expected output và actual output cho phần memory/syscall.

## 2. Các file code đã chỉnh

| File | Nội dung chỉnh |
|---|---|
| `include/common.h` | Thêm `struct mm_struct *mm` vào PCB để mỗi process có user memory map riêng; thêm kernel page table trong `struct krnl_t`. |
| `include/mm.h` | Sửa `INCLUDE`, `OVERLAP`; bổ sung prototype cho paging, kernel memory, user/kernel copy. |
| `src/os.c` | Khi loader tạo process: cấp phát `proc->mm`, gọi `init_mm(proc->mm, proc)`, khởi tạo kernel page table. |
| `src/syscall.c` | `_syscall()` gọi syscall handler với `krnl`, `pid`, `regs`. |
| `src/sys_mem.c` | Xóa dummy PCB; tìm process thật bằng PID trong `running_list`, `mlq_ready_queue`, `ready_queue`. |
| `src/sys_listsyscall.c` | In danh sách syscall trong `sys_call_table`. |
| `src/mm64.c` | Khởi tạo page table, set/get PTE, map virtual page sang frame, in page-table trace PGD/P4D/PUD/PMD/PT. |
| `src/mm-vm.c` | Tăng VMA bằng `inc_vma_limit()`, map thêm RAM frame, quản lý vùng cấp phát theo `sbrk`. |
| `src/libmem.c` | Hiện thực `alloc/free/read/write`, `kmalloc`, `copy_from_user`, `copy_to_user`; I/O RAM đi qua syscall `memmap`. |
| `src/cpu.c` | `READ` trong paging mode lưu giá trị đọc được về thanh ghi đích. |

## 3. Thiết kế Memory Management

### 3.1. User space

Mỗi process có một `struct mm_struct *mm` riêng. Trong `mm` có:

- `pgd/p4d/pud/pmd/pt`: bảng trang mô phỏng cho chế độ địa chỉ 64-bit.
- `mmap`: danh sách vùng nhớ ảo, hiện dùng VMA 0 cho user data segment.
- `symrgtbl[]`: bảng vùng nhớ theo region ID.
- `fifo_pgn`: danh sách page đã map, phục vụ thay thế trang nếu cần.

Khi chạy lệnh:

```text
alloc 100 1
```

luồng xử lý là:

```text
CPU -> liballoc -> __alloc -> syscall 17 / SYSMEM_INC_OP
    -> sys_memmap -> inc_vma_limit
    -> vm_map_ram -> alloc_pages_range -> vmap_page_range
    -> pte_set_fpn
```

Sau đó `region 1` được ghi vào `symrgtbl[1]`, còn page table chứa mapping `PGN -> FPN`.

### 3.2. Read/Write user memory

Lệnh:

```text
write 65 1 0
read 1 0 2
```

được xử lý như sau:

```text
WRITE -> __write -> pg_setval -> syscall 17 / SYSMEM_IO_WRITE -> MEMPHY_write
READ  -> __read  -> pg_getval -> syscall 17 / SYSMEM_IO_READ  -> MEMPHY_read
```

Như vậy, user code không ghi trực tiếp vào RAM. Việc đọc/ghi vật lý được chuyển qua syscall `memmap`.

### 3.3. Kernel space

Kernel memory dùng page table riêng nằm trong `struct krnl_t`:

```c
addr_t *krnl_pgd;
addr_t *krnl_p4d;
addr_t *krnl_pud;
addr_t *krnl_pmd;
addr_t *krnl_pt;
```

Lệnh:

```text
kmalloc 4 2
```

sẽ cấp phát vùng kernel-space, đánh dấu region đó bằng:

```c
symrgtbl[rgid].vmaid = -1;
```

Do đó, các hàm user read/write không thể truy cập nhầm kernel region. Việc truyền dữ liệu qua biên user/kernel dùng:

```text
copy_from_user [source] [destination] [offset] [size]
copy_to_user   [source] [destination] [offset] [size]
```

## 4. Chứng minh System Call dùng PID, không truyền PCB trực tiếp

Trong `src/libstd.c`, user-side wrapper chỉ gọi:

```c
_syscall(caller->krnl, caller->pid, syscall_idx, &regs);
```

Trong `src/sys_mem.c`, kernel nhận `pid`, rồi tìm process thật bằng:

```c
find_proc_by_pid(krnl, pid)
```

Hàm này duyệt:

1. `krnl->running_list`
2. `krnl->mlq_ready_queue[prio]`
3. `krnl->ready_queue`

Như vậy, user không truyền trực tiếp PCB sang kernel; kernel tự lấy PCB từ cấu trúc quản lý nội bộ bằng PID.

## 5. Test cases

### Test 1 — listsyscall

Config:

```text
input/os_syscall_list
```

Program:

```text
input/proc/sc1
```

Expected key output:

```text
0-sys_listsyscall
17-sys_memmap
CPU 0 stopped
```

### Test 2 — Base user memory alloc/write/read/free

Config:

```text
input/member2_mem
```

Program:

```text
input/proc/member2_mem
```

Expected key output:

```text
[libwrite] pid=1 rg=1 offset=0 <- value=65
[libwrite] pid=1 rg=1 offset=1 <- value=66
[libread] pid=1 rg=1 offset=0 -> value=65
[libread] pid=1 rg=1 offset=1 -> value=66
[libfree] pid=1 rg=1 released
CPU 0 stopped
```

### Test 3 — User/kernel copy

Config:

```text
input/member2_kcopy
```

Program:

```text
input/proc/member2_kcopy
```

Expected key output:

```text
[kmalloc] pid=1 rg=2 kernel_addr=32768 size=4
[copy_from_user] pid=1 user_rg=1 -> kernel_rg=2 offset=0 size=2
[copy_to_user] pid=1 kernel_rg=2 -> user_rg=3 offset=0 size=2
[libread] pid=1 rg=3 offset=0 -> value=65
[libread] pid=1 rg=3 offset=1 -> value=66
CPU 0 stopped
```

### Test 4 — memmap / vmap_pgd_memset

Config:

```text
input/member2_sysmap
```

Program:

```text
input/proc/member2_sysmap
```

Expected key output:

```text
[sys_memmap] vmap_pgd_memset pid=1 addr=0 pages=2
CPU 0 stopped
```

## 6. Lệnh chạy

```bash
make clean
make all
./os os_syscall_list
./os member2_mem
./os member2_kcopy
./os member2_sysmap
```

Hoặc chạy nhanh:

```bash
bash run_member2_tests.sh
```

## 7. Kết luận
- Có paging user memory cơ bản.
- Có kernel memory riêng.
- Có system call `listsyscall` và `memmap`.
- Memory I/O đi qua syscall.
- Giao tiếp user/kernel dùng PID và `sc_regs`, không truyền trực tiếp PCB từ chương trình user.
- Có input, expected output và output đã chạy để đưa vào báo cáo/demo.
