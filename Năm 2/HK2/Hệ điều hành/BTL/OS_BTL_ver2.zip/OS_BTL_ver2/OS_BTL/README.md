# TASK BTL - Simple OS Assignment Summary


## Phần Scheduler hiện thực `queue.c` and `shed.c`

### Chú ý 2 CPU có thể khác nhau nhưng 1 CPU thì sẽ gần như giống nhau
```sh

# mở MM_FIXED_MEMSZ trong file os-cfg.h để tránh lỗi 
#define MM_FIXED_MEMSZ

## BUILD
make

## RUN
./os votien_sched_1 >  result_sched/votien_sched_1.text  
python3 gantt.py input/votien_sched_1 result_sched/votien_sched_1.text result_sched/votien_sched_1.png

./os votien_sched_2 >  result_sched/votien_sched_2.text  
python3 gantt.py input/votien_sched_2 result_sched/votien_sched_2.text result_sched/votien_sched_2.png

./os votien_sched_3 >  result_sched/votien_sched_3.text  
python3 gantt.py input/votien_sched_3 result_sched/votien_sched_3.text result_sched/votien_sched_3.png

./os votien_sched_4 >  result_sched/votien_sched_4.text  
python3 gantt.py input/votien_sched_4 result_sched/votien_sched_4.text result_sched/votien_sched_4.png

./os votien_sched_5 >  result_sched/votien_sched_5.text  
python3 gantt.py input/votien_sched_5 result_sched/votien_sched_5.text result_sched/votien_sched_5.png

./os sched >  result_sched/sched.text  
python3 gantt.py input/sched result_sched/sched.text result_sched/sched.png

./os sched_0 >  result_sched/sched_0.text  
python3 gantt.py input/sched_0 result_sched/sched_0.text result_sched/sched_0.png

./os sched_1 >  result_sched/sched_1.text  
python3 gantt.py input/sched_1 result_sched/sched_1.text result_sched/sched_1.png

```
