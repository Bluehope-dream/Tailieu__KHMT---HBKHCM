# Member 2 - Base Memory & Syscall fixed package

## Main responsibility covered
- Basic paging-based memory allocation/read/write/free.
- User-space and kernel-space separation by `vmaid`: user `0`, kernel `-1`.
- System call `listsyscall` and `memmap`.
- `memmap` finds the real process by PID from kernel process lists instead of creating/passing a fake PCB pointer.
- Added member-2 test inputs and expected outputs.

## Important changed files
- `include/common.h`: added per-process `struct mm_struct *mm`.
- `include/mm.h`: fixed `INCLUDE` and `OVERLAP`; added `vm_map_ram` prototype.
- `include/os-cfg.h`: disabled `MM_FIXED_MEMSZ` so the provided paging input files read RAM/SWAP sizes correctly.
- `src/os.c`: initializes per-process memory map.
- `src/sys_mem.c`: corrected PID-based lookup and syscall dispatch.
- `src/mm-vm.c`: implemented VMA lookup, overlap check, VMA growth, and page mapping trigger.
- `src/mm64.c`: implemented base 64-bit index extraction, PTE get/set, page range mapping, page allocation, and page table printing.
- `src/libmem.c`: implemented user read/write through `SYSMEM_IO_READ/WRITE`; basic `kmalloc`; copy_from_user/copy_to_user.
- `src/loader.c`: enlarged opcode buffer so long opcodes such as `kmem_cache_create` do not overflow.

## How to run
```bash
make clean
make all
./os os_syscall_list
./os member2_mem
./os member2_sysmap
./os member2_kcopy
```

## Expected files
Expected outputs are stored in:
- `expected/os_syscall_list.output`
- `expected/member2_mem.output`
- `expected/member2_sysmap.output`
- `expected/member2_kcopy.output`
