#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

#define NUM_RESOURCES 10
#define MAX_REQUESTS 5

// Shared data 
typedef struct {
    int id; // Process ID
    int requested_resources;     // Resources the process requests
    void (*callback)(int); // Callback function for resource allocation.
} process_request_t;


int available_resources = NUM_RESOURCES;
pthread_mutex_t resource_lock = PTHREAD_MUTEX_INITIALIZER;
pthread_cond_t resource_cond = PTHREAD_COND_INITIALIZER;

void resource_callback(int process_id){
    // To do: perform action when resource available 
    printf(">>> [CALLBACK] Process %d : đã nhận được tài nguyên và xử lý ... \n", process_id);

}


void* resource_man(void * arg){
    process_request_t* request = (process_request_t*) arg;

    pthread_mutex_lock(&resource_lock);

    // Non-blocking allocation
    while (request -> requested_resources > available_resources){
        printf("Process %d waiting for resources\n",request->id);
        pthread_cond_wait(&resource_cond,&resource_lock);
    }

    // Alocate resources 
    printf("[System] Allocating %d resources to Process %d\n",request-> requested_resources,request->id);

    available_resources -= request -> requested_resources;
    request -> callback(request -> id);
    // TO DO : PERFORM PROCESSES 

    pthread_mutex_unlock(&resource_lock);
    sleep (2);                                   // Giả lập làm việc trong 2 giây. 
    pthread_mutex_lock(&resource_lock);

    // Release resource 
    available_resources += request -> requested_resources;
    printf (" Process %d released resources\n", request -> id);
    pthread_cond_broadcast(&resource_cond);

    pthread_mutex_unlock(&resource_lock);
    return NULL;
}

int main() {
    pthread_t thread1, thread2;

    // Khởi tạo dữ liệu cho 2 test case
    process_request_t req1 = { .id = 1, .requested_resources = 4, .callback = resource_callback };
    process_request_t req2 = { .id = 2, .requested_resources = 8, .callback = resource_callback };

    printf("=== BẮT ĐẦU KIỂM THỬ ===\n");
    printf("Tài nguyên ban đầu: %d\n\n", available_resources);

    // Chạy Test Case 1
    printf("--- Chạy Test Case 1: Tiến trình 1 yêu cầu 4 đơn vị ---\n");
    pthread_create(&thread1, NULL, resource_man, &req1);
    
    sleep(1); // Để Thread 1 chiếm tài nguyên trước

    // Chạy Test Case 2
    printf("\n--- Chạy Test Case 2: Tiến trình 2 yêu cầu 8 đơn vị ---\n");
    pthread_create(&thread2, NULL, resource_man, &req2);

    // Đợi các thread hoàn thành
    pthread_join(thread1, NULL);
    pthread_join(thread2, NULL);

    printf("\n=== KIỂM THỬ KẾT THÚC ===\n");
    return 0;
}