#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
// #include <unistd.h>

// Test 01
#define BUFFER_SIZE 5
#define NUM_ITEMS 10

// // Test 02
// #define BUFFER_SIZE 5
// #define NUM_ITEMS 6

int buffer[BUFFER_SIZE];
int count = 0;

pthread_mutex_t mutex;
pthread_cond_t cond_var;

/*---------------- WRITE ----------------*/
int write(int value) {
    pthread_mutex_lock(&mutex);

    while (count == BUFFER_SIZE) {
        // BUFFER IS FULL
        pthread_cond_wait(&cond_var, &mutex);
    }

    buffer[count++] = value;

    printf("[writer] wrote %d (count = %d)\n", value, count);


    if (count == 1) {
        pthread_cond_signal(&cond_var);
    }

    pthread_mutex_unlock(&mutex);
    return 0;
}

/*---------------- READ ----------------*/
int read(int *out) {
    pthread_mutex_lock(&mutex);

    while (count == 0) {

        pthread_cond_wait(&cond_var, &mutex);
    }


    *out = buffer[--count];

    printf("[reader] read %d (count = %d)\n", *out, count);


    if (count == BUFFER_SIZE - 1) {
        pthread_cond_signal(&cond_var);
    }

    pthread_mutex_unlock(&mutex);
    return 0;
}

/*---------------- THREAD FUNCTIONS ----------------*/
void *writer_thread(void *args) {
    for (int i = 0; i < NUM_ITEMS; i++) {
        write(i);
        // Test 01
        usleep(100000);
        // test 02
        // usleep(400000);
    }
    return NULL;
}

void *reader_thread(void *args) {
    int val;
    for (int i = 0; i < NUM_ITEMS; i++) {
        read(&val);
        // test 01
        usleep(300000);
        // test 02
        // usleep(50000);
    }
    return NULL;
}

/*---------------- MAIN ----------------*/
int main() {
    pthread_t writeItem, readItem;

    pthread_mutex_init(&mutex, NULL);
    pthread_cond_init(&cond_var, NULL);

    pthread_create(&writeItem, NULL, writer_thread, NULL);
    pthread_create(&readItem, NULL, reader_thread, NULL);

    pthread_join(writeItem, NULL);
    pthread_join(readItem, NULL);

    pthread_cond_destroy(&cond_var);
    pthread_mutex_destroy(&mutex);

    return 0;
}