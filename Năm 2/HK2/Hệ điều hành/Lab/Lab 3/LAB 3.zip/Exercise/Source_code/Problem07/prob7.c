#include<unistd.h>
#include<stdlib.h>
#include<stdio.h>
#include<pthread.h>
#include<stdatomic.h>
#include <assert.h>
#include<stdbool.h>

// Shared data 

typedef struct node {
    int data;
    struct node * next;
} node;

// TODO : implementaion of a lock - free stack
typedef struct  LockFreeStack{

    _Atomic(node*) head ; // Pointer to the top node

} LockFreeStack;

// Push an item onto the stack 

bool push(LockFreeStack*stack, int value){
    // TODO : set new node's next to the current head. 
    node *new_node = malloc(sizeof(node));
    if (!new_node) return false;

    new_node -> data = value;
    node *old_head = atomic_load(&stack->head);

    do {
        new_node->next = old_head;
    } while (!atomic_compare_exchange_weak(&stack-> head,&old_head,new_node));
    
    return true;

}

// Pop an item from the stack  
bool pop (LockFreeStack *stack, int *value){
    // Todo : Get the value to return and free the popped node. 

    node *old_head = atomic_load(&stack->head);
    while (old_head != NULL){
        if(atomic_compare_exchange_weak(&stack->head,&old_head,old_head->next)){
            *value = old_head -> data;
            // free(old_head);
            return true;

        }
    }
    return false;
}



// Testcase 01 : đơn luồng (sequential test)
void test_sequential (){
    printf("Running Test case 1: Sequential Logic .. \n");
    LockFreeStack s;
    atomic_init(&s.head, NULL);
    int val;

    push(&s, 10);
    push(&s, 20);
    push(&s, 30);

    pop(&s, &val); 
    assert(val == 30);
    pop(&s, &val); 
    assert(val == 20);
    pop(&s, &val); 
    assert(val == 10);
    
    bool empty = pop(&s, &val);
    assert(empty == false); // Stack phải rỗng

    printf(">>> Test Case 1 PASSED!\n\n");
}
// Testcase 02 : Đa luồng (CONCURRENCY)---
#define NUM_THREADS 8
#define OPS_PER_THREAD 10000

LockFreeStack global_stack;

void *thread_work (void* arg){
    int val;
    for (int i=0;i<OPS_PER_THREAD;i++){
        push(&global_stack,i);
        pop(&global_stack,&val);
    }
    return NULL;
}

void test_concurrency(){

    printf("Running Test Case 2: Concurrent Stress (%d threads)...\n", NUM_THREADS);
    atomic_init(&global_stack.head, NULL);
    pthread_t threads[NUM_THREADS];

    for (int i = 0; i < NUM_THREADS; i++) 
        pthread_create(&threads[i], NULL, thread_work, NULL);

    for (int i = 0; i < NUM_THREADS; i++) 
        pthread_join(threads[i], NULL);

    // Kiểm tra cuối cùng stack phải rỗng nếu mọi thao tác push/pop khớp nhau
    int final_val;
    if (pop(&global_stack, &final_val)) {
        printf(">>>> Test Case 2 FAILED: Stack not empty!\n");
    } else {
        printf(">>> Test Case 2 PASSED: No data loss or race conditions!\n");
    }

}
int main(){

    test_sequential();
    test_concurrency();

    return 0;
}