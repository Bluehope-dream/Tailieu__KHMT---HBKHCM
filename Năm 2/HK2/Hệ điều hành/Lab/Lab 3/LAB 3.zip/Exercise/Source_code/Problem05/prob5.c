#include<stdlib.h>
#include<stdio.h>
#include<unistd.h>
#include<pthread.h>

pthread_mutex_t lock;
 
// Shared data 
static int found = 1;
static int finished =0;

int is_safe(){
    // To do: perform polling checks 
    if(!found){
        return -1;     // Unsafety dectected
    }
    return 0;
}


void * periodical_detector(void *arg){
    printf(">>> Detector thread started\n");
    
    while (1){
        sleep(1); 

        pthread_mutex_lock(&lock);

        // Sửa ở đây: Nếu is_safe trả về -1 (Unsafe)
        if (is_safe() == -1){ 
            printf("[Detector] Unsafe detected! Taking action ...\n");
            fflush(stdout);

            finished = 1;
            pthread_mutex_unlock(&lock);
            break;
        }

        // Nếu is_safe trả về 0 (Safe)
        printf("[Detector] System is safe\n");
        fflush(stdout);

        pthread_mutex_unlock(&lock);
    }
    return NULL;
}


// Thực hiện quản lý kế hoạch của một run test
void run_test(void(*test_scenario)()){
    pthread_t detector ;

    // Reset lại biến dùng chung trước mỗi lần test
    pthread_mutex_lock(&lock);
    found =1;
    pthread_mutex_unlock(&lock);

    pthread_create(&detector,NULL,periodical_detector,NULL);

    test_scenario();
    pthread_join(detector,NULL);

}
void testcase_01(){
    printf("[Test01]\n");
    sleep (10);
    pthread_mutex_lock(&lock);
    found = 0;
    pthread_mutex_unlock(&lock);
}
void testcase_02(){
    printf("[Test02]\n");
    sleep(1);
    pthread_mutex_lock(&lock);
    found = 0; 
    pthread_mutex_unlock(&lock);
}
int main() {
   
    pthread_mutex_init(&lock, NULL);

    // Chạy test case 1

    printf("\n>>> CHẠY TEST CASE 1 <<<");
    run_test(testcase_01);

    // Chạy test case 2
    printf("\n>>> CHẠY TEST CASE 2 <<<");
    run_test(testcase_02);

    pthread_mutex_destroy(&lock);

    printf("=== TEST END ===\n");
    fflush(stdout);

    return 0;
}