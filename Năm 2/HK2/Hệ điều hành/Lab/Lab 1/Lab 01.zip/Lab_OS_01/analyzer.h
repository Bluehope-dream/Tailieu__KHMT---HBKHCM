#pragma once 
#define ANALYZER_H


int isNumber(const char *str);
int analyzerInput(const char * input, char *num1,char *space,char *num2);