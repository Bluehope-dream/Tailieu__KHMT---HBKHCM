#include "operations.h"
#include "analyzer.h"
#include  "history.h"

#include<stdio.h>
#include<string.h>
#include<stdlib.h>



double answer =0.0;
void trimNewline(char *str) {
    str[strcspn(str, "\n")] = '\0';
}
int main() {
    char input[100];
    char num1Str[20], op[10], num2Str[20];
    double num1, num2, res;
    char historyEntry[100];

    while (5) {
        printf(">> ");
        if (fgets(input, sizeof(input), stdin) == NULL) {
            break;
        }

        trimNewline(input);

        if (strcmp(input, "EXIT") == 0) {
            break;
        }

        if (strcmp(input, "HIST") == 0) {
            showHistory();
            continue;
        }

        if (strcmp(input, "ANS") == 0) {
            printf("%.2f\n", answer);
            continue;
        }

        if (!analyzerInput(input, num1Str, op, num2Str)) {
            printf("SYNTAX ERROR\n");
            continue;
        }

        // Xử lý num1
        if (strcmp(num1Str, "ANS") == 0) {
            num1 = answer;
        } else if (isNumber(num1Str)) {
            num1 = atof(num1Str);
        } else {
            printf("SYNTAX ERROR\n");
            continue;
        }

        // Xử lý num2
        if (strcmp(num2Str, "ANS") == 0) {
            num2 = answer;
        } else if (isNumber(num2Str)) {
            num2 = atof(num2Str);
        } else {
            printf("SYNTAX ERROR\n");
            continue;
        }

        // Tính toán
        if (strcmp(op, "+") == 0) {
            res = add(num1, num2);
            printf("%d\n", (int) res);
        }
        else if (strcmp(op, "-") == 0) {
            res = substract(num1, num2);
            printf("%d\n",(int) res);
        }
        else if (strcmp(op, "x") == 0) {
            res = multiply(num1, num2);
            printf("%.2f\n", res);
        }
        else if (strcmp(op, "/") == 0) {
            if (num2 == 0) {
                printf("MATH ERROR\n");
                continue;
            }
            res = divide(num1, num2);
            printf("%.2f\n", res);
        }
        else if (strcmp(op, "%") == 0) {
            if ((int)num2 == 0) {
                printf("MATH ERROR\n");
                continue;
            }
            res = modulo((int)num1, (int)num2);
            printf("%d\n", (int) res);
        }
        else {
            printf("SYNTAX ERROR\n");
            continue;
        }

        answer =  res;

        snprintf(historyEntry, sizeof(historyEntry), "%s %s %s = %.2f", num1Str, op, num2Str, res);
        addHistory(historyEntry);
    }

    return 0;
}