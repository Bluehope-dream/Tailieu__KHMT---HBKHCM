#pragma once

#define HISTORY_H

#define MAX_HISTORY 5
#define MAX_ENTRY 100



void addHistory(const char entry[]);

void showHistory();