#include  "analyzer.h"
#include<stdio.h>
#include<Stdlib.h>
#include<string.h>

int isNumber(const char *str){
    char *endptr;
    strtod(str,&endptr);
    return (*str != '\0' && *endptr == '\0');

}
int analyzerInput(const char * input, char *num1,char *space,char *num2){
    return sscanf(input,"%s %s %s",num1,space,num2)==3;

}