#pragma once 
#define OPERATIONS_H

int add (int,int);
int substract(int,int);
int multiply(int,int);
double divide(double,double);
int  modulo(int,int);








