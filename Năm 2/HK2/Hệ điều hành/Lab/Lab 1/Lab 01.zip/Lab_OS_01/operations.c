#include "operations.h"


int  add (int a, int b){
    return a+b;
}

int  substract(int a,int b){
    return a-b;
}
int  multiply(int a,int b){
    return a*b;
}
double divide(double a,double b){
    return a/b;
}
int  modulo(int a,int b){
    return a%b;
}