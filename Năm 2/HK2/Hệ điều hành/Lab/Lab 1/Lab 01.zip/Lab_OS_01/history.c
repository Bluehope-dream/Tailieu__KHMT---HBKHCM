#include "history.h"
#include<string.h>
#include<stdio.h>


static char history [MAX_HISTORY][MAX_ENTRY];
static int historyCount = 0;
void addHistory(const char entry[]){
    if(historyCount>= MAX_HISTORY){
        // Thực hiện cắt chuỗi gần nhất vào chuỗi trước đó xóa đoạn cách xa ko cần truy xuất 
        for (int i =1;i<MAX_HISTORY;i++){
            strcpy(history[i-1],history[i]);        // Syntax: copy char from source to des
        }
        strcpy(history[MAX_HISTORY - 1],entry);

    } else {
        strcpy(history[historyCount++],entry);
        // Entry là chuỗi đưa vào 
    }
}

void showHistory(){
    for (int i=0;i<historyCount;i++){
        printf("%s\n",history[i]);
    }
}