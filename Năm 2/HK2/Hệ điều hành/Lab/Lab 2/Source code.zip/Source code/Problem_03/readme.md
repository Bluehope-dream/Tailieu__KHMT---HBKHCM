# Problem 03. Two-way Coummunication using message queue & Multithreading 
## 1. Mục tiêu bài

- Implement two communication method in message queue by multithread background.
 - Cho phép chương trình giao tiếp đồng thời hai chiều 

 ---
## 2. Danh sách file

        Problem_03
        |
        |--------Task_3.c
        |--------Task3.c
        |--------readme.md

---

## 3. Cách build
Sử dụng `gcc` với thư viện `pthread`.

### Biên dịch chương trình :
    Để biên dịch chương trình Task3:
        '''bash
              gcc -pthread  -o Task3 Task3.c
         
    Mở 1 terminal khác, để biên dịch chương trình Task_3:
        '''' bash      
                gcc -pthread -o Task_3 Task_3.c

---
## 4. Cách chạy

    Để chạy chương trình :
        ''''                ./Task3
      
    Để chạy chương trình :
        ''''                ./Task_3
        
---
## 5. Input / Output
- Chương trình nhận input là message from any side.
- Kết quả đầu ra mong đợi là message sent from one will be received to another
Ví dụ : 
            Client nhập: Hello
            Server hiển thị: Client: Hello

            Server nhập: Hi
            Client hiển thị: Server: Hi

---

## 6. Ý tưởng hiện thực
- Mô tả ngắn cách giải.

            Dùng System V Message Queue(IPC) để truyền dữ liệu giữa 2 process
            Sử dụng 2 mesage queue riêng biệt


- Nêu rõ dùng process/thread/IPC/mmap như thế nào.
        ''' Sử dụng Thread

            Chương trình tạo 2 thread:

                    pthread_create(&t1, NULL, sender, NULL);
                    pthread_create(&t2, NULL, receiver, NULL);



        ''' Sử dụng IPC (Message Queue)

            Chương trình dùng System V Message Queue:

                q_send = msgget(Q1_KEY, PERMS | IPC_CREAT);
                q_recv = msgget(Q2_KEY, PERMS | IPC_CREAT);
        ''' Mỗi chương trình (client/server) tạo 2 thread:
                sender thread: đọc input từ bàn phím và gửi message.
                receiver thread: nhận message từ queue và in ra màn hình .

- Thiết kế : 
    ''' Task3.c (Server):  
            Gửi message qua Q2.
            Nhận message từ Q1.
    ''' Task_3.c (Client):
            Gửi message qua Q1.
            Nhận message từ Q2.

---

## 7. Ghi chú thêm 

- Cần phải chạy song song đồng thời 2 file trong thư mục trên 2 cửa sổ terminal khác nhau.


---