#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>
#include <sys/msg.h>

#define PERMS 0644
#define Q1_KEY 0x123
#define Q2_KEY 0x124

struct msgbuf {
    long mtype;
    char mtext[200];
};

int q_send, q_recv;

void* sender(void* arg) {
    struct msgbuf buf;
    buf.mtype = 1;

    while (fgets(buf.mtext, sizeof(buf.mtext), stdin)) {
        buf.mtext[strcspn(buf.mtext, "\n")] = 0;
        msgsnd(q_send, &buf, strlen(buf.mtext) + 1, 0);

        if (strcmp(buf.mtext, "end") == 0) break;
    }
    return NULL;
}

void* receiver(void* arg) {
    struct msgbuf buf;

    while (1) {
        msgrcv(q_recv, &buf, sizeof(buf.mtext), 0, 0);
        printf("Server: %s\n", buf.mtext);

        if (strcmp(buf.mtext, "end") == 0) break;
    }
    return NULL;
}

int main() {
    pthread_t t1, t2;

    q_send = msgget(Q1_KEY, PERMS | IPC_CREAT);
    q_recv = msgget(Q2_KEY, PERMS | IPC_CREAT);

    pthread_create(&t1, NULL, sender, NULL);
    pthread_create(&t2, NULL, receiver, NULL);

    pthread_join(t1, NULL);
    pthread_join(t2, NULL);

    return 0;
}