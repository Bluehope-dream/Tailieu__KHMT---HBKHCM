#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define PERMS 0644
#define MSG_KEY 0x123

struct my_msgbuf {
    long mtype;
    char mtext[200];
};

int main(void) {
    struct my_msgbuf buf;
    int msqid;
    int len;
    key_t key;

    system("touch msgq.txt");

    msqid = msgget(MSG_KEY, PERMS | IPC_CREAT);
    if (msqid == -1) {
        perror("msgget");
        exit(1);
    }

    printf("Message queue: ready to send messages.\n");
    printf("Enter lines of text, Ctrl+D to quit:\n");

    buf.mtype = 1;

    while (fgets(buf.mtext, sizeof(buf.mtext), stdin) != NULL) {
        len = strlen(buf.mtext);

        if (buf.mtext[len - 1] == '\n') {
            buf.mtext[len - 1] = '\0';
        }

        if (msgsnd(msqid, &buf, len + 1, 0) == -1) {
            perror("msgsnd");
            exit(1);
        }
    }

    strcpy(buf.mtext, "end");
    len = strlen(buf.mtext);

    if (msgsnd(msqid, &buf, len + 1, 0) == -1) {
        perror("msgsnd");
        exit(1);
    }

    if (msgctl(msqid, IPC_RMID, NULL) == -1) {
        perror("msgctl");
        exit(1);
    }

    printf("Message queue: done sending messages.\n");

    return 0;
}