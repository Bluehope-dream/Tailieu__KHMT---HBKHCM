#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <errno.h>

#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>

#define PERMS 0644
#define MSG_KEY 0x123

struct my_msgbuf {
    long mtype;
    char mtext[200];
};

int main(void) {
    struct my_msgbuf buf;
    int msqid;
    int to_end;

    msqid = msgget(MSG_KEY, PERMS | IPC_CREAT);
    if (msqid == -1) {
        perror("msgget");
        exit(1);
    }

    printf("Message queue: ready to receive messages.\n");

    for (;;) {

        if (msgrcv(msqid, &buf, sizeof(buf.mtext), 0, 0) == -1) {
            perror("msgrcv");
            exit(1);
        }

        printf("Received: \"%s\"\n", buf.mtext);

        to_end = strcmp(buf.mtext, "end");

        if (to_end == 0) {
            break;
        }
    }

    printf("Message queue: done receiving messages.\n");

    system("rm msgq.txt");

    return 0;
}