
## 1. Mục tiêu bài


- Calculate the sum of S(N) = 1+ 2 + 3+ ...+N  in two ways.


---

## 2. Danh sách file

        Problem_02
        |
        |--------sum_serial.c
        |--------sum_multi-thread.c
        |--------readme.md
        |--------Makefile

---

## 3. Cách build
    Biên dịch chương trình, gõ lệnh:

                '''                 make 
      
                

---


## 4. Cách chạy

    Để chạy chương trình sum_serial:
        ''''                ./sum_serial <N>
        VD:         ./sum_serial 1000000

    Để chạy chương trình sum_multi-thread:
        ''''                ./sum_multi-thread <numthreads> <N>
        
        VD:         ./sum_multi-thread 10 1000000

---


## 5. Input / Output
- Input:
    Chương trình sum_serial:  N là số tự nhiên bất kỳ  

    Chương trình sum_multi-thread: 
        numThread số lượng luồng thread tính toán được chỉ định 
        N là số tự nhiên bất kỳ

- Expected Output: 
        ''' Tổng các số tự nhiên từ 1 đến N.
        ''' So sánh thời gian tính toán của hai giải pháp hiện thực 

---

## 6. Ý tưởng hiện thực

    - Phương pháp giải quyết thứ nhất : Dùng vòng lặp tính tổng các số từ 1 cho đến N.

    - Phương pháp giải quyết thứ hai: 
        ''' Tận dùng phương pháp multi-thread để tạo cách xử lý đa luồng. 
        ''' Tạo các luồng thread phân đoạn tính tổng trên các numThreads 
        một cách đồng thời 1st thread calcuates the sum of {1,n/numThreads}, the 2nd thread tính {n/ numThreads +1, 2n/numThreads},...

---
