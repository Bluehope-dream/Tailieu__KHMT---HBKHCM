#include<stdio.h>
#include<stdlib.h>
#include<pthread.h>
#include<time.h>
#define MAX_COUNT 100
static long long N, numThread;
long long parseSum [MAX_COUNT];
void *calculate(void * sid){  // sid lấy tên số id của thread 
    long long i = (long long ) sid;
    long long start = (i * N) / numThread + 1;
    long long end =  (i+1)*N / numThread;
    parseSum[i]=0;
    for (long long m = start;m<=end;m++){
        parseSum[i] +=m;            // Tính parse sum ứng với mỗi pid khác 
    }
    return NULL;
}
int main(int argc, char* argv[]){

    if(argc <=2 ){
        printf("Please follow the rule of syntax to run %s <numThread> <N>", argv[0]);
        return 0;
    }
    N = atoll (argv[2]);
    numThread = atoll(argv[1]);
    long long sum =0;

    pthread_t threads[MAX_COUNT];
    clock_t start = clock();

    //Create threads 
    for (long long i=0;i<numThread;i++){
        pthread_create(&threads[i],NULL,calculate,(void*)i);
    }
    //Join threads
    for (long long i=0;i<numThread;i++){
        pthread_join(threads[i],NULL);
    }
    
    for (long long i=0;i<numThread;i++){
        sum += parseSum[i];
    }
    
    clock_t end = clock();
    double time_Cost = (double) (end-start)/CLOCKS_PER_SEC;
    printf("Sum of numbers from 1 to %lld using multithread is %lld\n",N,sum);
    printf("The multi-thread sum of %lld program spends %.8fs\n",N,time_Cost);
    return 0;
}
