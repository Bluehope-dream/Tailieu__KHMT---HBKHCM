// Problem: sum_serial 
#include<stdio.h>
#include<stdlib.h>
#include<time.h>
long long sum (long long N){
  
    long long  count=0;
    for (long long i=1;i<=N;i++){
        count +=i;
    }
    return count;
}
int main(int argc, char *argv[]){
    if (argc <=1) {
        printf("Please check your syntax command to run.");
        return 0;
    }
    long long N = atoll (argv[1]) ;
    // atoi(argv[1]);
    
    clock_t start = clock();

    long long res = sum(N);

    clock_t end = clock();

    printf("Sum from 1 to %lld is %lld\n",N,res);
    printf ("The time of sum_serial is %lfs\n",(double)(end - start) / CLOCKS_PER_SEC);
    return 0;
}