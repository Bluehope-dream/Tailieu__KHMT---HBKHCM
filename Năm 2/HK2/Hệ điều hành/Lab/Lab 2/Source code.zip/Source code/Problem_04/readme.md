

## 1. Mục tiêu bài

-    Hiện thực mapping created file vào trong local address space bằng cách sử dụng mmap.


---

## 2. Danh sách file

        Problem_04
        |
        |
        |--------------mmap.h
        |
        |--------------mmap.c       (source code chính)
        |
        |--------------run.sh         (file bash script)
        |
        |--------------readme.md


---

## 3. Cách build
- Để build chương trình, mở terminal, gõ lệnh : 
                        '''     chmod +x run.sh


---
## 4. Cách chạy
- Để chạy chương trình, gõ lệnh:
                        '''     ./run.sh

---
## 5. Input / Output

- Input của chương trình: 1 file Data.dat được ánh xạ vào mmap 

- Kết quả đầu ra mong đợi là :

        ''' Cả hai tiến trình Parent Process và Child Process cùng truy cập được vùng dữ liệu dùng chung
        ''' Tiến trình Child Process đọc được nội dung giá trị từ Parent Process.

---
## 6. Ý tưởng hiện thực


- Bước 1: Tạo file data.dat.

- Bước 2: Ánh xạ file data.dat vào trong trong RAM, file này được xem là vùng nhớ dùng chung của 2 process.

                ''' data = mmap(NULL, sizeof(SharedData), PROT_READ | PROT_WRITE,  MAP_SHARED, fd, 0);
                                                                                                                                      
- Bước 3: Tạo tiến trình con Child Process.

- Bước 4: Đồng bộ . Cho tiến trình con chờ tiến trình cha đến khi parent process đọc được dữ liệu.

- Bước 5: Unmmap region và close file.




---
