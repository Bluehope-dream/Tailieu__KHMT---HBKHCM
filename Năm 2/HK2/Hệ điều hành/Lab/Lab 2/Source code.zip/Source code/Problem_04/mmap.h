#ifndef MMAP_H
#define MMAP_H

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <fcntl.h>
#include <sys/wait.h>


typedef struct {
    int ready;
    int value;
} SharedData;



#endif