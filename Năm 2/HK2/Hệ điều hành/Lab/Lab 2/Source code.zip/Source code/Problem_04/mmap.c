#include "mmap.h"


int main() {
    int fd;
    SharedData *data;

    // 1. Tạo file
    fd = open("data.dat", O_CREAT | O_RDWR, 0666);
    if (fd < 0) {
        perror("open");
        exit(1);
    }

    // 2. Set kích thước file
    if (ftruncate(fd, sizeof(SharedData)) == -1) {
        perror("ftruncate");
        exit(1);
    }

    // 3. mmap file vào RAM
    data = mmap(NULL, sizeof(SharedData),
                PROT_READ | PROT_WRITE,
                MAP_SHARED, fd, 0);

    if (data == MAP_FAILED) {
        perror("mmap");
        exit(1);
    }

    // init
    data->ready = 0;

    pid_t pid = fork();

    if (pid == 0) {
        // ===== CHILD (Reader) =====
        while (data->ready == 0); // busy wait

        printf("Child read value: %d\n", data->value);
    } else {
        // ===== PARENT (Writer) =====
        sleep(1); 

        data->value = 999;
        data->ready = 1;

        printf("Parent wrote value: %d\n", data->value);

        wait(NULL);
    }

    // 4. cleanup
    munmap(data, sizeof(SharedData));
    close(fd);

    return 0;
}