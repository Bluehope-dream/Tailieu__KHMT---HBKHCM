
## 1. Mục tiêu bài

- Đọc dữ liệu từ hai file:
  - `movie-100k_1.txt`
  - `movie-100k_2.txt`
- Tính **average rating (điểm trung bình)** cho từng `MovieID`.
- Áp dụng **multiprocessing (fork)** để xử lý song song hai file nhằm cải thiện hiệu năng.

---

## 2. Danh sách file

        Problem_01
        |
        |--------movie-100k_1.txt   (Input data)
        |--------movie-100k-2.txt    (Input data)
        |--------Task1.h
        |--------Task1.c
        |--------main.c  (source code chính)
        |--------run.sh
        |--------readme.md


---

## 3. Cách build
    - Để build chương trình, ta cần  cấp quyền cho file bash cript: 
             ''''       chmod +x run.sh
---

## 4. Cách chạy
    - Để chạy chương trình : 
            ''''        ./run.sh

---

## 5. Input / Output
- Input của file: UserID,MovieID, rating được đọc từ hai file movie-100k_1.txt và movie-100k_2.txt
        
- Expected output:  Average rating of movieIds.


---

## 6. Ý tưởng hiện thực

- Tạo 2 childProcess đọc và xử lý từng file.    

        ''' Tạo tiến trình mới bằng lệnh fork():
                pid_t pid = fork();

- In ra kết quả mong đợi theo định dạng

---
