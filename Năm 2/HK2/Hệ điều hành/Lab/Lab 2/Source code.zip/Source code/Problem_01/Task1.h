#ifndef TASK1_H
#define TASK1_H

#define numMovies 1682
#define numUsers 943

extern int shmid;
double (*attachSharedMemory())[numUsers];
void detachSharedMemory(double (*matrix)[numUsers]);
void releaseSharedMemory();


void readFile(const char* fileName);

void computeAverage(double (*matrix)[numUsers]);

/*Create Process Child*/
void createChildProcess(const char *fileName);

#endif