
#include "Task1.h"
#include<sys/ipc.h>
#include <sys/shm.h>
#include<stdio.h>
#include <stdlib.h>
#include<unistd.h>
#include<sys/wait.h>
#include<string.h>

int shmid;
double (*attachSharedMemory())[numUsers]{
    double (*matrix)[numUsers] = shmat(shmid,NULL,0);
    if (matrix == (void*)-1){
        perror("shmat");
        exit(1);
    }
    return matrix;
}
void detachSharedMemory(double (*matrix)[numUsers]){
    if(shmdt(matrix) == -1){
        perror("shmdt");
        exit(1);
    }
}
void releaseSharedMemory(){
    if (shmctl(shmid,IPC_RMID,NULL) == -1){
        perror("shmctl");
        exit(1);
    }
}
//  Line Processing 
void processLine(char *line, double (*matrix)[numUsers]){
    int userId= -1,movieIndex =-1,rating = -1;
    char *token = strtok(line,"\t");
    int idx = 0;
    while (token != NULL){
        if (idx ==0) userId = atoi(token)-1;
        else if (idx ==1 ) movieIndex =atoi(token) -1;
        else if (idx ==2 ) rating = atoi(token);
        idx++;
        token = strtok(NULL,"\t");
        if (idx>=3 && userId >= 0 && movieIndex >=0 ){
            matrix [movieIndex][userId] = rating;
        }
    }
    
}

void readFile(const char* fileName){

    double (*matrix)[numUsers] = attachSharedMemory();
    FILE * f = fopen(fileName,"r");
    if (!f){
        perror("fopen");
        exit(1);
    }
    char *line =NULL;
    size_t len =0;
    while (getline(&line,&len,f) != -1){
        processLine(line,matrix);
    }
    free(line);
    fclose(f);
    detachSharedMemory(matrix);
}

void computeAverage(double (*matrix)[numUsers]){
    for (int i=0;i<numMovies;i++){
        double sum =0.0;
        int count =0;
        for (int j=0;j<numUsers;j++){
            if (matrix[i][j] >= 0){
                sum += matrix[i][j];
                count++;
            }
        }
        double average = (count==0)? 0.0 : sum /count;
        printf("Movie %d has %.3f average rating\n",i,average);
    }
}

/*Create Process Child*/
void createChildProcess(const char *fileName){
    pid_t pid = fork(); // Create new process mới 
    if (pid ==0){
        readFile(fileName);
        exit(0);
    } else if (pid <0){
        perror("fork");
        exit(1);
    }
}
