#include "Task1.h"
#include <sys/ipc.h>
#include <sys/shm.h>
#include <stdio.h>
#include <sys/wait.h>




int main(){
    shmid = shmget(IPC_PRIVATE,sizeof(double[numMovies][numUsers]),0644 | IPC_CREAT);
    if(shmid < 0){
        perror("shmget");
        return 1;
    }
    printf("Shared memory ID: %d\n",shmid);

    double (*matrix)[numUsers] = attachSharedMemory();
    // Initialize primitive matrix
    for (int i=0;i<numMovies;i++){
        for (int j=0;j<numUsers;j++){
            matrix[i][j] =-1.0;
        }
    }
    createChildProcess("movie-100k_1.txt");
    createChildProcess("movie-100k_2.txt");

    wait(NULL);
    wait(NULL);

    computeAverage(matrix);
    detachSharedMemory(matrix);
    releaseSharedMemory();
    return 0;
}