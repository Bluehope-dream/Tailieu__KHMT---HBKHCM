import static org.junit.jupiter.api.Assertions.*;

import java.util.List;

import org.junit.jupiter.api.Test;


// Build: javac -d bin -cp ".;junit-platform-console-standalone-1.10.0.jar" Exercise1/src/*.java
// Run: java -jar junit-platform-console-standalone-1.10.0.jar execute --class-path bin --scan-class-path
public class TestCase {

    @Test
    void test_101() {
        Transcript t1 = new Transcript();

        assertEquals(0.0, t1.gpa4());
        assertEquals(0, t1.failedCount());
    }

    @Test
    void test_102() {
        Transcript t2 = new Transcript();
        t2.addCourseResult(new CourseResult("C1", 3, 8.5));

        assertEquals(4.0, t2.gpa4());
        assertEquals(0, t2.failedCount());
    }

    @Test
    void test_103() {
        Transcript t3 = new Transcript();
        t3.addCourseResult(new CourseResult("C1", 3, 4.0));

        assertEquals(1.0, t3.gpa4());
        assertEquals(1, t3.failedCount());
    }

    // --- GradedItem interface ---

    @Test
    void test_CourseResult_implementsGradedItem() {
        CourseResult cr = new CourseResult("C1", 3, 7.0);
        assertTrue(cr instanceof GradedItem);
    }

    // --- CourseResult construction & validation ---

    @Test
    void test_CourseResult_valid() {
        CourseResult cr = new CourseResult("C1", 3, 8.5);
        assertEquals("C1", cr.getCourseId());
        assertEquals(3, cr.getCredits());
        assertEquals(8.5, cr.getScore());
    }

    @Test
    void test_CourseResult_nullCourseId_throws() {
        assertThrows(Throwable.class, () -> new CourseResult(null, 3, 5.0));
    }

    @Test
    void test_CourseResult_emptyCourseId_throws() {
        assertThrows(Throwable.class, () -> new CourseResult("  ", 3, 5.0));
    }

    @Test
    void test_CourseResult_zeroCredits_throws() {
        assertThrows(Throwable.class, () -> new CourseResult("C1", 0, 5.0));
    }

    @Test
    void test_CourseResult_negativeCredits_throws() {
        assertThrows(Throwable.class, () -> new CourseResult("C1", -1, 5.0));
    }

    @Test
    void test_CourseResult_scoreBelowZero_throws() {
        assertThrows(Throwable.class, () -> new CourseResult("C1", 3, -0.1));
    }

    @Test
    void test_CourseResult_scoreAboveTen_throws() {
        assertThrows(Throwable.class, () -> new CourseResult("C1", 3, 10.1));
    }

    @Test
    void test_CourseResult_scoreBoundary_zero_and_ten() {
        assertDoesNotThrow(() -> new CourseResult("C1", 1, 0.0));
        assertDoesNotThrow(() -> new CourseResult("C1", 1, 10.0));
    }

    // --- Transcript: empty state ---

    @Test
    void test_Transcript_empty_gpa_and_failedCount() {
        Transcript t = new Transcript();
        assertEquals(0.0, t.gpa4());
        assertEquals(0, t.failedCount());
        assertTrue(t.getResults().isEmpty());
    }

    // --- Transcript: addCourseResult null ---

    @Test
    void test_Transcript_addNull_throws() {
        Transcript t = new Transcript();
        assertThrows(Throwable.class, () -> t.addCourseResult(null));
    }

    // --- Transcript: GPA score bracket boundaries ---

    @Test
    void test_gpa4_bracket_4_at_8_5() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5));
        assertEquals(4.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_3_at_7_0() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 7.0));
        assertEquals(3.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_3_at_8_4() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.4));
        assertEquals(3.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_2_at_5_5() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 5.5));
        assertEquals(2.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_2_at_6_9() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 6.9));
        assertEquals(2.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_1_at_4_0() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 4.0));
        assertEquals(1.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_1_at_5_4() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 5.4));
        assertEquals(1.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_0_at_3_9() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 3.9));
        assertEquals(0.0, t.gpa4());
    }

    @Test
    void test_gpa4_bracket_0_at_0_0() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 0.0));
        assertEquals(0.0, t.gpa4());
    }

    // --- Transcript: weighted GPA with multiple courses ---

    @Test
    void test_gpa4_weighted_multiple_courses() {
        // (4.0*3 + 2.0*2) / 5 = 16/5 = 3.2
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // 4.0
        t.addCourseResult(new CourseResult("C2", 2, 5.5)); // 2.0
        assertEquals(3.2, t.gpa4());
    }

    @Test
    void test_gpa4_rounding_applied() {
        // (3.0*1 + 2.0*1) / 2 = 2.5 → 2.5 (exact, no rounding effect)
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 1, 7.0)); // 3.0
        t.addCourseResult(new CourseResult("C2", 1, 5.5)); // 2.0
        assertEquals(2.5, t.gpa4());
    }

    @Test
    void test_gpa4_rounding_to_one_decimal() {
        // (4.0*2 + 1.0*1) / 3 = 9/3 = 3.0
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 2, 9.0)); // 4.0
        t.addCourseResult(new CourseResult("C2", 1, 4.5)); // 1.0
        assertEquals(3.0, t.gpa4());
    }

    // --- Transcript: failedCount ---

    @Test
    void test_failedCount_below5_isFailed() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 4.9));
        assertEquals(1, t.failedCount());
    }

    @Test
    void test_failedCount_exactly5_notFailed() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 5.0));
        assertEquals(0, t.failedCount());
    }

    @Test
    void test_failedCount_zero_score_failed() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 0.0));
        assertEquals(1, t.failedCount());
    }

    @Test
    void test_failedCount_multiple_mixed() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 4.9)); // fail
        t.addCourseResult(new CourseResult("C2", 3, 5.0)); // pass
        t.addCourseResult(new CourseResult("C3", 3, 0.0)); // fail
        assertEquals(2, t.failedCount());
    }

    // --- Transcript: getResults encapsulation ---

    @Test
    void test_getResults_isUnmodifiable() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 7.0));
        List<CourseResult> results = t.getResults();
        assertThrows(Throwable.class, () -> results.add(new CourseResult("C2", 2, 6.0)));
    }

    @Test
    void test_getResults_order_preserved() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0));
        t.addCourseResult(new CourseResult("C2", 2, 6.0));
        t.addCourseResult(new CourseResult("C3", 1, 4.0));
        List<CourseResult> results = t.getResults();
        assertEquals("C1", results.get(0).getCourseId());
        assertEquals("C2", results.get(1).getCourseId());
        assertEquals("C3", results.get(2).getCourseId());
    }

    @Test
    public void testOldCode_DataLeakage() {
        Transcript transcript = new Transcript();
        transcript.addCourseResult(new CourseResult("Math", 2, 9.0));
        List<CourseResult> externalList = transcript.getResults();
        
        assertEquals(1, externalList.size());

        transcript.addCourseResult(new CourseResult("Physics", 3, 10.0));

        assertEquals(1, externalList.size(), "List bên ngoài bị thay đổi theo dữ liệu bên trong!");
    }

    @Test
    public void testBoth_CannotModifyDirectly() {
        Transcript transcript = new Transcript();
        List<CourseResult> externalList = transcript.getResults();

        // Dù là code cũ hay mới, Collections.unmodifiableList đều chặn việc bên ngoài 
        // gọi hàm .add() hay .remove() trực tiếp. Chỗ này sẽ quăng lỗi.
        assertThrows(UnsupportedOperationException.class, () -> {
            externalList.add(new CourseResult("Chemistry", 2, 1.0));
        });
    }
}