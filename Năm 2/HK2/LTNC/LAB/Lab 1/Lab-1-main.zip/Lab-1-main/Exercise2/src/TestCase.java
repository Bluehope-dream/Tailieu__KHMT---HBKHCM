import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;


// Build: javac -d bin -cp .:../junit-platform-console-standalone-1.10.0.jar src/*.java
// Run: java -jar ../junit-platform-console-standalone-1.10.0.jar execute --class-path bin --scan-class-path
public class TestCase {
    @Test
    void test_201() {

        RegularStudent tc1 =
            new RegularStudent("  S2  ", "  Le Van An  ",
                    "  K20 ", " CSE  ", 80,
                    new Transcript());

        assertEquals("S2", tc1.getId());
        assertEquals("Le Van An", tc1.getFullName());
        assertEquals("K20", tc1.getCohort());
        assertEquals("CSE", tc1.getMajor());
    }

    @Test
    void test_202() {

        assertThrows(Throwable.class, () -> {
            new RegularStudent(
                "S1","Le Van An","K20","CSE",
                80,null);
        });
    }

    @Test
    void test_203() {

        RegularStudent tc3a =
            new RegularStudent("S4","Le Van An",
                    "K20","CSE",0,
                    new Transcript());

        RegularStudent tc3b =
            new RegularStudent("S5","Le Van An",
                    "K20","CSE",100,
                    new Transcript());

        assertEquals(0, tc3a.getDisciplineScore());
        assertEquals(100, tc3b.getDisciplineScore());
    }

    @Test
    void test_Student_trimming() {
        RegularStudent s = new RegularStudent("  S1  ", "  Le Van An  ",
                "  K20  ", "  CSE  ", 80, new Transcript());
        assertEquals("S1", s.getId());
        assertEquals("Le Van An", s.getFullName());
        assertEquals("K20", s.getCohort());
        assertEquals("CSE", s.getMajor());
    }

    // --- Student: null/invalid constructor args ---

    @Test
    void test_Student_nullTranscript_throws() {
        assertThrows(Throwable.class, () ->
                new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, null));
    }

    @Test
    void test_Student_emptyId_throws() {
        assertThrows(Throwable.class, () ->
                new RegularStudent("  ", "Le Van An", "K20", "CSE", 80, new Transcript()));
    }

    @Test
    void test_Student_nullFullName_throws() {
        assertThrows(Throwable.class, () ->
                new RegularStudent("S1", null, "K20", "CSE", 80, new Transcript()));
    }

    @Test
    void test_Student_disciplineScore_boundary_valid() {
        assertDoesNotThrow(() -> new RegularStudent("S1", "Le Van An", "K20", "CSE", 0, new Transcript()));
        assertDoesNotThrow(() -> new RegularStudent("S2", "Le Van An", "K20", "CSE", 100, new Transcript()));
    }

    @Test
    void test_Student_disciplineScore_outOfRange_throws() {
        assertThrows(Throwable.class, () ->
                new RegularStudent("S1", "Le Van An", "K20", "CSE", -1, new Transcript()));
        assertThrows(Throwable.class, () ->
                new RegularStudent("S1", "Le Van An", "K20", "CSE", 101, new Transcript()));
    }

    // --- Student: setters ---

    @Test
    void test_Student_setters_valid() {
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, new Transcript());
        s.setCohort("K21");
        s.setMajor("IT");
        s.setDisciplineScore(90);
        assertEquals("K21", s.getCohort());
        assertEquals("IT", s.getMajor());
        assertEquals(90, s.getDisciplineScore());
    }

    @Test
    void test_Student_setters_invalid_throws() {
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, new Transcript());
        assertThrows(Throwable.class, () -> s.setCohort(null));
        assertThrows(Throwable.class, () -> s.setMajor("  "));
        assertThrows(Throwable.class, () -> s.setDisciplineScore(-1));
        assertThrows(Throwable.class, () -> s.setDisciplineScore(101));
    }

    // --- Student: getEnglishName ---

    @Test
    void test_getEnglishName_threeWords() {
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, new Transcript());
        assertEquals("Van-An Le", s.getEnglishName());
    }

    @Test
    void test_getEnglishName_twoWords() {
        RegularStudent s = new RegularStudent("S1", "Tran An", "K20", "CSE", 80, new Transcript());
        assertEquals("An Tran", s.getEnglishName());
    }

    @Test
    void test_getEnglishName_fourWords() {
        RegularStudent s = new RegularStudent("S1", "Nguyen Thi Thu Ha", "K20", "CSE", 80, new Transcript());
        assertEquals("Thi-Thu-Ha Nguyen", s.getEnglishName());
    }

    // --- Student: GPA/failedCount delegation ---

    @Test
    void test_Student_getGpa4_delegatesToTranscript() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0)); // 4.0
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, t);
        assertEquals(4.0, s.getGpa4());
    }

    @Test
    void test_Student_failedCount_delegatesToTranscript() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 4.0)); // fail
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, t);
        assertEquals(1, s.failedCount());
    }

    // --- RegularStudent: tuitionDiscountRate ---

    @Test
    void test_RegularStudent_tuitionDiscountRate_alwaysZero() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0));
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 95, t);
        assertEquals(0.0, s.tuitionDiscountRate());
    }

    // --- RegularStudent: eligibleForHonorsUpgrade ---

    @Test
    void test_eligibleForHonorsUpgrade_true() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // gpa 4.0
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 85, t);
        assertTrue(s.eligibleForHonorsUpgrade());
    }

    @Test
    void test_eligibleForHonorsUpgrade_false_lowGpa() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 7.0)); // gpa 3.0 < 3.4
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 90, t);
        assertFalse(s.eligibleForHonorsUpgrade());
    }

    @Test
    void test_eligibleForHonorsUpgrade_false_lowDiscipline() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0)); // gpa 4.0
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 84, t);
        assertFalse(s.eligibleForHonorsUpgrade());
    }

    @Test
    void test_eligibleForHonorsUpgrade_false_hasFailed() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0)); // 4.0
        t.addCourseResult(new CourseResult("C2", 3, 4.0)); // fail
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 90, t);
        assertFalse(s.eligibleForHonorsUpgrade());
    }

    @Test
    void test_eligibleForHonorsUpgrade_boundary_gpa_3_4() {
        // Need GPA exactly 3.4 after rounding
        // (4.0*2 + 2.0*1) / 3 = 10/3 ≈ 3.3 → 3.3 — not eligible
        // (4.0*3 + 3.0*1) / 4 = 15/4 = 3.75 → 3.8 — eligible
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // 4.0
        t.addCourseResult(new CourseResult("C2", 1, 7.0)); // 3.0
        RegularStudent s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 85, t);
        // (4*3 + 3*1)/4 = 15/4 = 3.75 → rounds to 3.8
        assertTrue(s.eligibleForHonorsUpgrade());
    }

    // --- HonorsStudent: tuitionDiscountRate ---

    @Test
    void test_HonorsStudent_tuitionDiscount_0_1_whenQualified() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // gpa 4.0
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 80, t);
        assertEquals(0.1, s.tuitionDiscountRate());
    }

    @Test
    void test_HonorsStudent_tuitionDiscount_0_lowGpa() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 7.0)); // gpa 3.0 < 3.2
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 80, t);
        assertEquals(0.0, s.tuitionDiscountRate());
    }

    @Test
    void test_HonorsStudent_tuitionDiscount_0_lowDiscipline() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // gpa 4.0
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 79, t);
        assertEquals(0.0, s.tuitionDiscountRate());
    }

    @Test
    void test_HonorsStudent_tuitionDiscount_boundary_discipline80() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5));
        HonorsStudent exactly80 = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 80, t);
        assertEquals(0.1, exactly80.tuitionDiscountRate());
    }

    // --- HonorsStudent: maintainsHonorsStatus ---

    @Test
    void test_maintainsHonorsStatus_true() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // gpa 4.0
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 75, t);
        assertTrue(s.maintainsHonorsStatus());
    }

    @Test
    void test_maintainsHonorsStatus_false_lowGpa() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 7.0)); // gpa 3.0 < 3.2
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 75, t);
        assertFalse(s.maintainsHonorsStatus());
    }

    @Test
    void test_maintainsHonorsStatus_false_lowDiscipline() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5)); // gpa 4.0
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 74, t);
        assertFalse(s.maintainsHonorsStatus());
    }

    @Test
    void test_maintainsHonorsStatus_false_hasFailed() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0));
        t.addCourseResult(new CourseResult("C2", 3, 4.0)); // fail
        HonorsStudent s = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 75, t);
        assertFalse(s.maintainsHonorsStatus());
    }

    @Test
    void test_maintainsHonorsStatus_boundary_discipline75() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5));
        HonorsStudent s75 = new HonorsStudent("S1", "Le Van An", "K20", "CSE", 75, t);
        HonorsStudent s74 = new HonorsStudent("S2", "Le Van An", "K20", "CSE", 74, t);
        assertTrue(s75.maintainsHonorsStatus());
        assertFalse(s74.maintainsHonorsStatus());
    }

    // --- Polymorphism: Student reference ---

    @Test
    void test_polymorphism_tuitionDiscountRate() {
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 8.5));

        Student regular = new RegularStudent("S1", "Le Van An", "K20", "CSE", 90, t);
        Student honors  = new HonorsStudent("S2", "Le Van An", "K20", "CSE", 80, t);

        assertEquals(0.0, regular.tuitionDiscountRate());
        assertEquals(0.1, honors.tuitionDiscountRate());
    }
}