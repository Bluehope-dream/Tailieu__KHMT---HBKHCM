# Lab 1: Student Classification System

## Chạy dự án

### Bước 1: chạy openjdk trên docker

```sh
PS C:\Code\LTNC> docker run -it --name ltnc-lab1 -v ${PWD}:/app  -w /app eclipse-temurin:21 bash
root@be1737d039e4:/app# java -version
openjdk version "21.0.10" 2026-01-20 LTS
OpenJDK Runtime Environment Temurin-21.0.10+7 (build 21.0.10+7-LTS)
OpenJDK 64-Bit Server VM Temurin-21.0.10+7 (build 21.0.10+7-LTS, mixed mode, sharing)
```

### Bước 2: Chạy test 

```
// vào vị trí Exercise1 muốn chạy test case
root@be1737d039e4:/app# cd Exercise1

// build bin/
root@be1737d039e4:/app/Exercise1# javac -d bin -cp .:../junit-platform-console-standalone-1.10.0.jar src/*.java

// Run Test
root@be1737d039e4:/app/Exercise1# java -jar ../junit-platform-console-standalone-1.10.0.jar execute --class-path bin --scan-class-path

// Đối với Exercise2, Exercise3, Exercise4 tương tự
```

---

<p align="center">
  <a href="https://www.facebook.com/Shiba.Vo.Tien">
    <img src="https://img.shields.io/badge/Facebook-1877F2?style=for-the-badge&logo=facebook&logoColor=white" alt="Facebook"/>
  </a>
  <a href="https://www.tiktok.com/@votien_shiba">
    <img src="https://img.shields.io/badge/TikTok-000000?style=for-the-badge&logo=tiktok&logoColor=white" alt="TikTok"/>
  </a>
  <a href="https://www.facebook.com/groups/khmt.ktmt.cse.bku?locale=vi_VN">
    <img src="https://img.shields.io/badge/Facebook%20Group-4267B2?style=for-the-badge&logo=facebook&logoColor=white" alt="Facebook Group"/>
  </a>
  <a href="https://www.facebook.com/CODE.MT.BK">
    <img src="https://img.shields.io/badge/Page%20CODE.MT.BK-0057FF?style=for-the-badge&logo=facebook&logoColor=white" alt="Facebook Page"/>
  </a>
  <a href="https://github.com/VoTienBKU">
    <img src="https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white" alt="GitHub"/>
  </a>
</p>
