import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

// Build: javac -d bin -cp .:../junit-platform-console-standalone-1.10.0.jar src/*.java
// Run: java -jar ../junit-platform-console-standalone-1.10.0.jar execute --class-path bin --scan-class-path
public class TestCase {

    private Student studentWith(int disciplineScore, CourseResult... courses) {
        Transcript t = new Transcript();
        for (CourseResult c : courses) t.addCourseResult(c);
        return new RegularStudent("S1", "Le Van An", "K20", "CSE", disciplineScore, t);
    }

    private Student studentWith(CourseResult... courses) {
        return studentWith(80, courses);
    }

    // =========================================================
    // Classification enum
    // =========================================================

    @Test
    void test_Classification_allValuesExist() {
        assertNotNull(Classification.EXCELLENT);
        assertNotNull(Classification.GOOD);
        assertNotNull(Classification.FAIR);
        assertNotNull(Classification.PASS);
        assertNotNull(Classification.FAIL);
    }

    // =========================================================
    // ClassificationPolicy: null guard (both policies)
    // =========================================================

    @Test
    void test_301() {
        ClassificationPolicy standard = new StandardPolicy();
        assertThrows(Throwable.class, () -> standard.classify(null));
    }

    @Test
    void test_StrictPolicy_nullStudent_throws() {
        ClassificationPolicy strict = new StrictPolicy();
        assertThrows(Throwable.class, () -> strict.classify(null));
    }

    // =========================================================
    // StandardPolicy – FAIL cases
    // =========================================================

    @Test
    void test_302() {
        // score 4.0 → gpa4 = 1.0 < 2.0 → FAIL
        ClassificationPolicy standard = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 4.0));
        assertEquals(Classification.FAIL, standard.classify(s));
    }

    @Test
    void test_Standard_FAIL_gpaBelow2_exact() {
        // score 3.9 → 0.0, gpa = 0.0 → FAIL
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 3.9));
        assertEquals(Classification.FAIL, p.classify(s));
    }

    @Test
    void test_Standard_FAIL_twoFailedCourses() {
        // two failed (score < 5.0), failedCount = 2 → FAIL regardless of gpa
        ClassificationPolicy p = new StandardPolicy();
        // gpa would be 2.0 (both score 5.5 → point4 2.0) but failedCount = 2 with 4.9
        Student s = studentWith(
            new CourseResult("C1", 3, 4.9),  // fail
            new CourseResult("C2", 3, 4.9)   // fail
        );
        assertEquals(Classification.FAIL, p.classify(s));
    }

    @Test
    void test_Standard_FAIL_highGpa_twoFailed() {
        // gpa ≥ 3.6 but failedCount = 2 → FAIL (failedCount rule dominates)
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 3, 9.0),  // 4.0
            new CourseResult("C2", 3, 4.9),  // fail
            new CourseResult("C3", 3, 4.9)   // fail
        );
        assertEquals(Classification.FAIL, p.classify(s));
    }

    @Test
    void test_Standard_FAIL_emptyTranscript() {
        // gpa = 0.0 → FAIL
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith();
        assertEquals(Classification.FAIL, p.classify(s));
    }

    // =========================================================
    // StandardPolicy – PASS cases
    // =========================================================

    @Test
    void test_303() {
        // score 5.5 → point4 2.0, gpa = 2.0 → PASS
        ClassificationPolicy standard = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 5.5));
        assertEquals(Classification.PASS, standard.classify(s));
    }

    @Test
    void test_Standard_PASS_boundary_lower() {
        // gpa exactly 2.0 → PASS
        ClassificationPolicy p = new StandardPolicy();
        // score 5.5 → 2.0 (already tested), use weighted to hit 2.0
        Student s = studentWith(new CourseResult("C1", 3, 6.9)); // 2.0
        assertEquals(Classification.PASS, p.classify(s));
    }

    @Test
    void test_Standard_PASS_boundary_upper() {
        // gpa 2.4 → still PASS (< 2.5)
        // single course: score 5.5 → 2.0 — use 2 courses to hit ~2.4
        // (2.0*3 + 3.0*1)/4 = 9/4 = 2.25 → 2.3
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 3, 6.0),  // 2.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.PASS, p.classify(s));
    }

    // =========================================================
    // StandardPolicy – FAIR cases
    // =========================================================

    @Test
    void test_Standard_FAIR_boundary_lower() {
        // gpa exactly 2.5 → FAIR
        // (2.0*1 + 3.0*1)/2 = 2.5
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 1, 5.5),  // 2.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.FAIR, p.classify(s));
    }

    @Test
    void test_Standard_FAIR_boundary_upper() {
        // gpa 3.1 → still FAIR (< 3.2)
        // (3.0*3 + 2.0*1)/4 = 11/4 = 2.75 → 2.8 (not right)
        // (4.0*1 + 2.0*3)/4 = 10/4 = 2.5 → FAIR
        // need 3.1 after rounding: (3.0*2 + 2.0*1)/3 = 8/3 = 2.67 → 2.7
        // simpler: use single course score 7.0 → 3.0 (FAIR)
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 8.4)); // 3.0 → FAIR
        assertEquals(Classification.FAIR, p.classify(s));
    }

    // =========================================================
    // StandardPolicy – GOOD cases
    // =========================================================

    @Test
    void test_Standard_GOOD_boundary_lower() {
        // gpa exactly 3.2 → GOOD
        // (4.0*2 + 2.0*1)/3 = 10/3 = 3.33 → 3.3 (FAIR?)
        // (4.0*1 + 3.0*2)/3 = 10/3 = 3.3 → FAIR
        // Try: (4.0*3 + 2.0*2)/5 = 16/5 = 3.2 → 3.2 → GOOD
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 3, 8.5),  // 4.0
            new CourseResult("C2", 2, 5.5)   // 2.0
        );
        assertEquals(Classification.GOOD, p.classify(s));
    }

    @Test
    void test_Standard_GOOD_boundary_upper() {
        // gpa 3.5 → GOOD (< 3.6)
        // (4.0*2 + 3.0*1)/3 = 11/3 = 3.67 → 3.7 → not GOOD if failedCount 0
        // (4.0*3 + 3.0*2)/5 = 18/5 = 3.6 → EXCELLENT if failedCount 0
        // (3.0*3 + 4.0*1)/4 = 13/4 = 3.25 → 3.3 → FAIR
        // (4.0*3 + 2.0*3)/6 = 18/6 = 3.0 → FAIR
        // Simple: use two courses to make gpa exactly 3.5
        // (4.0*1 + 3.0*1)/2 = 3.5 → GOOD
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 1, 8.5),  // 4.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.GOOD, p.classify(s));
    }

    // =========================================================
    // StandardPolicy – EXCELLENT cases
    // =========================================================

    @Test
    void test_Standard_EXCELLENT() {
        // gpa = 4.0, failedCount = 0 → EXCELLENT
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 9.0));
        assertEquals(Classification.EXCELLENT, p.classify(s));
    }

    @Test
    void test_Standard_EXCELLENT_boundary_gpa_3_6() {
        // gpa exactly 3.6, failedCount = 0 → EXCELLENT
        // (4.0*3 + 3.0*2)/5 = 18/5 = 3.6
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 3, 9.0),  // 4.0
            new CourseResult("C2", 2, 7.0)   // 3.0
        );
        assertEquals(Classification.EXCELLENT, p.classify(s));
    }

    @Test
    void test_Standard_notEXCELLENT_when_oneFailed_highGpa() {
        // gpa ≥ 3.6 but failedCount = 1 → NOT EXCELLENT (and NOT FAIL since < 2 failed)
        ClassificationPolicy p = new StandardPolicy();
        Student s = studentWith(
            new CourseResult("C1", 3, 9.0),  // 4.0
            new CourseResult("C2", 3, 9.0),  // 4.0
            new CourseResult("C3", 3, 4.9)   // fail, point4=1.0
        );
        // gpa = (4+4+1)/3 = 3.0 → FAIR actually since 1 fail
        // Need gpa ≥ 3.6 with exactly 1 failed course
        // (4.0*9 + 1.0*1)/10 = 37/10 = 3.7, failedCount=1 → not EXCELLENT, not FAIL
        Transcript t2 = new Transcript();
        for (int i = 0; i < 9; i++) t2.addCourseResult(new CourseResult("C" + i, 1, 9.0)); // 4.0 each
        t2.addCourseResult(new CourseResult("CF", 1, 4.9)); // fail, 1.0
        Student s2 = new RegularStudent("S2", "Le Van An", "K20", "CSE", 80, t2);
        // gpa = (4.0*9 + 1.0*1)/10 = 37/10 = 3.7
        assertNotEquals(Classification.EXCELLENT, p.classify(s2));
        assertNotEquals(Classification.FAIL, p.classify(s2));
    }

    // =========================================================
    // StrictPolicy – FAIL cases
    // =========================================================

    @Test
    void test_Strict_FAIL_anyFailedCourse() {
        // failedCount = 1 → FAIL (strict threshold is ≥ 1)
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 4.9));
        assertEquals(Classification.FAIL, p.classify(s));
    }

    @Test
    void test_Strict_FAIL_gpaBelow2_2() {
        // gpa = 2.0 < 2.2 → FAIL
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 5.5)); // 2.0
        assertEquals(Classification.FAIL, p.classify(s));
    }

    @Test
    void test_Strict_FAIL_emptyTranscript() {
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith();
        assertEquals(Classification.FAIL, p.classify(s));
    }

    // =========================================================
    // StrictPolicy – PASS cases
    // =========================================================

    @Test
    void test_Strict_PASS_boundary_lower() {
        // gpa = 2.2 → PASS  (need exactly 2.2 after rounding)
        // (2.0*4 + 3.0*1)/5 = 11/5 = 2.2
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(
            new CourseResult("C1", 4, 6.0),  // 2.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.PASS, p.classify(s));
    }

    @Test
    void test_Strict_PASS_below_2_7() {
        // gpa = 2.5 → PASS (< 2.7)
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(
            new CourseResult("C1", 1, 6.0),  // 2.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.PASS, p.classify(s));
    }

    // =========================================================
    // StrictPolicy – FAIR cases
    // =========================================================

    @Test
    void test_Strict_FAIR_boundary_lower() {
        // gpa = 2.7 → FAIR  (2.0*1 + 4.0*1 + 2.0*1)/3 ... try (3.0*1 + 2.0*2)/3 = 7/3 = 2.3
        // (3.0*2 + 2.0*1)/3 = 8/3 = 2.67 → 2.7 → FAIR
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(
            new CourseResult("C1", 2, 7.0),  // 3.0
            new CourseResult("C2", 1, 6.0)   // 2.0
        );
        assertEquals(Classification.FAIR, p.classify(s));
    }

    @Test
    void test_Strict_FAIR_below_3_3() {
        // gpa = 3.0 → FAIR
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 8.4)); // 3.0
        assertEquals(Classification.FAIR, p.classify(s));
    }

    // =========================================================
    // StrictPolicy – GOOD cases
    // =========================================================

    @Test
    void test_Strict_GOOD_boundary_lower() {
        // gpa exactly 3.3 → GOOD
        // (4.0*3 + 2.0*2)/5 = 16/5 = 3.2 → not 3.3
        // (4.0*2 + 3.0*1)/3 = 11/3 = 3.67 → 3.7
        // (3.0*3 + 4.0*1)/4 = 13/4 = 3.25 → 3.3 → GOOD (strict)
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(
            new CourseResult("C1", 3, 8.4),  // 3.0
            new CourseResult("C2", 1, 8.5)   // 4.0
        );
        assertEquals(Classification.GOOD, p.classify(s));
    }

    @Test
    void test_Strict_GOOD_below_3_7() {
        // gpa = 3.5 → GOOD
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(
            new CourseResult("C1", 1, 8.5),  // 4.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.GOOD, p.classify(s));
    }

    // =========================================================
    // StrictPolicy – EXCELLENT cases
    // =========================================================

    @Test
    void test_Strict_EXCELLENT() {
        // gpa = 4.0, failedCount = 0 → EXCELLENT
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 9.0));
        assertEquals(Classification.EXCELLENT, p.classify(s));
    }

    @Test
    void test_Strict_EXCELLENT_boundary_gpa_3_7() {
        // gpa = 3.7, failedCount = 0 → EXCELLENT
        // (4.0*2 + 3.0*1)/3 = 11/3 = 3.67 → 3.7 ✓
        ClassificationPolicy p = new StrictPolicy();
        Student s = studentWith(
            new CourseResult("C1", 2, 8.5),  // 4.0
            new CourseResult("C2", 1, 7.0)   // 3.0
        );
        assertEquals(Classification.EXCELLENT, p.classify(s));
    }

    @Test
    void test_Strict_EXCELLENT_requires_noFailed() {
        // gpa = 4.0 but failedCount = 1 → not EXCELLENT
        ClassificationPolicy p = new StrictPolicy();
        // 1 failed → FAIL immediately under StrictPolicy
        Student s = studentWith(new CourseResult("C1", 3, 4.9));
        assertEquals(Classification.FAIL, p.classify(s));
    }

    // =========================================================
    // Policy difference: same student, different classification
    // =========================================================

    @Test
    void test_Standard_vs_Strict_sameStudent_differentResult() {
        // gpa = 2.0 → Standard: PASS, Strict: FAIL
        ClassificationPolicy standard = new StandardPolicy();
        ClassificationPolicy strict = new StrictPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 5.5)); // gpa 2.0
        assertEquals(Classification.PASS, standard.classify(s));
        assertEquals(Classification.FAIL, strict.classify(s));
    }

    @Test
    void test_Standard_vs_Strict_oneFailed() {
        // failedCount = 1, gpa > 2.0 → Standard: depends on gpa, Strict: FAIL
        ClassificationPolicy standard = new StandardPolicy();
        ClassificationPolicy strict = new StrictPolicy();
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0)); // 4.0
        t.addCourseResult(new CourseResult("C2", 3, 4.9)); // fail
        Student s = new RegularStudent("S1", "Le Van An", "K20", "CSE", 80, t);
        // gpa = (4.0+1.0)/2 = 2.5, failedCount=1
        assertEquals(Classification.FAIR, standard.classify(s));
        assertEquals(Classification.FAIL, strict.classify(s));
    }

    // =========================================================
    // Polymorphism: HonorsStudent classified via Student ref
    // =========================================================

    @Test
    void test_Policy_worksWithHonorsStudent() {
        ClassificationPolicy p = new StandardPolicy();
        Transcript t = new Transcript();
        t.addCourseResult(new CourseResult("C1", 3, 9.0));
        Student s = new HonorsStudent("H1", "Nguyen Thi B", "K20", "CSE", 90, t);
        assertEquals(Classification.EXCELLENT, p.classify(s));
    }

    // =========================================================
    // Provided tests (301-303)
    // =========================================================

    @Test
    void test_providedTest_302_duplicate() {
        ClassificationPolicy standard = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 4.0));
        assertEquals(Classification.FAIL, standard.classify(s));
    }

    @Test
    void test_providedTest_303_duplicate() {
        ClassificationPolicy standard = new StandardPolicy();
        Student s = studentWith(new CourseResult("C1", 3, 5.5));
        assertEquals(Classification.PASS, standard.classify(s));
    }
}