public interface Priceable {
    double getCurrentPriceValue();

    double getPriceChange(double previousPrice);
    // Calculate absolute change of Price
    double getPriceChangePercent(double previousPrice);
    // Calculate absoute change of percentage price 
}
