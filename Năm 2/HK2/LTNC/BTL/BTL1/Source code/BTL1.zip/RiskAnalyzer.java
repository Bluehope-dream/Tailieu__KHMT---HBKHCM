import java.util.*;

public class RiskAnalyzer<T extends Instrument>{
   
    private List<T> instruments;
    public RiskAnalyzer(){
        instruments = new ArrayList<>();
    }
    public void add(T instrument){
        if (instrument == null) {
            throw new IllegalArgumentException("Instrument cannot be null");
        }
    //     int count =0;
    //     for (T i : instruments){
    //         if (i.getSymbol().equals(instrument.getSymbol())){
    //             instruments.set(count,instrument);
    //             i.updatePrice(instrument.getCurrentPriceValue());
    //             return;
    //         }
    //         count++;
    //    }
    Iterator<T> it = instruments.iterator();
    while (it.hasNext()){
        T tmp = it.next();
        if (tmp.getSymbol().equals(instrument.getSymbol())){
            it.remove();
        }
    }
       instruments.add(instrument);
       
    }
    public double averageRisk(){
        // Output : average riskScore of all Instruments
        if (instruments.isEmpty()) {
            throw new NoSuchElementException("No instruments.");
        }
        double total =0.0;
        for (T i : instruments ){
            total += i.riskScore();
        }
        return (total/instruments.size());
    }
    public T highestRisk(){
        // Output: return instrument with the highest riskScore
         if (instruments.isEmpty()) {
            throw new NoSuchElementException("No instruments.");
        }
        
        T max = instruments.get(0); 
        for (T i: instruments){
            
            if (i.riskScore() > max.riskScore()){
                max =i;
            }
        }
        return max;
    }
    public T lowestRisk(){
        // Output: return instrument with the lowest riskScore
        if (instruments.isEmpty()) {
            throw new NoSuchElementException("No instruments.");
        }
        T min = instruments.get(0);
        for (T i: instruments){
            if (i.riskScore()<min.riskScore()){
                min =i;
            }
        }
        return min;
    }

    public List<T> getAboveRiskThreshold(double threshold){
        List<T> res = new ArrayList<>();
        if (instruments.isEmpty()) return res;
        for (T i: instruments){
            if (i.riskScore()>threshold){
                res.add(i);
            }
        }
        return res;
    }
   
    public List<T> getUnionInstrument(){
        return instruments;
    }

}