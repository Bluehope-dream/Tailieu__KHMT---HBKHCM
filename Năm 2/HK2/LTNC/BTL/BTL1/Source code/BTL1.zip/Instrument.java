import java.time.LocalDateTime;

public abstract class Instrument implements Tradeable, Priceable{
    private final String symbol;
    private String name;
    private double currentPrice;
    private LocalDateTime lastUpdated;

    public Instrument(String symbol, String name, double currentPrice) {
        // TODO
        // throw new UnsupportedOperationException("TODO") 
        //  This line of codes highlights incomplete body of method.
        this.symbol =symbol;
        this.name = name;
        this.currentPrice = currentPrice;
        this.lastUpdated = LocalDateTime.now(); // Cập nhật thời gian khi khai báo 
    }

    public abstract double riskScore();

    public abstract String assetClass();

    public abstract void accept(InstrumentVisitor visior);


    public LocalDateTime getUpDateTime(){
        return lastUpdated;
    }
    public void updatePrice(double newPrice) {
        // TODO
        // throw new UnsupportedOperationException("TODO");
        if (newPrice<0){
            throw new IllegalArgumentException();
        }
        this.currentPrice = newPrice;
        this.lastUpdated = LocalDateTime.now(); // Cập nhật biến mới vào 
    }
    @Override
    public String getSymbol() {
        // TODO
        // throw new UnsupportedOperationException("TODO");
        return symbol;
    }

    public String getName() {
        // TODO
        
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
    public void setCurrentPrice(double price){
        this.currentPrice= price;
    }
    @Override
    public double getCurrentPriceValue() {
        // TODO
        if (currentPrice < 0){
            throw new  IllegalArgumentException();
        }
        return currentPrice;
    }

    public LocalDateTime getLastUpdated() {
        // TODO
        return lastUpdated;
    }

    @Override
    public String toString() {
        // TODO
        // Output format: "<ClassName>[symbol=<s>, price=<p>, risk=<r>]"
        return getClass().getSimpleName() +"[symbol="+ getSymbol()+", price="+String.format("%.2f", getCurrentPriceValue())+", risk="+ String.format("%.2f", riskScore())+"]";
    }
    @Override 
    public double getPriceChange(double previousPrice){
        return (getCurrentPriceValue()- previousPrice);
    }

    @Override
    public double getPriceChangePercent( double previousPrice){
        if (previousPrice==0.0){
            throw new IllegalArgumentException("Invalid previous price: division by zero");
        }
        return ((getCurrentPriceValue()-previousPrice)/previousPrice*100.0);
    }
    @Override
    public boolean isAvailableForTrading(){
        return true;
    }

}
