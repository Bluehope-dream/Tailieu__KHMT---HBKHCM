public interface Tradeable {
    String getSymbol();

    double getCurrentPriceValue();

    boolean isAvailableForTrading();    // tell me if bought or not!!

    default String getTradingInfo() {
        // TODO
        // Output: return formatted trading summary
        return 
        // "Tradeable: "+
         getSymbol() 
                +" @ "+ 
                String.format("%.2f", getCurrentPriceValue())
            // getCurrentPriceValue()
             + (isAvailableForTrading()? " [AVAILABLE]":" [Unavailable]");
        // Update dùng 2 chũ số thập phân mà cập nhật nhé 
    }
}
