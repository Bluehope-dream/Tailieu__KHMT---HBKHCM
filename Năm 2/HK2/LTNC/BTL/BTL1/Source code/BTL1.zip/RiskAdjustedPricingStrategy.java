// TODO

public class RiskAdjustedPricingStrategy implements PricingStrategy{
    // Do mỗi interface với các chiến lược tính khác nhau nên đa hình phải ghi đè interface trừ kiểu default thì ko cần đâu 

    @Override
    public double calculateFairValue(Instrument i){
        return (i.getCurrentPriceValue()*(1+0.01 *i.riskScore()));
    }

    @Override
    public String strategyName() {
        return "RiskAdjustedPricingStrategy";
    }

}