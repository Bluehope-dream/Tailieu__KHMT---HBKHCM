// TODO


public interface PricingStrategy{
    double calculateFairValue(Instrument i);
    String strategyName();
}