import java.util.*;


public class Portfolio implements  Observable<String> {
    private final String portfolioId;
    private final String ownerName;
    private final List<Position> positions;
    private final List<Observer<String>> observers;

    public Portfolio(String portfolioId, String ownerName) {
        // TODO
        this.portfolioId = portfolioId;
        this.ownerName = ownerName;
        this.positions = new ArrayList<>();
        this.observers = new ArrayList <>();
    }
 
    public void addPosition(Instrument inst, int qty, double costBasis) {
        // TODO
        for (Position p : positions){
            if (p.getInstrument().getSymbol().equals(inst.getSymbol())){
                p.addQuantity(qty, costBasis);
                notifyObservers("ADDED: "+ inst.getSymbol()+" x"+qty);
                return;
            }
        }
        Position newElement = new Position(inst, qty, costBasis);
        positions.add(newElement);
        notifyObservers("ADDED: "+ inst.getSymbol()+" x"+qty);
    }
  
    public void removePosition(String symbol) throws PositionNotFoundException {
        // TODO
        // Never modigy your code by for =- each base 
        // for (Position p : positions){
        //     if (p.getInstrument().getSymbol().equals(symbol)){
        //         positions.remove(p);
        //         notifyObservers("REMOVED: "+ symbol);
        //         return;
        //     }
        // }
        Iterator<Position> it = positions.iterator();
        while (it.hasNext()){
            Position tmp = it.next();
            if (tmp.getInstrument().getSymbol().equals(symbol)){
                it.remove();
                notifyObservers("REMOVED: "+ symbol);
                return;
            }
        }
        throw new PositionNotFoundException("Position not found: "+ symbol);

    }

    public double totalMarketValue() {
        // TODO
        double sum =0.0;
        for (Position p : positions){
            sum += p.marketValue();
        }
        return sum;
    }

    public double totalUnrealizedPnL() {
        // TODO
        double sum =0.0;
        for (Position p : positions){
            sum += p.unrealizedPnL();
        }
        return sum;
    }

    public Position getPosition(String symbol) throws PositionNotFoundException {
        // TODO
        // Học thêm cách chạy mảng trên java vào ngày mai đi 
        for (Position p: positions){
            if(p.getInstrument().getSymbol().equals(symbol)){
                return p;
            }
        }
        throw new PositionNotFoundException("Position not found: "+ symbol);

    }

    public List<Position> getPositionsSortedByValue() {
        // TODO
        // Ouput: arrange your sorted position in List  by marketValue()
        List<Position> newList = new ArrayList<>(positions);
        int n = newList.size();
        // Method Sort : Selection Sort 
        for (int i=0;i<n-1;i++){
            int maxIdx = i;
            for (int j=i+1;j<n;j++){
                if (newList.get(j).marketValue() > newList.get(maxIdx).marketValue()) {
                    maxIdx = j;
                 }
                   // swap
            }
            Position temp = newList.get(i);
            newList.set(i, newList.get(maxIdx));
            newList.set(maxIdx, temp);
        }
        return newList;
    }

    public Map<String, Double> allocationByAssetClass() {
        // TODO
        Map<String,Double> allocation = new HashMap<>();

        double sum = totalMarketValue();

        if (sum==0) return allocation;

        for (Position p: positions){
            String assetClass = p.getInstrument().assetClass();  // Define your name assetClass of instruments
            double value = p.marketValue();

            allocation.put(assetClass,allocation.getOrDefault(assetClass, 0.0)+ value);
        }

        // Chuyển nó sang phần trăm

        for (String key: allocation.keySet()){
            double ratio = (allocation.get(key)/sum) *100;
            allocation.put(key,ratio);
        }
        return allocation;
    }

    public void revalueAll(PricingStrategy strategy) {
        // TODO
        // Output: Calculate your value of strategy 
        for(Position p : positions){
            Instrument instr = p.getInstrument();

            double newPrice = strategy.calculateFairValue(instr);

            instr.updatePrice(newPrice);
        }

        notifyObservers("REVALUED: "+ strategy.strategyName());
        
    }

    
    public void addObserver(Observer<String> observer) {
        // TODO
        // for (Observer<String> s: observers){
        //     if (s.equals(observer)){
        //         observers.remove(s);
        //     }
        // }
        Iterator<Observer<String>> it = observers.iterator();
        while (it.hasNext()){
            Observer<String> tmp = it.next();
            if (tmp.equals(observer)){
                it.remove();
            }
        }
       observers.add(observer);
    }

    
    public void removeObserver(Observer<String> observer) {
        // TODO
        observers.remove(observer);
    }


    public void notifyObservers(String event) {
        // TODO
        for (Observer<String> obs: observers){
            obs.onEvent(event);
        }
       
    }

    public String getPortfolioId() {
        // TODO
        return portfolioId;
    }

    public String getOwnerName() {
        // TODO
        return  ownerName;
    }
}
