
// Application of Visitor Pattern / Structural Pattern

import java.util.*;

public class TaxReportVisitor implements InstrumentVisitor{
   
    private double totalTaxLiability ;
   
    // private  Map<String, Double> taxes; Map gây tình trạng ghi đè sai nên ko thể sửa chữa đc 
    private List<String> reportLines;
    public TaxReportVisitor()
    { 
        this.reportLines = new ArrayList<>();
        this.totalTaxLiability=0.0;
        totalTaxLiability =0.0;
    }
    protected void addTax(Instrument i,double tax){
        // String key = i.getClass().getSimpleName()+" "+ i.getSymbol();
        // taxes.put(key,tax);
        // totalTaxLiability += tax;
        String line = i.getClass().getSimpleName() 
                + " " 
                + i.getSymbol() 
                + ": " 
                + String.format("%.2f", tax);

        reportLines.add(line); // KHÔNG overwrite nữa
        totalTaxLiability += tax;
    }
    @Override
    public void visit(Stock s){
        double tax =  0.15 * s.getCurrentPriceValue();
        addTax(s, tax);
    }
    @Override
    public void visit (Bond b){

        double tax=  0.3 * b.annualCouponPayment(1);
        addTax(b, tax);

    }
    @Override
    public  void visit (Option o){
        
        double tax= 0.2* o.getCurrentPriceValue();
        addTax(o, tax);

    }
    @Override
    public void visit (Future o){

        double tax= 0.2* o.getCurrentPriceValue();
        addTax(o, tax);

    }

    public String getReport(){
        StringBuilder str = new StringBuilder();

        // for (Map.Entry<String, Double> entry : taxes.entrySet()) {
        //     str.append(entry.getKey())
        //       .append(": ")
        //       .append(String.format("%.2f", entry.getValue()))
        //       .append("\n");
        // }
        for (String line : reportLines) {
            str.append(line).append("\n");
        }
        str.append("Total Tax: ").append(String.format("%.2f", totalTaxLiability));
        return str.toString();
    }

    public double getTotalTaxLiability(){
        return totalTaxLiability;
    }
   

}
