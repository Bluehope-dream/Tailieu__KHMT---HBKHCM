

public interface  InstrumentVisitor {
    void visit(Stock s);
    void visit (Bond b);
    void visit (Option o);
    void visit (Future o);

}
