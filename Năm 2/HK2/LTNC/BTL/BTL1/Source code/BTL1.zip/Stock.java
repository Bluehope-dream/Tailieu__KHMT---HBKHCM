public class Stock extends Instrument {
    private  double marketCap;
    private String sector;

    public Stock(String symbol, String name, double currentPrice, double marketCap, String sector) {
        super(symbol, name, currentPrice);
        // TODO
        this.marketCap = marketCap;
        this.sector = sector;
    }

    @Override
    public double riskScore() {
        // TODO
        if (marketCap < Math.pow(10,9)){
            return 7.5;
        } else if (marketCap< Math.pow(10,10)){
            return 5.0;
        } else return 3.0;
    }

    @Override
    public String assetClass() {
        // TODO
        
        return "EQUITY";
    }
    @Override
    public void accept(InstrumentVisitor visitor){
        visitor.visit(this);
    }
    public double getMarketCap() {
        // TODO
        return marketCap;
    }

    public String getSector() {
        // TODO
        return sector;
    }
    public void setmarketCap(double marketCap){
        this.marketCap = marketCap;
    }
    public void setSector(String sector){
        this.sector= sector;
    }
}
