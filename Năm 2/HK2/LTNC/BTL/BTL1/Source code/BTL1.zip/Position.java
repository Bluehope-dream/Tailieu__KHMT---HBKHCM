public class Position {
    private final Instrument instrument;
    private int quantity;   
    private double averageCostBasis;

    public Position(Instrument instrument, int quantity, double averageCostBasis) {
        // TODO
        this.instrument = instrument;
        this.quantity = quantity;
        this.averageCostBasis = averageCostBasis;
    }

    public double marketValue() {
        // TODO
        return (this.quantity * instrument.getCurrentPriceValue());
    }

    public double unrealizedPnL() {
        // TODO
        return (marketValue() - quantity*averageCostBasis);
    }

    public void addQuantity(int qty, double costBasis) {
        // TODO
        
        double totalCost = averageCostBasis*quantity + qty*costBasis; 
        this.quantity += qty;
        this.averageCostBasis = totalCost / quantity;

    }

    public Instrument getInstrument() {
        // TODO
       return instrument;
    }

    public int getQuantity() {
        // TODO
        return quantity;
    }

    public double getAverageCostBasis() {
        // TODO
        return averageCostBasis;
    }

    @Override
    public String toString() {
        // TODO
        // Output : Position[symbol=<symbol>, qty=<quantity>, value=<value>, pnl=<pnl>] 
        return "Position[symbol="+ instrument.getSymbol() + ", qty="+ quantity+ ", value="+ String.format("%.2f", marketValue())+", pnl="+String.format("%.2f", unrealizedPnL())+"]";
    }
}
