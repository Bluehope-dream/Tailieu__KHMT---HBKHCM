// TODO

public class SimplePricingStrategy implements PricingStrategy {

    @Override
    public double calculateFairValue(Instrument i){
        return (i.getCurrentPriceValue()*1.05);
    }
    @Override
    public String strategyName(){
        return "SimplePricingStrategy";
    }
}