# TASK 2 - Hiện thực cấu trúc dữ liệu RedBlack Tree cho Vector Store

## 📋 Mô tả

Hiện thực Red Black Tree

## Tài liệu cấu trúc dữ liệu
---
| Tên cấu trúc dữ liệu   | File tài liệu                  |
|------------------------|--------------------------------|
| Red Black Tree         | [RB.md](./document/RB.md)      |
| Coverage               | [Coverage.md](./document/Coverage.md)      
---

## Biên dịch

### **Lệnh biên dịch bình thường**
```bash
g++ -std=c++17 -o main -I. main.cpp tests/*.cpp src/*.cpp
```
- `-std=c++17` — Sử dụng tiêu chuẩn C++17.
- `-o main` — Tạo file thực thi `main`.
- `tests/*.cpp` — Tất cả file `.cpp` trong thư mục `tests`.
- `-I.` - Thêm thư mục hiện tại (.) vào include path (danh sách thư mục tìm header).

---

### **Lệnh biên dịch từng file**
```bash
g++ -std=c++17 -o main -I. main.cpp tests/test_rb.cpp src/RB.cpp
```
- `-std=c++17` — Sử dụng tiêu chuẩn C++17.
- `-o main` — Tạo file thực thi `main`.
- `tests/test_rb.cpp` — File test cho lớp Red Black Tree.

---

### **Lệnh biên dịch với AddressSanitizer (phát hiện lỗi bộ nhớ)**
```bash
g++ -std=c++17 -fsanitize=address -fno-omit-frame-pointer -g -O0 -Wall -Wextra -o main -I. main.cpp tests/test_rb.cpp src/RB.cpp
```
**Giải thích thêm:**
- `-fsanitize=address` — Bật AddressSanitizer để phát hiện lỗi như tràn bộ nhớ, use-after-free...
- `-fno-omit-frame-pointer` — Giữ thông tin stack trace để debug dễ hơn.
- `-g` — Thêm thông tin debug.
- `-O0` — Tắt tối ưu hóa để debug chính xác.
- `-Wall -Wextra` — Bật tất cả cảnh báo quan trọng.

## Quy tắc

> Không được include thêm thư viện ngoài những thư viện đã cho sẵn.

> Các hàm được thiết kế sẵn là các hàm cung cấp cho các bạn tiện sử dụng trong quá trình phát triển, các bạn có thể thêm/sửa/xóa các hàm này nếu muốn.

> Các hàm in ra đã được set up sẵn để phù hợp với các bài test, các bạn không được sửa đổi định dạng in ra của các hàm này.