# TÀI LIỆU PHÁT TRIỂN RED-BLACK TREE

## Chèn và tái cân bằng

1. **Bước 1 – Chèn như BST thông thường**

* So sánh khóa `key` với các nút hiện có.
* Chèn nút mới `N` tại vị trí lá thích hợp.
* Gán `color(N) = RED`.

2. **Bước 2 – Sửa lỗi vi phạm quy tắc màu**

* Có thể vi phạm quy tắc “nút đỏ không có con đỏ”.
* Dựa vào **màu cha (P), ông (G), và chú (U)** để quyết định thao tác:

     * **Trường hợp 1:** N là gốc → tô đen.
     * **Trường hợp 2:** Cha (P) đỏ, chú (U) đỏ → **recolor**.
     ![alt text](images/image-1.png)

     * **Trường hợp 3:** Cha (P) đỏ, chú (U) đen, cấu hình “tam giác” → **xoay tại P** rồi xử lý lại.
     ![alt text](images/image-3.png)

     * **Trường hợp 4:** Cha (P) đỏ, chú (U) đen, cấu hình “đường thẳng” → **xoay tại G** và **đổi màu**.
     ![alt text](images/image-2.png)

---

## Xoá và tái cân bằng

Tốt 👌 — dưới đây là phần **mô tả giải thuật xóa trong cây Đỏ-Đen (Red-Black Tree)** được viết theo đúng **format** mà anh muốn (tương tự phần “Chèn và tái cân bằng” của anh):

---

## Xóa và tái cân bằng

1. **Bước 1 – Xóa như BST thông thường**

* Tìm nút có khóa `key` cần xóa — gọi là `Z`.
* Có ba trường hợp:

  * **Trường hợp 1:** `Z` không có con → xóa trực tiếp.
  * **Trường hợp 2:** `Z` có một con → thay thế `Z` bằng con của nó.
  * **Trường hợp 3:** `Z` có hai con → tìm **nút kế tiếp (successor)** `Y`, hoán đổi giá trị `Z` ↔ `Y`, rồi xóa `Y` (lúc này `Y` chỉ có nhiều nhất 1 con).

> Nếu **nút bị xóa hoặc bị thay thế có màu đen**, thì tính cân bằng màu của cây có thể bị phá vỡ.
> Ta gọi nút còn lại (hoặc `NULL`) là `X`, và thực hiện bước 2 để **tái cân bằng**.

---

2. **Bước 2 – Sửa lỗi vi phạm quy tắc màu**

* Mục tiêu: loại bỏ “**double black**” tại `X` (nút đen dư một cấp).
* Gọi:

  * `P` là cha của `X`
  * `W` là anh em (sibling) của `X`

### Trường hợp 1: `W` đỏ

→ Đổi màu:

* `W` → đen
* `P` → đỏ
* **Xoay** tại `P` theo hướng của `X`
  Sau đó, cập nhật lại `W` (vì cấu trúc cây đã thay đổi).

---

### Trường hợp 2: `W` đen và cả hai con của `W` đều đen hoặc NULL

→ Đổi màu `W` → đỏ
→ Dời vấn đề “double black” lên `P` (tức `X = P`) và lặp lại.

---

### Trường hợp 3: `W` đen, và:

* Nếu `X` là con trái của `P`:

  * `W->left` đỏ, `W->right` đen
    → Đổi màu `W->left` → đen, `W` → đỏ
    → **Xoay phải** tại `W`
    → Sang **Trường hợp 4**

* Nếu `X` là con phải của `P`:

  * `W->right` đỏ, `W->left` đen
    → Đổi màu `W->right` → đen, `W` → đỏ
    → **Xoay trái** tại `W`
    → Sang **Trường hợp 4**

---

### Trường hợp 4: `W` đen, và:

* Nếu `X` là con trái:

  * `W->right` đỏ
    → Đặt `W` có màu bằng `P`, `P` → đen, `W->right` → đen
    → **Xoay trái** tại `P`
    → Kết thúc.


* Nếu `X` là con phải:

  * `W->left` đỏ
    → Đặt `W` có màu bằng `P`, `P` → đen, `W->left` → đen
    → **Xoay phải** tại `P`
    → Kết thúc.

---

3. **Bước 3 – Đảm bảo gốc là đen**

* Sau khi hoàn tất, nếu `X` là gốc, tô đen nó để bảo toàn quy tắc.
