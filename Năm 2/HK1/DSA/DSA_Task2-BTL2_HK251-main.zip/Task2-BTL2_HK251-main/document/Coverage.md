# Độ bao phủ mã nguồn (Code Coverage)

Dự án này sử dụng **Doctest** để viết kiểm thử (unit test) và **Gcovr** để đo độ bao phủ mã nguồn.

## Cách chạy kiểm thử

1. Biên dịch chương trình với cờ hỗ trợ đo coverage:

   ```sh
   g++ -std=c++17 -O0 -g --coverage -I. -o main main.cpp src/*.cpp tests/*.cpp
   ```
2. Chạy chương trình kiểm thử:

   ```sh
   ./main
   ```
3. Tạo báo cáo độ bao phủ:

   ```sh
   gcovr -r . --html --html-details -o coverage.html
   ```
4. Mở file `coverage.html` trong trình duyệt để xem chi tiết (**đường dẫn bên ngoài chứ ko phải đường dẫn docker**).

![alt text](images/image.png)

## Ý nghĩa

* Độ bao phủ thể hiện tỷ lệ mã được chạy qua khi kiểm thử.
* Mục tiêu là **bao phủ cao nhất có thể** (thường trên 95%) để đảm bảo chất lượng mã.
